//! Rusted Calamari: an image viewer and sorter. The image owns the window.
//! The Octobrachial Tree folds out beside it; every other control stays
//! hidden until the pointer goes looking for it.

use crate::fonts::{self, FACES, SIZES};
use crate::glyph::{run_at, Grid, Run};
use crate::loader::{Loader, Slot};
use crate::theme::{self, chip, dialog, dropdown, r, ra, rd, Item, Row, ROUND, RULE, DIM, EDGE, IRON, IRON_HI, MUTED, PANEL, RUST, RUST_HI, SHADOW, STAGE, TEXT, WARN};
use eframe::egui::{self, Area, Color32, CursorIcon, Event, Id, Key, LayerId, Order, Pos2, Rect, Sense, Stroke, StrokeKind, TextEdit, Vec2, ViewportCommand};
use image::DynamicImage;
use octo::config::{self, Cat, Rgb};
use octo::layout::{render, Cls, Ctx, Kind, Style};
use octo::ops::{self, Op};
use octo::paint::colour;
use octo::tide::{self, balance, View};
use octo::tree::{is_decodable, Tree, IMAGES, OTHER_MEDIA};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

const STYLES: [Style; 3] = [Style::Arm, Style::Beak, Style::Boxed];
const STYLE_NAMES: [&str; 3] = ["Octobrachial Arm", "Octobrachial Beak", "Boxtobrachial"];
const SWATCHES: [&str; 12] = [
    "#e56399", "#92CC7C", "#7f96ff", "#a6cfd5", "#E6D463", "#F0A35E", "#c792ea", "#ff8a65", "#4dd0e1", "#aed581",
    "#f06292", "#9fa8da",
];
/// Keys the app keeps; categories cannot take them.
const RESERVED: [&str; 2] = ["h", "0"];
const ASPECTS: [(&str, f32); 9] = [
    ("free", 0.0),
    ("original", -1.0),
    ("1:1", 1.0),
    ("4:3", 4.0 / 3.0),
    ("3:2", 1.5),
    ("16:9", 16.0 / 9.0),
    ("3:4", 0.75),
    ("2:3", 2.0 / 3.0),
    ("9:16", 9.0 / 16.0),
];
const SPIN: [&str; 4] = ["▖", "▘", "▝", "▗"];
/// Preview resolution for pending edits.
const PREVIEW: u32 = 2560;

fn lerp_color(a: Color32, b: Color32, t: f32) -> Color32 {
    let f = |x: u8, y: u8| (x as f32 + (y as f32 - x as f32) * t).round() as u8;
    Color32::from_rgba_premultiplied(f(a.r(), b.r()), f(a.g(), b.g()), f(a.b(), b.b()), f(a.a(), b.a()))
}

fn rgb(c: Rgb) -> Color32 {
    Color32::from_rgb(c.0, c.1, c.2)
}

fn hexs(c: Rgb) -> String {
    format!("#{:02X}{:02X}{:02X}", c.0, c.1, c.2)
}

fn run(s: impl Into<String>, c: Color32) -> Run {
    (s.into(), c)
}

#[derive(Serialize, Deserialize, Clone)]
#[serde(default)]
pub struct Settings {
    pub font: usize,
    pub size: usize,
    pub style: usize,
    pub pin_ui: bool,
    /// Tree folded out beside the image.
    pub tree: bool,
    /// Width the user dragged the tree to; None hugs the tree.
    pub panel_w: Option<f32>,
    /// Folder and position written over the image ("japan 003").
    pub title: bool,
    pub library: Option<PathBuf>,
}

impl Default for Settings {
    fn default() -> Self {
        Settings { font: 0, size: 2, style: 0, pin_ui: false, tree: true, panel_w: None, title: false, library: None }
    }
}

struct Lib {
    tree: Tree,
    active: usize,
    cursor: usize,
}

enum Undo {
    Move { from: usize, to: usize, from_name: String, to_name: String },
    Trash { node: usize, name: String, trashed: PathBuf },
    /// Bytes the file had before a save.
    Saved { node: usize, name: String, bytes: Vec<u8> },
    /// A pending op on this file.
    Op { path: PathBuf },
}

/// Unsaved edits on one file, previewed at screen resolution.
struct Pending {
    ops: Vec<Op>,
    base: DynamicImage,
    full: [u32; 2],
    tex: egui::TextureHandle,
}

#[derive(Clone, Copy, PartialEq)]
enum Grab {
    Move,
    /// Bit 0: left edge, 1: right, 2: top, 3: bottom.
    Edge(u8),
    New,
}

struct Crop {
    path: PathBuf,
    r: [f32; 4],
    aspect: usize,
    grab: Option<(Grab, [f32; 4], Pos2)>,
}

struct Fly {
    tex: Option<egui::TextureHandle>,
    from: Rect,
    cat: usize,
    t0: f64,
}

struct Flash {
    node: usize,
    cat: usize,
    t0: f64,
}

#[derive(Clone, Copy, PartialEq)]
enum Menu {
    File,
    Edit,
    View,
}

#[derive(Clone, Copy, PartialEq)]
enum Act {
    Menu(Menu),
    Settings,
    Help,
    Close,
    Open,
    ImportImages,
    Save,
    SaveAll,
    ExportAs,
    Revert,
    ImportCats,
    ExportCats,
    Manifest,
    ExportSet,
    Quit,
    Undo,
    CropTool,
    Edit(Op),
    Trash,
    Tree,
    Fit,
    Actual,
    Style(bool),
    Pin,
    Title,
    Font(bool),
    Size(bool),
    EditCat(usize),
    NewCat,
    FormKey,
    Swatch(bool),
    Tier(bool),
    FormSave,
    FormDelete,
    FormCancel,
    SaveAllQuit,
    DiscardQuit,
    Aspect(bool),
    CropApply,
    CropCancel,
    Throw(usize),
    CidEdit(usize),
}

/// A category colour being edited in place: changes apply live; Esc puts
/// the original back.
struct CidEdit {
    cat: usize,
    at: Rect,
    orig: Rgb,
    hex: String,
    opened: f64,
}

struct Form {
    edit: Option<usize>,
    name: String,
    key: Option<String>,
    cid: String,
    tier: char,
    capturing: bool,
    err: Option<String>,
}

enum Dialog {
    None,
    Help,
    Settings,
    Form(Form),
    Unsaved,
}

enum TreeAct {
    Arm(usize),
    Ink(usize),
    Throw(usize),
    Browse(usize),
}

pub struct App {
    s: Settings,
    font_on: Option<usize>,
    lib: Option<Lib>,
    loader: Loader,
    view: View,
    dialog: Dialog,
    menu: Option<Menu>,
    chrome_hover: bool,
    quiet: bool,
    zoom: f32,
    pan: Vec2,
    undo: Vec<Undo>,
    fly: Vec<Fly>,
    flash: Option<Flash>,
    landing: Option<(usize, f64)>,
    toast: Option<(String, Color32, f64)>,
    img_rect: Option<Rect>,
    chips: Vec<(usize, Pos2)>,
    tree_acc: f32,
    tree_dx: f32,
    tree_hold: f32,
    hold_frames: u8,
    typed: bool,
    pending: HashMap<PathBuf, Pending>,
    crop: Option<Crop>,
    cid_edit: Option<CidEdit>,
    quitting: bool,
}

impl App {
    pub fn new(cc: &eframe::CreationContext<'_>, arg: Option<PathBuf>) -> App {
        let s: Settings = cc.storage.and_then(|st| eframe::get_value(st, "rusted-calamari")).unwrap_or_default();
        let mut v = egui::Visuals::dark();
        v.text_cursor.stroke = Stroke::new(2.0, RUST_HI);
        v.selection.bg_fill = RUST;
        v.panel_fill = STAGE;
        cc.egui_ctx.set_visuals(v);
        let mut app = App {
            s,
            font_on: None,
            lib: None,
            loader: Loader::new(cc.egui_ctx.clone()),
            view: View { rows: 40, scroll: 0 },
            dialog: Dialog::None,
            menu: None,
            chrome_hover: false,
            quiet: false,
            zoom: 1.0,
            pan: Vec2::ZERO,
            undo: Vec::new(),
            fly: Vec::new(),
            flash: None,
            landing: None,
            toast: None,
            img_rect: None,
            chips: Vec::new(),
            tree_acc: 0.0,
            tree_dx: 0.0,
            tree_hold: 0.0,
            hold_frames: 3,
            typed: false,
            pending: HashMap::new(),
            crop: None,
            cid_edit: None,
            quitting: false,
        };
        let start = arg.or_else(|| app.s.library.clone()).filter(|p| p.is_dir());
        if let Some(p) = start {
            app.open_library(&p, 0.0);
        }
        app
    }

    fn style(&self) -> Style {
        STYLES[self.s.style % 3]
    }

    fn say(&mut self, s: impl Into<String>, c: Color32, now: f64) {
        self.toast = Some((s.into(), c, now));
    }

    fn ctx_of(lib: &Lib) -> Ctx {
        Ctx { active: Some(lib.active), cursor: lib.cursor }
    }

    // ── library ──────────────────────────────────────────────────────

    fn open_library(&mut self, p: &Path, now: f64) {
        let p = p.canonicalize().unwrap_or_else(|_| p.to_path_buf());
        match Tree::scan(&p, config::load(&p)) {
            Ok(mut tree) => {
                balance(&mut tree, self.style(), &Ctx { active: Some(0), cursor: 0 });
                self.lib = Some(Lib { tree, active: 0, cursor: 0 });
                self.s.library = Some(p);
                self.view.scroll = 0;
                self.undo.clear();
                self.fly.clear();
                self.flash = None;
                self.crop = None;
                self.pending.clear();
                self.tree_hold = 0.0;
                self.reset_view();
            }
            Err(e) => self.say(format!("Can't open {}: {e}", p.display()), WARN, now),
        }
    }

    fn reset_view(&mut self) {
        self.zoom = 1.0;
        self.pan = Vec2::ZERO;
    }

    fn current(&self) -> Option<PathBuf> {
        let lib = self.lib.as_ref()?;
        let f = lib.tree.nodes[lib.active].files.get(lib.cursor)?;
        Some(lib.tree.dir(lib.active).join(&f.name))
    }

    fn current_cat(&self) -> Option<usize> {
        let lib = self.lib.as_ref()?;
        lib.tree.nodes[lib.active].files.get(lib.cursor)?.cat
    }

    fn current_px(&self) -> Option<[u32; 2]> {
        let p = self.current()?;
        match (self.pending.get(&p), self.loader.get(&p)) {
            (Some(pd), _) => Some(ops::dims(pd.full[0], pd.full[1], &pd.ops)),
            (None, Some(Slot::Ready { size, .. })) => Some(*size),
            _ => None,
        }
    }

    fn step(&mut self, d: isize) {
        let Some(lib) = self.lib.as_mut() else { return };
        let n = lib.tree.nodes[lib.active].files.len();
        if n == 0 {
            return;
        }
        let c = (lib.cursor as isize + d).clamp(0, n as isize - 1) as usize;
        if c != lib.cursor {
            lib.cursor = c;
            self.crop = None;
            self.reset_view();
        }
    }

    /// Throw the active image into category `cat` of the active folder.
    /// Unsaved edits are written first so they travel with the file.
    fn classify(&mut self, cat: usize, now: f64) {
        if let Some(path) = self.current()
            && self.pending.contains_key(&path)
            && !self.save(&path, now)
        {
            return;
        }
        let from = self.img_rect;
        let Some(lib) = self.lib.as_mut() else { return };
        let a = lib.active;
        let Some(f) = lib.tree.nodes[a].files.get(lib.cursor).cloned() else { return };
        let dir = lib.tree.dir(a);
        let src = dir.join(&f.name);
        let cname = lib.tree.cats[cat].name.clone();
        match ops::move_into(&src, &dir.join(&cname), &f.name) {
            Ok(n) => {
                let tex = self.loader.texture(&src);
                self.loader.forget(&src);
                lib.tree.take_file(a, &f.name);
                let d = lib.tree.ensure_child(a, &cname);
                lib.tree.put_file(d, &n);
                let len = lib.tree.nodes[a].files.len();
                lib.cursor = lib.cursor.min(len.saturating_sub(1));
                self.undo.push(Undo::Move { from: a, to: d, from_name: f.name, to_name: n });
                match from {
                    Some(r) => self.fly.push(Fly { tex, from: r, cat, t0: now }),
                    None => self.landing = Some((cat, now)),
                }
                self.flash = Some(Flash { node: d, cat, t0: now });
                self.crop = None;
                self.reset_view();
            }
            Err(e) => self.say(format!("Couldn't move {}: {e}", f.name), WARN, now),
        }
    }

    fn trash(&mut self, now: f64) {
        let Some(path) = self.current() else { return };
        self.pending.remove(&path);
        self.crop = None;
        let lib = self.lib.as_mut().unwrap();
        let a = lib.active;
        let name = lib.tree.nodes[a].files[lib.cursor].name.clone();
        let td = ops::trash_dir(&lib.tree);
        match ops::move_into(&path, &td, &name) {
            Ok(n) => {
                self.loader.forget(&path);
                lib.tree.take_file(a, &name);
                let len = lib.tree.nodes[a].files.len();
                lib.cursor = lib.cursor.min(len.saturating_sub(1));
                self.undo.push(Undo::Trash { node: a, name, trashed: td.join(n) });
            }
            Err(e) => self.say(format!("Couldn't trash {name}: {e}"), WARN, now),
        }
    }

    // ── edits ────────────────────────────────────────────────────────

    fn preview(ctx: &egui::Context, base: &DynamicImage, ops: &[Op], path: &Path) -> egui::TextureHandle {
        let img = ops::apply(base.clone(), ops).to_rgba8();
        let ci = egui::ColorImage::from_rgba_unmultiplied([img.width() as usize, img.height() as usize], img.as_raw());
        ctx.load_texture(format!("edit:{}", path.display()), ci, egui::TextureOptions::LINEAR)
    }

    fn push_op(&mut self, ctx: &egui::Context, op: Op, now: f64) {
        let Some(path) = self.current() else { return };
        if !is_decodable(&path.to_string_lossy()) {
            self.say("This format can't be edited", WARN, now);
            return;
        }
        if !self.pending.contains_key(&path) {
            match ops::decode(&path) {
                Ok(img) => {
                    let full = [img.width(), img.height()];
                    let base = if full[0].max(full[1]) > PREVIEW { img.thumbnail(PREVIEW, PREVIEW) } else { img };
                    let tex = Self::preview(ctx, &base, &[], &path);
                    self.pending.insert(path.clone(), Pending { ops: Vec::new(), base, full, tex });
                }
                Err(e) => {
                    self.say(format!("Can't edit: {e}"), WARN, now);
                    return;
                }
            }
        }
        let p = self.pending.get_mut(&path).unwrap();
        p.ops.push(op);
        p.tex = Self::preview(ctx, &p.base, &p.ops, &path);
        self.undo.push(Undo::Op { path });
        self.reset_view();
    }

    fn save(&mut self, path: &Path, now: f64) -> bool {
        let Some(p) = self.pending.get(path) else { return true };
        match ops::save_ops(path, &p.ops) {
            Ok(bytes) => {
                self.pending.remove(path);
                self.loader.forget(path);
                self.undo.retain(|u| !matches!(u, Undo::Op { path: q } if q == path));
                if let Some(lib) = &self.lib {
                    let name = path.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
                    if let Some(node) = (0..lib.tree.nodes.len()).find(|&i| Some(lib.tree.dir(i).as_path()) == path.parent()) {
                        self.undo.push(Undo::Saved { node, name, bytes });
                    }
                }
                true
            }
            Err(e) => {
                self.say(format!("Couldn't save: {e}"), WARN, now);
                false
            }
        }
    }

    fn save_all(&mut self, now: f64) -> bool {
        let paths: Vec<PathBuf> = self.pending.keys().cloned().collect();
        let n = paths.len();
        let ok = paths.iter().filter(|p| self.save(p, now)).count();
        if n > 1 {
            self.say(format!("Saved {ok} of {n} images"), MUTED, now);
        }
        ok == n
    }

    fn export_as(&mut self, now: f64) {
        let Some(path) = self.current() else { return };
        let stem = path.file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "image".into());
        let ext = path.extension().map(|s| s.to_string_lossy().to_ascii_lowercase()).unwrap_or_else(|| "png".into());
        let Some(dest) = rfd::FileDialog::new()
            .set_title("Export as")
            .set_directory(path.parent().unwrap_or(Path::new(".")))
            .set_file_name(format!("{stem}_export.{ext}"))
            .add_filter("PNG", &["png"])
            .add_filter("JPEG", &["jpg", "jpeg"])
            .add_filter("WebP", &["webp"])
            .add_filter("BMP", &["bmp"])
            .add_filter("TIFF", &["tif", "tiff"])
            .save_file()
        else {
            return;
        };
        let ops = self.pending.get(&path).map(|p| p.ops.clone()).unwrap_or_default();
        match ops::export_ops(&path, &ops, &dest) {
            Ok(()) => {
                // An export into the library shows up where it landed.
                if let Some(lib) = self.lib.as_mut()
                    && let Some(node) = (0..lib.tree.nodes.len()).find(|&i| Some(lib.tree.dir(i).as_path()) == dest.parent())
                {
                    let name = dest.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
                    if octo::tree::is_media(&name) && !lib.tree.nodes[node].files.iter().any(|f| f.name == name) {
                        lib.tree.put_file(node, &name);
                    }
                }
                self.say(format!("Exported {}", dest.display()), MUTED, now);
            }
            Err(e) => self.say(format!("Couldn't export: {e}"), WARN, now),
        }
    }

    fn undo(&mut self, ctx: &egui::Context, now: f64) {
        let Some(u) = self.undo.pop() else { return };
        if let Undo::Op { path } = &u {
            if let Some(p) = self.pending.get_mut(path) {
                p.ops.pop();
                if p.ops.is_empty() {
                    self.pending.remove(path);
                } else {
                    p.tex = Self::preview(ctx, &p.base, &p.ops, path);
                }
            }
            return;
        }
        let Some(lib) = self.lib.as_mut() else { return };
        let r = match u {
            Undo::Move { from, to, from_name, to_name } => {
                let src = lib.tree.dir(to).join(&to_name);
                ops::move_into(&src, &lib.tree.dir(from), &from_name).map(|n| {
                    lib.tree.take_file(to, &to_name);
                    (from, lib.tree.put_file(from, &n))
                })
            }
            Undo::Trash { node, name, trashed } => {
                ops::move_into(&trashed, &lib.tree.dir(node), &name).map(|n| (node, lib.tree.put_file(node, &n)))
            }
            Undo::Saved { node, name, bytes } => {
                let p = lib.tree.dir(node).join(&name);
                std::fs::write(&p, bytes).map(|_| {
                    self.loader.forget(&p);
                    (node, lib.tree.nodes[node].files.iter().position(|f| f.name == name).unwrap_or(0))
                })
            }
            Undo::Op { .. } => unreachable!(),
        };
        match r {
            Ok((node, i)) => {
                lib.active = node;
                lib.cursor = i;
                self.crop = None;
                self.reset_view();
            }
            Err(e) => self.say(format!("Couldn't undo: {e}"), WARN, now),
        }
    }

    fn start_crop(&mut self) {
        if let Some(path) = self.current()
            && is_decodable(&path.to_string_lossy())
        {
            self.reset_view();
            self.crop = Some(Crop { path, r: [0.0, 0.0, 1.0, 1.0], aspect: 0, grab: None });
        }
    }

    // ── tree ─────────────────────────────────────────────────────────

    fn tree_act(&mut self, act: TreeAct, now: f64) {
        let style = self.style();
        match act {
            TreeAct::Throw(c) => self.classify(c, now),
            TreeAct::Ink(id) => {
                let lib = self.lib.as_mut().unwrap();
                let cx = Self::ctx_of(lib);
                tide::click(&mut lib.tree, &mut self.view, style, &cx, id, true);
                self.tree_hold = 0.0;
            }
            TreeAct::Arm(id) | TreeAct::Browse(id) => {
                self.tree_hold = 0.0;
                self.crop = None;
                let lib = self.lib.as_mut().unwrap();
                if id == lib.active {
                    let cx = Self::ctx_of(lib);
                    tide::click(&mut lib.tree, &mut self.view, style, &cx, id, false);
                    return;
                }
                // Keep the clicked row under the pointer while the slot rows move.
                let old = Self::ctx_of(lib);
                let r = render(&lib.tree, style, &old).row(id).map(|x| x as isize - self.view.scroll as isize);
                lib.active = id;
                lib.cursor = 0;
                let cx = Self::ctx_of(lib);
                if let (Some(r), Some(nr)) = (r, render(&lib.tree, style, &cx).row(id)) {
                    self.view.scroll = (nr as isize - r).max(0) as usize;
                }
                let n = &lib.tree.nodes[id];
                let has_arms = n.kids.iter().any(|&k| lib.tree.nodes[k].own_cat.is_none());
                if !n.open && has_arms {
                    tide::click(&mut lib.tree, &mut self.view, style, &cx, id, false);
                }
                self.reset_view();
            }
        }
    }

    /// Width the tree wants: its widest row, held while sorting so the
    /// image doesn't twitch as sucker rows shorten.
    fn tree_width(&mut self, g: &Grid, full: Rect) -> f32 {
        if let Some(w) = self.s.panel_w {
            return w.clamp(g.cw * 24.0, full.width() * 0.6);
        }
        let Some(lib) = self.lib.as_ref() else { return 0.0 };
        let f = render(&lib.tree, self.style(), &Self::ctx_of(lib));
        let want = f.lines.iter().map(|x| x.width()).max().unwrap_or(0) as f32 * g.cw + g.cw * 4.0;
        if self.hold_frames > 0 {
            self.hold_frames -= 1;
            self.tree_hold = 0.0;
        }
        self.tree_hold = self.tree_hold.max(want);
        self.tree_hold.clamp(g.cw * 24.0, full.width() * 0.5)
    }

    fn tree_pane(&mut self, ui: &mut egui::Ui, rect: Rect, x0: f32, g: &Grid, now: f64) {
        let style = self.style();
        let Some(lib) = self.lib.as_ref() else { return };
        let cx = Self::ctx_of(lib);
        let frame = render(&lib.tree, style, &cx);
        let inner = Rect::from_min_max(Pos2::new(x0 + g.cw * 1.5, rect.top() + g.rh), Pos2::new(rect.right() - g.cw, rect.bottom() - g.rh));
        let rows = ((inner.height() / g.rh).floor() as usize).max(1);
        self.view.rows = rows;
        self.view.scroll = self.view.scroll.min(frame.lines.len().saturating_sub(1));

        let resp = ui.interact(rect, Id::new("otf-pane"), Sense::click_and_drag());
        let widest = frame.lines.iter().map(|l| l.width()).max().unwrap_or(0) as f32 * g.cw;
        let slack = (widest - inner.width()).max(0.0);
        if resp.hovered() {
            self.tree_dx += ui.input(|i| i.smooth_scroll_delta.x);
            self.tree_acc += ui.input(|i| i.smooth_scroll_delta.y);
            while self.tree_acc >= g.rh {
                self.tree_acc -= g.rh;
                self.view.scroll = self.view.scroll.saturating_sub(1);
            }
            while self.tree_acc <= -g.rh {
                self.tree_acc += g.rh;
                if self.view.scroll + rows < frame.lines.len() {
                    self.view.scroll += 1;
                }
            }
        }
        self.tree_dx = (self.tree_dx + resp.drag_delta().x).clamp(-slack, 0.0);
        let inner = inner.translate(Vec2::new(self.tree_dx, 0.0));

        let p = ui.painter().with_clip_rect(rect);
        p.rect_filled(rect, 0.0, PANEL);
        let hover_row = resp.hover_pos().map(|h| ((h.y - inner.top()) / g.rh).floor()).filter(|r| *r >= 0.0).map(|r| r as usize);
        let end = (self.view.scroll + rows).min(frame.lines.len());
        for (i, li) in (self.view.scroll..end).enumerate() {
            let line = &frame.lines[li];
            let y = inner.top() + i as f32 * g.rh;
            if hover_row == Some(i) {
                p.rect_filled(Rect::from_min_size(Pos2::new(rect.left(), y), Vec2::new(rect.width(), g.rh)), 0.0, Color32::from_white_alpha(6));
            }
            let mut x = inner.left();
            let mut runs: Vec<Run> = Vec::with_capacity(line.spans.len());
            for s in &line.spans {
                let w = s.text.chars().count() as f32 * g.cw;
                let mut col = rgb(colour(&lib.tree, s.cls).0);
                if let Cls::CatName(cat) = s.cls
                    && let Some(f) = &self.flash
                    && s.node == Some(f.node)
                    && cat == f.cat
                    && now - f.t0 < 0.8
                {
                    let k = 1.0 - ((now - f.t0) / 0.8) as f32;
                    p.rect_filled(Rect::from_min_size(Pos2::new(x - 1.0, y), Vec2::new(w + 2.0, g.rh)), 0.0, col.gamma_multiply(k));
                    if k > 0.45 {
                        col = STAGE;
                    }
                }
                runs.push((s.text.clone(), col));
                x += w;
            }
            g.line(&p, Pos2::new(inner.left(), y), &runs, 1.0);
        }
        let above = self.view.scroll;
        let below = frame.lines.len().saturating_sub(end);
        if above > 0 {
            let t = format!("▲ {above}");
            g.text(&p, Pos2::new(rect.right() - (t.chars().count() as f32 + 2.0) * g.cw, rect.top() + g.rh * 0.2), &t, DIM, 1.0);
        }
        if below > 0 {
            let t = format!("▼ {below}");
            g.text(&p, Pos2::new(rect.right() - (t.chars().count() as f32 + 2.0) * g.cw, rect.bottom() - g.rh * 1.2), &t, DIM, 1.0);
        }

        let mut act = None;
        if (resp.clicked() || resp.secondary_clicked())
            && let Some(pos) = resp.interact_pointer_pos()
        {
            let rr = ((pos.y - inner.top()) / g.rh).floor();
            if rr >= 0.0
                && let Some(line) = frame.lines.get(self.view.scroll + rr as usize)
                && let Some(si) = run_at(&line.spans, |s| s.text.chars().count(), g.col(inner.left(), pos.x))
            {
                let s = &line.spans[si];
                let slot = line.spans[..=si].iter().rev().find_map(|x| match x.cls {
                    Cls::CatName(c) => Some((c, x.node)),
                    _ => None,
                });
                act = match s.cls {
                    Cls::Ink => s.node.map(TreeAct::Ink),
                    Cls::CatName(_) | Cls::Count | Cls::Sucker(None) | Cls::Cursor if line.kind == Kind::Beak && slot.is_some() => {
                        let (c, node) = slot.unwrap();
                        if resp.secondary_clicked() { node.map(TreeAct::Browse) } else { Some(TreeAct::Throw(c)) }
                    }
                    _ => s.node.map(TreeAct::Arm),
                };
            }
        }
        if let Some(a) = act {
            self.tree_act(a, now);
        }
    }

    // ── stage ────────────────────────────────────────────────────────

    fn stage(&mut self, ui: &mut egui::Ui, rect: Rect, g: &Grid, now: f64) {
        self.img_rect = None;
        let Some(lib) = self.lib.as_ref() else { return };
        let node = &lib.tree.nodes[lib.active];
        let p = ui.painter().with_clip_rect(rect);
        let Some(f) = node.files.get(lib.cursor) else {
            let first = format!("{} has no loose images", node.name);
            let hint = if self.s.tree { "Pick a folder in the tree to sort from it" } else { "Press Tab to open the tree and pick a folder" };
            theme::card(&p, g, rect.center(), &[(first.as_str(), TEXT), (hint, MUTED)]);
            return;
        };
        let name = f.name.clone();
        let path = lib.tree.dir(lib.active).join(&name);
        let cropping = self.crop.as_ref().is_some_and(|c| c.path == path);
        let resp = ui.interact(rect, Id::new("stage"), Sense::click_and_drag());

        let (tex, orig) = match (self.pending.get(&path), self.loader.get(&path)) {
            (Some(pd), _) => (pd.tex.clone(), ops::dims(pd.full[0], pd.full[1], &pd.ops)),
            (None, Some(Slot::Ready { tex, size, .. })) => (tex.clone(), *size),
            (None, Some(Slot::Failed(e))) => {
                let e = e.clone();
                theme::card(&p, g, rect.center(), &[(name.as_str(), TEXT), ("Can't decode this file", WARN), (e.as_str(), MUTED)]);
                self.img_rect = Some(Rect::from_center_size(rect.center(), g.size(24, 5)));
                return;
            }
            (None, None) if is_decodable(&name) => {
                let s = SPIN[((now * 8.0) as usize) % 4];
                g.text(&p, rect.center() - Vec2::new(g.cw * 0.5, g.rh * 0.5), s, MUTED, 1.0);
                ui.ctx().request_repaint();
                return;
            }
            (None, None) => {
                theme::card(&p, g, rect.center(), &[(name.as_str(), TEXT), ("No preview for this format", MUTED), ("It still sorts", MUTED)]);
                self.img_rect = Some(Rect::from_center_size(rect.center(), g.size(28, 5)));
                return;
            }
        };
        let ts = tex.size_vec2();
        let fit = (rect.width() / ts.x).min(rect.height() / ts.y);
        if !cropping {
            if resp.double_clicked() {
                self.reset_view();
            }
            self.pan += resp.drag_delta();
            if resp.hovered() {
                let dy = ui.input(|i| i.smooth_scroll_delta.y);
                if dy != 0.0
                    && let Some(ptr) = resp.hover_pos()
                {
                    let old = self.zoom;
                    self.zoom = (self.zoom * (1.0 + dy * 0.0025)).clamp(0.1, 32.0);
                    let c = rect.center() + self.pan;
                    self.pan += (ptr - c) * (1.0 - self.zoom / old);
                }
            }
            if resp.dragged() {
                ui.ctx().set_cursor_icon(CursorIcon::Grabbing);
            }
        }
        let r = Rect::from_center_size(rect.center() + self.pan, ts * fit * self.zoom);
        // Lift the picture off the stage.
        p.rect_filled(r.translate(Vec2::new(0.0, 5.0)).expand(3.0), 3.0, SHADOW);
        p.image(tex.id(), r, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
        self.img_rect = Some(r);
        // The image's cid, held in the app: a rule under the picture.
        if let Some(c) = self.current_cat() {
            let bar = Rect::from_min_size(Pos2::new(r.left(), r.bottom() + 6.0), Vec2::new(r.width(), 3.0));
            p.rect_filled(bar, 0.0, rgb(self.lib.as_ref().unwrap().tree.cats[c].cid));
        }
        if self.s.title && !cropping {
            self.title_overlay(&p, g, r);
        }
        if cropping {
            self.crop_overlay(ui, &p, &resp, r, orig, g);
        }
    }

    /// "japan 003": the folder and the image's place in it, set large in the
    /// interface face on the image's lower left, with a hard drop shadow.
    fn title_overlay(&self, p: &egui::Painter, g: &Grid, r: Rect) {
        let Some(lib) = self.lib.as_ref() else { return };
        let n = &lib.tree.nodes[lib.active];
        let digits = n.files.len().to_string().len().max(3);
        let text = format!("{} {:0digits$}", n.name, lib.cursor + 1);
        let size = (g.font.size * 2.4).min(r.height() * 0.12).max(g.font.size);
        let font = egui::FontId::monospace(size);
        let pos = Pos2::new(r.left() + size * 1.2, r.bottom() - size * 1.6);
        let pos = pos.max(r.min);
        p.text(pos + Vec2::new(size * 0.08, size * 0.08), egui::Align2::LEFT_TOP, &text, font.clone(), Color32::from_black_alpha(170));
        p.text(pos, egui::Align2::LEFT_TOP, &text, font, Color32::from_rgb(0xf2, 0xee, 0xe4));
    }

    fn crop_overlay(&mut self, ui: &egui::Ui, p: &egui::Painter, resp: &egui::Response, ir: Rect, px: [u32; 2], g: &Grid) {
        let Some(c) = self.crop.as_mut() else { return };
        let to_screen = |n: [f32; 4]| Rect::from_min_max(ir.lerp_inside(Vec2::new(n[0], n[1])), ir.lerp_inside(Vec2::new(n[2], n[3])));
        let to_norm = |q: Pos2| [((q.x - ir.left()) / ir.width()).clamp(0.0, 1.0), ((q.y - ir.top()) / ir.height()).clamp(0.0, 1.0)];
        let ratio = match ASPECTS[c.aspect].1 {
            x if x < 0.0 => Some(px[0] as f32 / px[1] as f32),
            x if x == 0.0 => None,
            x => Some(x),
        };
        let hit = |s: Rect, q: Pos2| -> Grab {
            let t = 10.0;
            let mut m = 0u8;
            if (q.x - s.left()).abs() < t && q.y > s.top() - t && q.y < s.bottom() + t {
                m |= 1
            }
            if (q.x - s.right()).abs() < t && q.y > s.top() - t && q.y < s.bottom() + t {
                m |= 2
            }
            if (q.y - s.top()).abs() < t && q.x > s.left() - t && q.x < s.right() + t {
                m |= 4
            }
            if (q.y - s.bottom()).abs() < t && q.x > s.left() - t && q.x < s.right() + t {
                m |= 8
            }
            if m != 0 {
                Grab::Edge(m)
            } else if s.contains(q) {
                Grab::Move
            } else {
                Grab::New
            }
        };
        let s = to_screen(c.r);
        if let Some(h) = resp.hover_pos()
            && c.grab.is_none()
        {
            ui.ctx().set_cursor_icon(match hit(s, h) {
                Grab::Move => CursorIcon::Move,
                Grab::Edge(m) if m & 3 != 0 && m & 12 != 0 => {
                    if (m & 1 != 0) == (m & 4 != 0) { CursorIcon::ResizeNwSe } else { CursorIcon::ResizeNeSw }
                }
                Grab::Edge(m) if m & 3 != 0 => CursorIcon::ResizeHorizontal,
                Grab::Edge(_) => CursorIcon::ResizeVertical,
                Grab::New => CursorIcon::Crosshair,
            });
        }
        if resp.drag_started()
            && let Some(q) = resp.interact_pointer_pos()
        {
            c.grab = Some((hit(s, q), c.r, q));
        }
        if resp.dragged()
            && let (Some((grab, r0, q0)), Some(q)) = (c.grab, resp.interact_pointer_pos())
        {
            let [nx, ny] = to_norm(q);
            let mut r = r0;
            match grab {
                Grab::Move => {
                    let (w, h) = (r0[2] - r0[0], r0[3] - r0[1]);
                    r[0] = (r0[0] + (q.x - q0.x) / ir.width()).clamp(0.0, 1.0 - w);
                    r[1] = (r0[1] + (q.y - q0.y) / ir.height()).clamp(0.0, 1.0 - h);
                    r[2] = r[0] + w;
                    r[3] = r[1] + h;
                }
                Grab::New => {
                    let [ax, ay] = to_norm(q0);
                    r = [ax.min(nx), ay.min(ny), ax.max(nx), ay.max(ny)];
                }
                Grab::Edge(m) => {
                    if m & 1 != 0 {
                        r[0] = nx.min(r[2] - 0.01)
                    }
                    if m & 2 != 0 {
                        r[2] = nx.max(r[0] + 0.01)
                    }
                    if m & 4 != 0 {
                        r[1] = ny.min(r[3] - 0.01)
                    }
                    if m & 8 != 0 {
                        r[3] = ny.max(r[1] + 0.01)
                    }
                }
            }
            if let Some(a) = ratio
                && grab != Grab::Move
            {
                // Hold the ratio in pixels: height follows width.
                let w_px = (r[2] - r[0]) * px[0] as f32;
                let mut h_n = w_px / a / px[1] as f32;
                let from_bottom = matches!(grab, Grab::Edge(m) if m & 4 != 0) || (grab == Grab::New && ny < to_norm(q0)[1]);
                if from_bottom {
                    h_n = h_n.min(r[3]);
                    r[1] = r[3] - h_n;
                } else {
                    h_n = h_n.min(1.0 - r[1]);
                    r[3] = r[1] + h_n;
                }
                let w_n = h_n * a * px[1] as f32 / px[0] as f32;
                if matches!(grab, Grab::Edge(m) if m & 1 != 0) {
                    r[0] = r[2] - w_n
                } else {
                    r[2] = r[0] + w_n
                }
            }
            c.r = r;
        }
        if resp.drag_stopped() {
            c.grab = None;
        }

        // Dim outside, thirds inside, rust corners, pixel size above.
        let s = to_screen(c.r);
        let veil = Color32::from_black_alpha(165);
        p.rect_filled(Rect::from_min_max(ir.min, Pos2::new(ir.right(), s.top())), 0.0, veil);
        p.rect_filled(Rect::from_min_max(Pos2::new(ir.left(), s.bottom()), ir.max), 0.0, veil);
        p.rect_filled(Rect::from_min_max(Pos2::new(ir.left(), s.top()), Pos2::new(s.left(), s.bottom())), 0.0, veil);
        p.rect_filled(Rect::from_min_max(Pos2::new(s.right(), s.top()), Pos2::new(ir.right(), s.bottom())), 0.0, veil);
        let thin = Stroke::new(1.0, Color32::from_white_alpha(55));
        for k in [1.0 / 3.0, 2.0 / 3.0] {
            let x = s.left() + s.width() * k;
            let y = s.top() + s.height() * k;
            p.line_segment([Pos2::new(x, s.top()), Pos2::new(x, s.bottom())], thin);
            p.line_segment([Pos2::new(s.left(), y), Pos2::new(s.right(), y)], thin);
        }
        p.rect_stroke(s, 0.0, Stroke::new(1.0, RUST_HI), StrokeKind::Outside);
        let l = 14.0_f32.min(s.width() / 3.0).min(s.height() / 3.0);
        let thick = Stroke::new(3.0, RUST_HI);
        for (cx, cy, sx, sy) in [(s.left(), s.top(), 1.0, 1.0), (s.right(), s.top(), -1.0, 1.0), (s.left(), s.bottom(), 1.0, -1.0), (s.right(), s.bottom(), -1.0, -1.0)] {
            p.line_segment([Pos2::new(cx, cy), Pos2::new(cx + sx * l, cy)], thick);
            p.line_segment([Pos2::new(cx, cy), Pos2::new(cx, cy + sy * l)], thick);
        }
        let d = ops::dims(px[0], px[1], &[Op::Crop(c.r)]);
        let label = format!(" {} x {} ", d[0], d[1]);
        let lp = Pos2::new(s.left(), (s.top() - g.rh - 4.0).max(ir.top()));
        p.rect_filled(Rect::from_min_size(lp, g.size(label.chars().count(), 1)), 0.0, RUST);
        g.text(p, lp, &label, STAGE, 1.0);
    }

    fn want(&mut self) {
        let Some(lib) = self.lib.as_ref() else { return };
        let files = &lib.tree.nodes[lib.active].files;
        if files.is_empty() {
            self.loader.want(&[]);
            return;
        }
        let dir = lib.tree.dir(lib.active);
        let c = lib.cursor as isize;
        let mut v = Vec::new();
        for d in [0isize, 1, -1, 2, 3, -2, 5, -5, 25, 50] {
            let i = c + d;
            if i >= 0 && (i as usize) < files.len() {
                v.push(dir.join(&files[i as usize].name));
            }
        }
        self.loader.want(&v);
    }

    // ── input ────────────────────────────────────────────────────────

    fn key_name(k: Key) -> Option<String> {
        if k == Key::Space {
            return Some("spc".into());
        }
        let n = k.name();
        let mut ch = n.chars();
        match (ch.next(), ch.next()) {
            (Some(c), None) if c.is_ascii_alphanumeric() => Some(c.to_ascii_lowercase().to_string()),
            _ => None,
        }
    }

    fn keys(&mut self, ctx: &egui::Context, now: f64) {
        let typing = self.typed || ctx.memory(|m| m.focused().is_some());
        let events = ctx.input(|i| i.events.clone());
        for ev in events {
            let Event::Key { key, pressed: true, repeat, modifiers, .. } = ev else { continue };
            if self.cid_edit.is_some() {
                match key {
                    Key::Escape => self.close_cid(false),
                    Key::Enter => self.close_cid(true),
                    _ => {}
                }
                continue;
            }
            if let Dialog::Form(f) = &mut self.dialog
                && f.capturing
            {
                f.capturing = false;
                if key == Key::Escape {
                    continue;
                }
                let Some(n) = Self::key_name(key) else {
                    f.err = Some("Use a letter, a digit or space".into());
                    continue;
                };
                let taken = self.lib.as_ref().and_then(|l| {
                    l.tree.cats.iter().enumerate().find(|(i, c)| Some(*i) != f.edit && c.key.as_deref() == Some(n.as_str()))
                });
                if RESERVED.contains(&n.as_str()) {
                    f.err = Some(format!("{n} is used by the app"));
                } else if let Some((_, c)) = taken {
                    f.err = Some(format!("{n} already throws to {}", c.name));
                } else {
                    f.key = Some(n);
                    f.err = None;
                }
                continue;
            }
            if typing {
                if key == Key::Escape {
                    ctx.memory_mut(|m| {
                        if let Some(id) = m.focused() {
                            m.surrender_focus(id);
                        }
                    });
                }
                continue;
            }
            if !self.s.pin_ui {
                self.quiet = true;
            }
            // The crop tool owns the keyboard while it is up.
            if self.crop.is_some() {
                match key {
                    Key::Enter => self.act(ctx, Act::CropApply, now),
                    Key::Escape => self.crop = None,
                    Key::A => self.act(ctx, Act::Aspect(!modifiers.shift), now),
                    _ => {}
                }
                continue;
            }
            let cmd = modifiers.command;
            let sh = modifiers.shift;
            let steps = |k: Key| match k {
                Key::ArrowLeft => Some(-1),
                Key::ArrowRight => Some(1),
                Key::ArrowUp => Some(-5),
                Key::ArrowDown => Some(5),
                Key::OpenBracket => Some(25),
                Key::CloseBracket => Some(-25),
                Key::Semicolon => Some(50),
                Key::Quote => Some(-50),
                _ => None,
            };
            if let Some(d) = steps(key) {
                self.menu = None;
                self.step(d);
                continue;
            }
            let a = match key {
                Key::Escape if self.menu.is_some() => {
                    self.menu = None;
                    None
                }
                Key::Escape => (!matches!(self.dialog, Dialog::None)).then_some(Act::Close),
                Key::F if modifiers.alt => Some(Act::Menu(Menu::File)),
                Key::E if modifiers.alt => Some(Act::Menu(Menu::Edit)),
                Key::V if modifiers.alt => Some(Act::Menu(Menu::View)),
                Key::H if !cmd => Some(Act::Help),
                Key::Period => Some(Act::Settings),
                Key::Tab => Some(Act::Tree),
                Key::Num0 if !cmd => Some(Act::Fit),
                Key::Num1 if cmd => Some(Act::Actual),
                Key::O if cmd => Some(Act::Open),
                Key::I if cmd => Some(Act::ImportImages),
                Key::S if cmd && sh => Some(Act::ExportAs),
                Key::S if cmd => Some(Act::Save),
                Key::Q if cmd => Some(Act::Quit),
                Key::Z if cmd => Some(Act::Undo),
                Key::K if cmd => Some(Act::CropTool),
                Key::R if cmd => Some(Act::Edit(if sh { Op::RotCcw } else { Op::RotCw })),
                Key::F if cmd => Some(Act::Edit(if sh { Op::FlipV } else { Op::FlipH })),
                Key::Backspace => Some(Act::Undo),
                Key::Delete => Some(Act::Trash),
                _ if !repeat && !cmd && !modifiers.alt => Self::key_name(key).and_then(|n| {
                    self.lib.as_ref().and_then(|l| l.tree.cats.iter().position(|c| c.key.as_deref() == Some(n.as_str()))).map(Act::Throw)
                }),
                _ => None,
            };
            if let Some(a) = a {
                self.act(ctx, a, now);
            }
        }
    }

    fn drops(&mut self, ctx: &egui::Context, now: f64) {
        let dropped: Vec<PathBuf> =
            ctx.input(|i| i.raw.dropped_files.iter().map(|f| f.path().to_path_buf()).filter(|p| !p.as_os_str().is_empty()).collect());
        if dropped.is_empty() {
            return;
        }
        if let Some(d) = dropped.iter().find(|p| p.is_dir()) {
            let d = d.clone();
            self.open_library(&d, now);
            return;
        }
        self.import_files(&dropped, now);
    }

    fn import_files(&mut self, files: &[PathBuf], now: f64) {
        let Some(lib) = self.lib.as_mut() else {
            self.say("Open a folder first", WARN, now);
            return;
        };
        let dir = lib.tree.dir(lib.active);
        let mut n = 0;
        for f in files {
            let name = f.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
            if octo::tree::is_media(&name)
                && let Ok(nm) = ops::copy_into(f, &dir)
            {
                lib.tree.put_file(lib.active, &nm);
                n += 1;
            }
        }
        let into = lib.tree.nodes[lib.active].name.clone();
        self.say(format!("Imported {n} into {into}"), MUTED, now);
    }

    // ── actions ──────────────────────────────────────────────────────

    fn act(&mut self, ctx: &egui::Context, a: Act, now: f64) {
        if !matches!(a, Act::Menu(_)) {
            self.menu = None;
        }
        match a {
            Act::Menu(m) => self.menu = if self.menu == Some(m) { None } else { Some(m) },
            Act::Settings => self.dialog = if matches!(self.dialog, Dialog::Settings) { Dialog::None } else { Dialog::Settings },
            Act::Help => self.dialog = if matches!(self.dialog, Dialog::Help) { Dialog::None } else { Dialog::Help },
            Act::Close => {
                self.dialog = match self.dialog {
                    Dialog::Form(_) => Dialog::Settings,
                    _ => Dialog::None,
                }
            }
            Act::Open => {
                if let Some(d) = rfd::FileDialog::new().set_title("Open folder").pick_folder() {
                    self.open_library(&d, now);
                }
            }
            Act::ImportImages => {
                let ex: Vec<&str> = IMAGES.iter().chain(OTHER_MEDIA).copied().collect();
                if let Some(fs) = rfd::FileDialog::new().set_title("Import images").add_filter("Images and video", &ex).pick_files() {
                    self.import_files(&fs, now);
                }
            }
            Act::Save => {
                if let Some(p) = self.current() {
                    self.save(&p, now);
                }
            }
            Act::SaveAll => {
                self.save_all(now);
            }
            Act::ExportAs => self.export_as(now),
            Act::Revert => {
                if let Some(p) = self.current() {
                    self.pending.remove(&p);
                    self.undo.retain(|u| !matches!(u, Undo::Op { path } if *path == p));
                }
            }
            Act::ImportCats => self.import_categories(now),
            Act::ExportCats | Act::Manifest | Act::ExportSet => self.export(a, now),
            Act::Quit => ctx.send_viewport_cmd(ViewportCommand::Close),
            Act::Undo => self.undo(ctx, now),
            Act::CropTool => {
                if self.crop.is_some() {
                    self.crop = None;
                } else {
                    self.start_crop();
                }
            }
            Act::Edit(op) => self.push_op(ctx, op, now),
            Act::Trash => self.trash(now),
            Act::Tree => self.s.tree = !self.s.tree,
            Act::Fit => self.reset_view(),
            Act::Actual => {
                if let (Some(r), Some(f)) = (self.img_rect, self.current_px()) {
                    self.zoom *= f[0] as f32 / r.width();
                    self.pan = Vec2::ZERO;
                }
            }
            Act::Style(fwd) => self.s.style = if fwd { (self.s.style + 1) % 3 } else { (self.s.style + 2) % 3 },
            Act::Pin => self.s.pin_ui = !self.s.pin_ui,
            Act::Title => self.s.title = !self.s.title,
            Act::Font(fwd) => self.s.font = if fwd { (self.s.font + 1) % 12 } else { (self.s.font + 11) % 12 },
            Act::Size(fwd) => {
                let n = SIZES.len();
                self.s.size = if fwd { (self.s.size + 1) % n } else { (self.s.size + n - 1) % n };
                self.hold_frames = 3;
            }
            Act::EditCat(i) => {
                if let Some(c) = self.lib.as_ref().and_then(|l| l.tree.cats.get(i)).cloned() {
                    self.dialog =
                        Dialog::Form(Form { edit: Some(i), name: c.name, key: c.key, cid: hexs(c.cid), tier: c.tier, capturing: false, err: None });
                }
            }
            Act::NewCat => {
                let used: Vec<String> =
                    self.lib.as_ref().map(|l| l.tree.cats.iter().map(|c| hexs(c.cid).to_lowercase()).collect()).unwrap_or_default();
                let cid = SWATCHES.iter().find(|s| !used.contains(&s.to_lowercase())).unwrap_or(&SWATCHES[0]);
                self.dialog =
                    Dialog::Form(Form { edit: None, name: String::new(), key: None, cid: cid.to_string(), tier: 'c', capturing: false, err: None });
            }
            Act::FormKey => {
                if let Dialog::Form(f) = &mut self.dialog {
                    f.capturing = true;
                    f.err = None;
                }
                ctx.memory_mut(|m| {
                    if let Some(id) = m.focused() {
                        m.surrender_focus(id);
                    }
                });
            }
            Act::Swatch(fwd) => {
                if let Dialog::Form(f) = &mut self.dialog {
                    let n = SWATCHES.len();
                    let i = SWATCHES.iter().position(|s| s.eq_ignore_ascii_case(&f.cid)).unwrap_or(0);
                    f.cid = SWATCHES[if fwd { (i + 1) % n } else { (i + n - 1) % n }].to_string();
                }
            }
            Act::Tier(fwd) => {
                if let Dialog::Form(f) = &mut self.dialog {
                    let t = f.tier as u8;
                    f.tier = if fwd { t.saturating_add(1).min(b'z') as char } else { t.saturating_sub(1).max(b'a') as char };
                }
            }
            Act::FormSave => self.save_form(),
            Act::FormDelete => {
                if let Dialog::Form(f) = &self.dialog
                    && let Some(i) = f.edit
                    && let Some(lib) = self.lib.as_mut()
                {
                    lib.tree.cats.remove(i);
                    lib.tree.recat();
                    let _ = config::save(&lib.tree.root, &lib.tree.cats);
                    self.flash = None;
                    self.fly.clear();
                }
                self.dialog = Dialog::Settings;
            }
            Act::FormCancel => self.dialog = Dialog::Settings,
            Act::SaveAllQuit => {
                if self.save_all(now) {
                    self.quitting = true;
                    ctx.send_viewport_cmd(ViewportCommand::Close);
                }
            }
            Act::DiscardQuit => {
                self.pending.clear();
                self.quitting = true;
                ctx.send_viewport_cmd(ViewportCommand::Close);
            }
            Act::Aspect(fwd) => {
                let px = self.current_px();
                if let Some(c) = self.crop.as_mut() {
                    let n = ASPECTS.len();
                    c.aspect = if fwd { (c.aspect + 1) % n } else { (c.aspect + n - 1) % n };
                    c.r = [0.0, 0.0, 1.0, 1.0];
                    let a = ASPECTS[c.aspect].1;
                    if let Some(px) = px
                        && a > 0.0
                    {
                        // Largest centred rect of that ratio.
                        let img = px[0] as f32 / px[1] as f32;
                        if a > img {
                            let h = img / a;
                            c.r = [0.0, (1.0 - h) / 2.0, 1.0, (1.0 + h) / 2.0];
                        } else {
                            let w = a / img;
                            c.r = [(1.0 - w) / 2.0, 0.0, (1.0 + w) / 2.0, 1.0];
                        }
                    }
                }
            }
            Act::CropApply => {
                if let Some(c) = self.crop.take()
                    && c.r != [0.0, 0.0, 1.0, 1.0]
                {
                    self.push_op(ctx, Op::Crop(c.r), now);
                }
            }
            Act::CropCancel => self.crop = None,
            Act::Throw(c) => self.classify(c, now),
            Act::CidEdit(_) => {}
        }
    }

    fn import_categories(&mut self, now: f64) {
        let Some(lib) = self.lib.as_mut() else { return };
        let Some(f) = rfd::FileDialog::new().set_title("Import categories").pick_file() else { return };
        let cats = std::fs::read_to_string(&f).map(|t| config::parse(&t)).unwrap_or_default();
        if cats.is_empty() {
            self.say("That file has no categories in it", WARN, now);
            return;
        }
        lib.tree.cats = cats;
        lib.tree.recat();
        let _ = config::save(&lib.tree.root, &lib.tree.cats);
        self.flash = None;
        self.fly.clear();
    }

    fn export(&mut self, what: Act, now: f64) {
        let Some(lib) = self.lib.as_ref() else { return };
        let r = match what {
            Act::Manifest => rfd::FileDialog::new()
                .set_file_name("calamari_manifest.csv")
                .save_file()
                .map(|p| std::fs::write(&p, ops::manifest(&lib.tree)).map(|_| format!("Exported manifest to {}", p.display()))),
            Act::ExportCats => rfd::FileDialog::new()
                .set_file_name("categories.calamari")
                .save_file()
                .map(|p| std::fs::write(&p, config::to_text(&lib.tree.cats)).map(|_| format!("Exported categories to {}", p.display()))),
            _ => rfd::FileDialog::new()
                .set_title("Export sorted set")
                .pick_folder()
                .map(|d| ops::export_set(&lib.tree, &d).map(|n| format!("Copied {n} sorted files to {}", d.display()))),
        };
        match r {
            Some(Ok(m)) => self.say(m, MUTED, now),
            Some(Err(e)) => self.say(format!("Couldn't export: {e}"), WARN, now),
            None => {}
        }
    }

    fn save_form(&mut self) {
        let Dialog::Form(f) = &mut self.dialog else { return };
        let name = f.name.trim().to_string();
        if name.is_empty() || name.contains(|c: char| c.is_whitespace() || "/\\:*?\"<>|".contains(c)) {
            f.err = Some("Name it like a folder, without spaces".into());
            return;
        }
        let Some(cid) = config::hex(&f.cid) else {
            f.err = Some("Colour must be #RRGGBB".into());
            return;
        };
        let Some(lib) = self.lib.as_mut() else {
            f.err = Some("Open a folder first".into());
            return;
        };
        if lib.tree.cats.iter().enumerate().any(|(i, c)| Some(i) != f.edit && c.name == name) {
            f.err = Some(format!("{name} already exists"));
            return;
        }
        let cat = Cat { key: f.key.clone(), name, cid, tier: f.tier };
        match f.edit {
            Some(i) => lib.tree.cats[i] = cat,
            None => lib.tree.cats.push(cat),
        }
        lib.tree.recat();
        if let Err(e) = config::save(&lib.tree.root, &lib.tree.cats) {
            f.err = Some(format!("Kept for this session; couldn't write .calamari: {e}"));
            return;
        }
        self.dialog = Dialog::Settings;
    }

    // ── chrome ───────────────────────────────────────────────────────

    /// The menu bar: logo, menus with their Alt letter lit, and on the
    /// right anything unsaved and the library path.
    fn menubar(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32) -> Option<Act> {
        let h = g.rh * 1.5;
        let slide = (1.0 - alpha) * h * 0.5;
        if alpha < 0.01 {
            return None;
        }
        let mut act = None;
        let mut hovered = false;
        let mut spots: Vec<(f32, f32, Act)> = Vec::new();
        let titles: [(&str, Act, bool); 5] = [
            ("File", Act::Menu(Menu::File), self.menu == Some(Menu::File)),
            ("Edit", Act::Menu(Menu::Edit), self.menu == Some(Menu::Edit)),
            ("View", Act::Menu(Menu::View), self.menu == Some(Menu::View)),
            ("Settings", Act::Settings, matches!(self.dialog, Dialog::Settings | Dialog::Form(_))),
            ("Help", Act::Help, matches!(self.dialog, Dialog::Help)),
        ];
        let mut right: Vec<Run> = Vec::new();
        if !self.pending.is_empty() {
            right.push(run(format!("{} unsaved", self.pending.len()), RUST_HI));
            right.push(run("   ", DIM));
        }
        if let Some(l) = &self.lib {
            right.push(run(l.tree.root.display().to_string(), DIM));
        }
        Area::new(Id::new("menubar"))
            .fixed_pos(full.min - Vec2::new(0.0, slide))
            .order(Order::Foreground)
            .interactable(alpha > 0.05)
            .show(ctx, |ui| {
                let (rect, resp) = ui.allocate_exact_size(Vec2::new(full.width(), h), Sense::click());
                let p = ui.painter();
                p.rect_filled(rect, 0.0, IRON.gamma_multiply(alpha));
                p.line_segment([rect.left_bottom(), rect.right_bottom()], Stroke::new(1.0, EDGE.gamma_multiply(alpha)));
                let y = rect.top() + (h - g.rh) * 0.5;
                let mut x = rect.left() + g.cw;
                g.line(p, Pos2::new(x, y), &[("◙ ".into(), RUST_HI), ("Rusted Calamari".into(), TEXT)], alpha);
                x += g.cw * 20.0;
                let hover = resp.hover_pos();
                for (t, a, open) in titles {
                    let w = (t.chars().count() + 2) as f32 * g.cw;
                    let cell = Rect::from_min_size(Pos2::new(x, rect.top()), Vec2::new(w, h));
                    let hot = hover.is_some_and(|q| cell.contains(q));
                    if open || hot {
                        p.rect_filled(cell, 0.0, (if open { RUST } else { IRON_HI }).gamma_multiply(alpha));
                    }
                    let first: String = t.chars().take(1).collect();
                    let rest: String = t.chars().skip(1).collect();
                    let menu = matches!(a, Act::Menu(_));
                    // The Alt letter is lit on the three Alt menus.
                    let lit = match (open, menu) {
                        (true, _) => STAGE,
                        (false, true) => RUST_HI,
                        (false, false) => TEXT,
                    };
                    g.line(p, Pos2::new(x + g.cw, y), &[(first, lit), (rest, if open { STAGE } else { TEXT })], alpha);
                    spots.push((x, x + w, a));
                    x += w;
                }
                let rw = Grid::cols(&right) as f32 * g.cw;
                let rx = (rect.right() - rw - g.cw).max(x + g.cw * 3.0);
                g.line(&p.with_clip_rect(Rect::from_min_max(Pos2::new(x + g.cw, rect.top()), rect.max)), Pos2::new(rx, y), &right, alpha);
                if resp.clicked()
                    && let Some(q) = resp.interact_pointer_pos()
                {
                    act = spots.iter().find(|(a, b, _)| q.x >= *a && q.x < *b).map(|s| s.2);
                }
                hovered = resp.contains_pointer();
            });
        self.chrome_hover |= hovered;
        if let Some(m) = self.menu {
            let x = spots.iter().find(|s| s.2 == Act::Menu(m)).map_or(full.left(), |s| s.0);
            let items = self.menu_items(m);
            let o = dropdown(ctx, g, "dropdown", Pos2::new(x, full.top() + h - slide), &items, alpha);
            self.chrome_hover |= o.hovered;
            if o.click.is_some() {
                return o.click;
            }
        }
        act
    }

    fn menu_items(&self, m: Menu) -> Vec<Item<Act>> {
        let has_img = self.current().is_some();
        let dirty = self.current().is_some_and(|p| self.pending.contains_key(&p));
        let lib = self.lib.is_some();
        let it = |label: &str, key: &str, act: Act, on: bool| Item::Act { label: label.into(), key: key.into(), act, on };
        match m {
            Menu::File => vec![
                it("Open folder...", "Ctrl+O", Act::Open, true),
                it("Import images...", "Ctrl+I", Act::ImportImages, lib),
                Item::Rule,
                it("Save", "Ctrl+S", Act::Save, dirty),
                it("Save all", "", Act::SaveAll, !self.pending.is_empty()),
                it("Export as...", "Ctrl+Shift+S", Act::ExportAs, has_img),
                it("Revert edits", "", Act::Revert, dirty),
                Item::Rule,
                it("Import categories...", "", Act::ImportCats, lib),
                it("Export categories...", "", Act::ExportCats, lib),
                it("Export manifest...", "", Act::Manifest, lib),
                it("Export sorted set...", "", Act::ExportSet, lib),
                Item::Rule,
                it("Quit", "Ctrl+Q", Act::Quit, true),
            ],
            Menu::Edit => vec![
                it("Undo", "Ctrl+Z", Act::Undo, !self.undo.is_empty()),
                Item::Rule,
                it("Crop...", "Ctrl+K", Act::CropTool, has_img),
                it("Rotate right", "Ctrl+R", Act::Edit(Op::RotCw), has_img),
                it("Rotate left", "Ctrl+Shift+R", Act::Edit(Op::RotCcw), has_img),
                it("Flip horizontal", "Ctrl+F", Act::Edit(Op::FlipH), has_img),
                it("Flip vertical", "Ctrl+Shift+F", Act::Edit(Op::FlipV), has_img),
                Item::Rule,
                it("Move to trash", "Del", Act::Trash, has_img),
            ],
            Menu::View => vec![
                it(if self.s.tree { "Fold the tree" } else { "Unfold the tree" }, "Tab", Act::Tree, lib),
                it("Fit to window", "0", Act::Fit, has_img),
                it("Actual size", "Ctrl+1", Act::Actual, has_img),
                Item::Rule,
                it(if self.s.title { "Hide the title" } else { "Show the title" }, "", Act::Title, has_img),
                it(&format!("Tree style: {}", STYLE_NAMES[self.s.style % 3]), "", Act::Style(true), true),
                it(if self.s.pin_ui { "Let the interface fade" } else { "Pin the interface" }, "", Act::Pin, true),
            ],
        }
    }

    /// Status line: where you are on the left, the slots on the right. The
    /// slot chips are throw targets for the mouse and landing marks for the
    /// keyboard. Their positions are kept even while the line is hidden.
    fn statusbar(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32) -> Option<Act> {
        let h = g.rh * 1.5;
        let Some(lib) = self.lib.as_ref() else {
            self.chips.clear();
            return None;
        };
        let n = &lib.tree.nodes[lib.active];
        let sep = || run(" │ ", EDGE);
        let mut left: Vec<Run> = vec![run(n.name.clone(), RUST_HI)];
        if let Some(f) = n.files.get(lib.cursor) {
            let path = lib.tree.dir(lib.active).join(&f.name);
            left.push(sep());
            left.push(run(format!("{} of {}", lib.cursor + 1, n.files.len()), MUTED));
            left.push(sep());
            left.push(run(f.name.clone(), TEXT));
            if let Some(px) = self.current_px() {
                left.push(sep());
                left.push(run(format!("{}x{}", px[0], px[1]), MUTED));
            }
            if let Some(Slot::Ready { bytes, .. }) = self.loader.get(&path) {
                left.push(sep());
                left.push(run(format!("{:.1} MB", *bytes as f64 / 1_048_576.0), MUTED));
            }
            left.push(sep());
            left.push(run(if (self.zoom - 1.0).abs() < 0.01 { "fit".to_string() } else { format!("{:.0}%", self.zoom * 100.0) }, MUTED));
            if self.pending.contains_key(&path) {
                left.push(sep());
                left.push(run("edited, not saved", RUST_HI));
            }
        }
        let cats: Vec<(usize, String, String, Color32)> =
            lib.tree.cats.iter().enumerate().filter_map(|(i, c)| c.key.clone().map(|k| (i, k, c.name.clone(), rgb(c.cid)))).collect();
        let chip_w = |k: &str, nm: &str| (k.chars().count() + nm.chars().count() + 4) as f32 * g.cw;
        let rw: f32 = cats.iter().map(|(_, k, nm, _)| chip_w(k, nm) + g.cw).sum();
        let y0 = full.bottom() - h;
        let start = full.right() - rw - g.cw;
        let mut x = start;
        self.chips = cats
            .iter()
            .map(|(i, k, nm, _)| {
                let w = chip_w(k, nm);
                let c = Pos2::new(x + w * 0.5, y0 + h * 0.5);
                x += w + g.cw;
                (*i, c)
            })
            .collect();
        if alpha < 0.01 {
            return None;
        }
        let slide = (1.0 - alpha) * h * 0.5;
        let mut act = None;
        let mut hovered = false;
        Area::new(Id::new("statusbar"))
            .fixed_pos(Pos2::new(full.left(), y0 + slide))
            .order(Order::Foreground)
            .interactable(alpha > 0.05)
            .show(ctx, |ui| {
                let (rect, resp) = ui.allocate_exact_size(Vec2::new(full.width(), h), Sense::click());
                let p = ui.painter();
                p.rect_filled(rect, 0.0, IRON.gamma_multiply(alpha));
                p.line_segment([rect.left_top(), rect.right_top()], Stroke::new(1.0, EDGE.gamma_multiply(alpha)));
                let y = rect.top() + (h - g.rh) * 0.5;
                let clip = Rect::from_min_max(rect.min, Pos2::new(start - g.cw * 2.0, rect.bottom()));
                g.line(&p.with_clip_rect(clip), Pos2::new(rect.left() + g.cw, y), &left, alpha);
                let hover = resp.hover_pos();
                let mut x = start;
                for (i, k, nm, c) in &cats {
                    let w = chip_w(k, nm);
                    let cell = Rect::from_min_size(Pos2::new(x, rect.top() + 3.0), Vec2::new(w, h - 6.0));
                    let hot = hover.is_some_and(|q| cell.contains(q));
                    p.rect_filled(cell, 2.0, (if hot { IRON_HI } else { STAGE }).gamma_multiply(alpha));
                    let kw = (k.chars().count() + 2) as f32 * g.cw;
                    p.rect_filled(Rect::from_min_size(cell.min, Vec2::new(kw, cell.height())), 2.0, c.gamma_multiply(alpha));
                    g.line(p, Pos2::new(x, y), &[(format!(" {k} "), STAGE), (format!(" {nm}"), *c)], alpha);
                    if resp.clicked()
                        && let Some(q) = resp.interact_pointer_pos()
                        && cell.contains(q)
                    {
                        act = Some(Act::Throw(*i));
                    }
                    if hot {
                        ctx.set_cursor_icon(CursorIcon::PointingHand);
                    }
                    x += w + g.cw;
                }
                hovered = resp.contains_pointer();
            });
        self.chrome_hover |= hovered;
        act
    }

    /// The fold tab on the tree's edge: `<` folds the tree away, `>` brings
    /// it back. It comes and goes with the rest of the interface.
    fn fold_tab(&mut self, ctx: &egui::Context, g: &Grid, edge_x: f32, mid_y: f32, alpha: f32) -> Option<Act> {
        if alpha < 0.01 {
            return None;
        }
        let mut act = None;
        let size = Vec2::new(g.cw * 1.8, g.rh * 3.0);
        let glyph = if self.s.tree { "<" } else { ">" };
        // Centred on the divider; flush to the window edge when folded.
        let x = (edge_x - size.x * 0.5).max(0.0);
        Area::new(Id::new("fold-tab"))
            .fixed_pos(Pos2::new(x, mid_y - size.y * 0.5))
            .order(Order::Foreground)
            .interactable(alpha > 0.05)
            .show(ctx, |ui| {
                let (rect, resp) = ui.allocate_exact_size(size, Sense::click());
                let p = ui.painter();
                let hot = resp.hovered();
                p.rect_filled(rect.translate(Vec2::new(2.0, 3.0)), 2.0, SHADOW.gamma_multiply(alpha));
                p.rect_filled(rect, 2.0, (if hot { RUST } else { IRON }).gamma_multiply(alpha));
                p.rect_stroke(rect, 2.0, Stroke::new(1.0, EDGE.gamma_multiply(alpha)), StrokeKind::Inside);
                g.text(p, rect.center() - Vec2::new(g.cw * 0.5, g.rh * 0.5), glyph, if hot { STAGE } else { RUST_HI }, alpha);
                if hot {
                    ctx.set_cursor_icon(CursorIcon::PointingHand);
                }
                if resp.clicked() {
                    act = Some(Act::Tree);
                }
                self.chrome_hover |= resp.contains_pointer();
            });
        act
    }

    fn settings_dialog(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32) -> Option<Act> {
        let cats: Vec<Cat> = self.lib.as_ref().map(|l| l.tree.cats.clone()).unwrap_or_else(config::defaults);
        let active = self.lib.as_ref().map(|l| l.tree.path(l.active)).unwrap_or_else(|| "-".into());
        let tick = |b: bool| if b { "[x]" } else { "[ ]" };
        let spin = |label: &str, value: String, prev: Act, next: Act| -> Row<Act> {
            Row::new(vec![r(format!("├─ {label:<6} "), DIM), ra("◄", RUST_HI, prev), r(format!(" {value} "), TEXT), ra("►", RUST_HI, next)])
        };
        let mut rows: Vec<Row<Act>> = vec![
            Row::new(vec![r("[settings]", RUST_HI), r(":style: ", DIM), r(format!("\"{}\"", STYLE_NAMES[self.s.style % 3]), TEXT)]),
            Row::act(vec![r("├─ ", DIM), r(tick(self.s.pin_ui), RUST_HI), r(" PIN_UI: Turn Active UI Fade OFF", TEXT)], Act::Pin),
            Row::act(vec![r("├─ ", DIM), r(tick(self.s.tree), RUST_HI), r(" Octobrachial Tree beside the image", TEXT), r("   Tab", DIM)], Act::Tree),
            Row::act(vec![r("├─ ", DIM), r(tick(self.s.title), RUST_HI), r(" Title over the image", TEXT), r("   folder and number", DIM)], Act::Title),
            spin("font", FACES[self.s.font % 12].name.to_string(), Act::Font(false), Act::Font(true)),
            spin("size", format!("{}", SIZES[self.s.size % SIZES.len()]), Act::Size(false), Act::Size(true)),
            spin("style", STYLE_NAMES[self.s.style % 3].to_string(), Act::Style(false), Act::Style(true)),
            Row::new(vec![r("└─ ", DIM), r("[create]", RUST_HI)]),
            Row::new(vec![r("   └─ ", DIM), r("[classification_category] ", TEXT), r(active, MUTED)]),
        ];
        for (i, c) in cats.iter().enumerate() {
            // The key as a keycap in its category's colour; the colour itself
            // edits in place on a double-click.
            let (key, kw) = match &c.key {
                Some(k) => (chip(format!(" {k} "), STAGE, rgb(c.cid)), k.chars().count() + 2),
                None => (r(" - ", DIM), 3),
            };
            rows.push(Row::act(
                vec![
                    r("      ├─ ", DIM),
                    r(format!("{}.", c.tier), MUTED),
                    r(format!("{:<10}", format!("[{}]", c.name)), rgb(c.cid)),
                    r(" ", DIM),
                    key,
                    r(" ".repeat(7 - kw.min(6)), DIM),
                    rd(hexs(c.cid), MUTED, Act::CidEdit(i)),
                    r(" ", DIM),
                    rd("████", rgb(c.cid), Act::CidEdit(i)),
                ],
                Act::EditCat(i),
            ));
        }
        rows.push(Row::act(vec![r("      └─ ", DIM), r("+ category", RUST_HI)], Act::NewCat));
        rows.push(Row::blank());
        rows.push(Row::new(vec![r("Double-click a colour to change it.", DIM)]));
        let size = theme::dialog_size(g, "Settings", &rows, 0);
        let pos = Pos2::new(full.center().x - size.x * 0.5, full.top() + g.rh * 3.0);
        let o = dialog(ctx, g, "settings", pos, "Settings", &rows, 0, alpha, Act::Close, |_, _| {});
        self.chrome_hover |= o.hovered;
        if let Some((Act::CidEdit(i), at)) = o.double
            && let Some(c) = self.lib.as_ref().and_then(|l| l.tree.cats.get(i))
        {
            self.cid_edit = Some(CidEdit { cat: i, at, orig: c.cid, hex: hexs(c.cid), opened: ctx.input(|x| x.time) });
        }
        o.click
    }

    fn close_cid(&mut self, keep: bool) {
        let Some(ed) = self.cid_edit.take() else { return };
        let Some(lib) = self.lib.as_mut() else { return };
        if let Some(c) = lib.tree.cats.get_mut(ed.cat) {
            if !keep {
                c.cid = ed.orig;
            } else if c.cid != ed.orig {
                let _ = config::save(&lib.tree.root, &lib.tree.cats);
            }
        }
    }

    /// The in-place colour editor under a double-clicked colour: hex field,
    /// picker, swatches. Every change lands on the category at once, so the
    /// tree, the keycaps and the status chips recolour while you drag.
    fn cid_editor(&mut self, ctx: &egui::Context, g: &Grid, now: f64) {
        if !matches!(self.dialog, Dialog::Settings) {
            self.close_cid(true);
            return;
        }
        let (Some(ed), Some(lib)) = (self.cid_edit.as_mut(), self.lib.as_mut()) else { return };
        let Some(cat) = lib.tree.cats.get(ed.cat).cloned() else {
            self.cid_edit = None;
            return;
        };
        let mut c = rgb(cat.cid);
        let (mut done, mut revert) = (false, false);
        let font = g.font.clone();
        let button = |ui: &mut egui::Ui, t: &str, col: Color32| {
            let r = ui.add(egui::Label::new(egui::RichText::new(t).font(font.clone()).color(col)).sense(Sense::click()));
            if r.hovered() {
                ui.painter().rect_filled(r.rect.expand(1.0), 3.0, RUST);
                ui.painter().text(r.rect.left_top(), egui::Align2::LEFT_TOP, t, font.clone(), STAGE);
                ui.ctx().set_cursor_icon(CursorIcon::PointingHand);
            }
            r.clicked()
        };
        let area = Area::new(Id::new("cid-edit"))
            .fixed_pos(ed.at.left_bottom() + Vec2::new(-g.cw, 6.0))
            .order(Order::Tooltip)
            .show(ctx, |ui| {
                egui::Frame::NONE
                    .fill(IRON)
                    .stroke(Stroke::new(RULE, EDGE))
                    .corner_radius(ROUND)
                    .inner_margin(egui::Margin::same(12))
                    .shadow(theme::shadow(1.0))
                    .show(ui, |ui| {
                        ui.spacing_mut().slider_width = g.cw * 20.0;
                        ui.horizontal(|ui| {
                            ui.label(egui::RichText::new(format!("[{}]", cat.name)).font(font.clone()).color(c));
                            ui.add_space(g.cw);
                            let te = ui.add(
                                TextEdit::singleline(&mut ed.hex).font(font.clone()).text_color(TEXT).desired_width(g.cw * 8.0).background_color(STAGE),
                            );
                            if te.changed()
                                && let Some(h) = config::hex(&ed.hex)
                            {
                                c = rgb(h);
                            }
                            if te.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)) {
                                done = true;
                            }
                        });
                        ui.add_space(8.0);
                        if egui::widgets::color_picker::color_picker_color32(ui, &mut c, egui::widgets::color_picker::Alpha::Opaque) {
                            ed.hex = format!("#{:02X}{:02X}{:02X}", c.r(), c.g(), c.b());
                        }
                        ui.add_space(8.0);
                        ui.horizontal(|ui| {
                            for sw in SWATCHES {
                                let sc = config::hex(sw).map_or(MUTED, rgb);
                                let (r, resp) = ui.allocate_exact_size(Vec2::splat(g.rh * 0.9), Sense::click());
                                ui.painter().rect_filled(r, 3.0, sc);
                                if resp.hovered() || sc == c {
                                    ui.painter().rect_stroke(r, 3.0, Stroke::new(1.5, TEXT), StrokeKind::Outside);
                                }
                                if resp.clicked() {
                                    c = sc;
                                    ed.hex = sw.to_uppercase();
                                }
                            }
                        });
                        ui.add_space(10.0);
                        ui.horizontal(|ui| {
                            done |= button(ui, "[ Done ]", RUST_HI);
                            ui.add_space(g.cw);
                            revert |= button(ui, "[ Revert ]", MUTED);
                        });
                    });
            });
        // Live: the category takes the colour now.
        if let Some(k) = lib.tree.cats.get_mut(ed.cat) {
            k.cid = (c.r(), c.g(), c.b());
        }
        self.chrome_hover |= area.response.contains_pointer();
        let outside = ctx.input(|i| i.pointer.primary_clicked())
            && now > ed.opened
            && !ctx.input(|i| i.pointer.interact_pos()).is_some_and(|p| area.response.rect.contains(p));
        if revert {
            self.close_cid(false);
        } else if done || outside {
            self.close_cid(true);
        }
    }

    fn form_dialog(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32) -> Option<Act> {
        let Dialog::Form(f) = &mut self.dialog else { return None };
        let cid = config::hex(&f.cid);
        let title = if f.edit.is_some() { "Edit category" } else { "New category" };
        let mut rows: Vec<Row<Act>> = vec![
            Row::new(vec![r("├─ name   ", DIM), r(" ".repeat(20), TEXT)]),
            Row::act(
                vec![
                    r("├─ key    ", DIM),
                    match (&f.key, f.capturing) {
                        (_, true) => r("press a key", RUST_HI),
                        (Some(k), false) => chip(format!(" {k} "), STAGE, cid.map_or(MUTED, rgb)),
                        (None, false) => r(" - ", DIM),
                    },
                    r(if f.capturing { "" } else { "   click, then press the key" }, DIM),
                ],
                Act::FormKey,
            ),
            Row::new(vec![
                r("├─ colour ", DIM),
                r(" ".repeat(9), TEXT),
                r(" ████  ", cid.map_or(WARN, rgb)),
                ra("◄", RUST_HI, Act::Swatch(false)),
                r(" swatch ", MUTED),
                ra("►", RUST_HI, Act::Swatch(true)),
            ]),
            Row::new(vec![
                r("├─ tier   ", DIM),
                ra("◄", RUST_HI, Act::Tier(false)),
                r(format!(" {} ", f.tier), TEXT),
                ra("►", RUST_HI, Act::Tier(true)),
                r("   a sorts first", DIM),
            ]),
            Row::blank(),
        ];
        let mut buttons = vec![r("└─ ", DIM), ra("[ Save ]", RUST_HI, Act::FormSave), r("  ", DIM)];
        if f.edit.is_some() {
            buttons.push(ra("[ Delete ]", WARN, Act::FormDelete));
            buttons.push(r("  ", DIM));
        }
        buttons.push(ra("[ Cancel ]", MUTED, Act::FormCancel));
        rows.push(Row::new(buttons));
        rows.push(Row::new(vec![r(format!("   {}", f.err.clone().unwrap_or_default()), WARN)]));
        let size = theme::dialog_size(g, title, &rows, 44);
        let pos = Pos2::new(full.center().x - size.x * 0.5, full.top() + g.rh * 3.0);
        let font = g.font.clone();
        let (name_ref, cid_ref) = (&mut f.name, &mut f.cid);
        let o = dialog(ctx, g, "form", pos, title, &rows, 44, alpha, Act::Close, |ui, o| {
            let field = |row: usize, col: usize, w: usize| Rect::from_min_size(o + Vec2::new(col as f32 * g.cw, row as f32 * g.rh), g.size(w, 1));
            theme::field_bg(ui.painter(), field(0, 10, 20));
            theme::field_bg(ui.painter(), field(2, 10, 9));
            ui.put(field(0, 10, 20), TextEdit::singleline(name_ref).font(font.clone()).text_color(TEXT).frame(egui::Frame::NONE).margin(Vec2::ZERO));
            ui.put(field(2, 10, 9), TextEdit::singleline(cid_ref).font(font.clone()).text_color(TEXT).frame(egui::Frame::NONE).margin(Vec2::ZERO));
        });
        self.chrome_hover |= o.hovered;
        o.click
    }

    fn help_dialog(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32) -> Option<Act> {
        let cats: Vec<Cat> = self.lib.as_ref().map(|l| l.tree.cats.clone()).unwrap_or_else(config::defaults);
        let mut rows: Vec<Row<Act>> = vec![Row::new(vec![r("Sort", RUST_HI)])];
        for c in &cats {
            if let Some(k) = &c.key {
                rows.push(Row::new(vec![r(format!("  {k:<16}"), TEXT), r(format!("throw into {}", c.name), rgb(c.cid))]));
            }
        }
        let sec = |rows: &mut Vec<Row<Act>>, head: &str, items: &[(&str, &str)]| {
            rows.push(Row::blank());
            rows.push(Row::new(vec![r(head.to_string(), RUST_HI)]));
            for (k, d) in items {
                rows.push(Row::new(vec![r(format!("  {k:<16}"), TEXT), r(d.to_string(), MUTED)]));
            }
        };
        sec(&mut rows, "Browse", &[("← →", "one back, one on"), ("↑ ↓", "five back, five on"), ("[ ]", "25 on, 25 back"), ("; '", "50 on, 50 back")]);
        sec(
            &mut rows,
            "Edit",
            &[
                ("Ctrl+K", "crop; Enter applies, A changes the ratio"),
                ("Ctrl+R", "rotate right; with Shift, left"),
                ("Ctrl+F", "flip; with Shift, vertical"),
                ("Ctrl+S", "save edits into the file"),
                ("Ctrl+Shift+S", "export as a new file"),
                ("Ctrl+Z", "undo"),
                ("Del", "move to trash"),
            ],
        );
        sec(
            &mut rows,
            "View",
            &[("Tab", "fold or unfold the tree"), ("wheel, drag", "zoom, pan"), ("0", "fit to window"), ("Ctrl+1", "actual size"), (".", "settings")],
        );
        sec(&mut rows, "Tree", &[("click a folder", "sort from it; again to fold"), ("click a slot", "throw the image into it"), ("right-click", "browse what a slot holds")]);
        let size = theme::dialog_size(g, "Keys", &rows, 0);
        let pos = Pos2::new(full.center().x - size.x * 0.5, (full.center().y - size.y * 0.5).max(full.top() + g.rh * 2.0));
        let o = dialog(ctx, g, "help", pos, "Keys", &rows, 0, alpha, Act::Close, |_, _| {});
        self.chrome_hover |= o.hovered;
        o.click
    }

    fn unsaved_dialog(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32) -> Option<Act> {
        let n = self.pending.len();
        let rows: Vec<Row<Act>> = vec![
            Row::new(vec![r(format!("{n} image{} {} edits that aren't saved.", if n == 1 { "" } else { "s" }, if n == 1 { "has" } else { "have" }), TEXT)]),
            Row::blank(),
            Row::new(vec![
                ra("[ Save all and quit ]", RUST_HI, Act::SaveAllQuit),
                r("  ", DIM),
                ra("[ Quit without saving ]", WARN, Act::DiscardQuit),
                r("  ", DIM),
                ra("[ Cancel ]", MUTED, Act::Close),
            ]),
        ];
        let size = theme::dialog_size(g, "Unsaved edits", &rows, 0);
        dialog(ctx, g, "unsaved", full.center() - size * 0.5, "Unsaved edits", &rows, 0, alpha, Act::Close, |_, _| {}).click
    }

    fn crop_bar(&mut self, ctx: &egui::Context, g: &Grid, stage: Rect, alpha: f32) -> Option<Act> {
        let c = self.crop.as_ref()?;
        let rows = vec![Row::new(vec![
            r("Ratio ", MUTED),
            ra("◄", RUST_HI, Act::Aspect(false)),
            r(format!(" {:<8} ", ASPECTS[c.aspect].0), TEXT),
            ra("►", RUST_HI, Act::Aspect(true)),
            r("     ", DIM),
            ra("[ Apply ]", RUST_HI, Act::CropApply),
            r("  ", DIM),
            ra("[ Cancel ]", MUTED, Act::CropCancel),
        ])];
        let size = theme::dialog_size(g, "Crop", &rows, 0);
        let pos = Pos2::new(stage.center().x - size.x * 0.5, stage.bottom() - size.y - g.rh * 2.5);
        dialog(ctx, g, "cropbar", pos, "Crop", &rows, 0, alpha, Act::CropCancel, |_, _| {}).click
    }

    fn splash(&self, p: &egui::Painter, g: &Grid, rect: Rect) {
        // An original calamari in block glyphs: mantle, fins, eyes, arms.
        let art: [(&str, Color32); 11] = [
            ("       ▄█▄       ", RUST_HI),
            ("      █████      ", RUST_HI),
            ("  ▄▄▄███████▄▄▄  ", RUST),
            ("     ███████     ", RUST),
            ("     ███████     ", RUST),
            ("     █◙███◙█     ", RUST),
            ("     ▀█████▀     ", RUST),
            ("    //|||||\\\\    ", MUTED),
            ("   // ||||| \\\\   ", MUTED),
            ("  //  || ||  \\\\  ", DIM),
            ("  ~   ~   ~   ~  ", DIM),
        ];
        let lines: [(&str, Color32); 4] = [
            ("Rusted Calamari", TEXT),
            ("", TEXT),
            ("Drop a folder here to start sorting it.", MUTED),
            ("Ctrl+O opens one. H lists the keys.", DIM),
        ];
        let h = (art.len() + 2 + lines.len()) as f32 * g.rh;
        let mut y = rect.center().y - h * 0.5;
        for (s, c) in art {
            let w = s.chars().count() as f32 * g.cw;
            g.text(p, Pos2::new(rect.center().x - w * 0.5, y), s, c, 1.0);
            y += g.rh;
        }
        y += g.rh * 2.0;
        for (s, c) in lines {
            let w = s.chars().count() as f32 * g.cw;
            g.text(p, Pos2::new(rect.center().x - w * 0.5, y), s, c, 1.0);
            y += g.rh;
        }
    }
}

impl eframe::App for App {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        if self.font_on != Some(self.s.font) {
            fonts::install(&ctx, self.s.font);
            self.font_on = Some(self.s.font);
            self.hold_frames = 3;
        }
        let now = ctx.input(|i| i.time);

        // Closing with unsaved edits asks first.
        if ctx.input(|i| i.viewport().close_requested()) && !self.pending.is_empty() && !self.quitting {
            ctx.send_viewport_cmd(ViewportCommand::CancelClose);
            self.dialog = Dialog::Unsaved;
        }

        self.drops(&ctx, now);
        self.loader.poll(&ctx);
        self.keys(&ctx, now);
        if ctx.input(|i| i.pointer.delta() != Vec2::ZERO) {
            self.quiet = false;
        }
        let g = Grid::new(&ctx, SIZES[self.s.size % SIZES.len()]);
        let full = ui.max_rect();
        ui.painter().rect_filled(full, 0.0, STAGE);

        // What the chrome is doing this frame.
        let ptr = ctx.input(|i| i.pointer.hover_pos());
        let dialog_open = !matches!(self.dialog, Dialog::None);
        let near_top = ptr.is_some_and(|p| p.y < full.top() + g.rh * 2.0);
        let near_bottom = ptr.is_some_and(|p| p.y > full.bottom() - g.rh * 2.5);
        let was_hover = self.chrome_hover;
        self.chrome_hover = false;
        let awake = !self.quiet || self.s.pin_ui;
        let bar_on = self.s.pin_ui || dialog_open || self.menu.is_some() || (awake && (near_top || (was_hover && !near_bottom)));
        let status_on = self.s.pin_ui || (awake && near_bottom);
        let a_bar = ctx.animate_bool_with_time(Id::new("fade-bar"), bar_on, 0.16);
        let a_status = ctx.animate_bool_with_time(Id::new("fade-status"), status_on, 0.16);

        // Layout. Pinned chrome takes its own room; hovered chrome floats over
        // the image. The tree's width animates and the stage takes the rest,
        // so folding the tree grows the image.
        let bar_h = g.rh * 1.5;
        let top = full.top() + if self.s.pin_ui { bar_h } else { 0.0 };
        let bottom = full.bottom() - if self.s.pin_ui { bar_h } else { 0.0 };
        let open_w = if self.lib.is_some() { self.tree_width(&g, full) } else { 0.0 };
        let target = if self.s.tree && self.lib.is_some() { open_w } else { 0.0 };
        let pw = ctx.animate_value_with_time(Id::new("panel-w"), target, 0.22);
        // The margin between tree and image opens and closes with the fold;
        // its centre line is the divider.
        let open_frac = if open_w > 0.0 { (pw / open_w).clamp(0.0, 1.0) } else { 0.0 };
        let gutter = g.cw * 2.0 * open_frac;
        let line_x = full.left() + pw + gutter * 0.5;
        let panel = Rect::from_min_max(Pos2::new(full.left(), top), Pos2::new(full.left() + pw, bottom));
        let stage = Rect::from_min_max(Pos2::new(full.left() + pw + gutter, top), Pos2::new(full.right(), bottom));

        let mut acts: Vec<Act> = Vec::new();
        if self.lib.is_none() {
            self.splash(ui.painter(), &g, full);
        } else {
            if pw > 1.0 {
                // Content rides the panel's right edge, so folding slides it away.
                let x0 = panel.right() - open_w;
                self.tree_pane(ui, panel, x0, &g, now);
                // The divider: drag it to set the tree's width, double-click it
                // to go back to hugging the tree.
                let zone = Rect::from_center_size(Pos2::new(line_x, panel.center().y), Vec2::new(g.cw * 1.4, panel.height()));
                let dr = ui.interact(zone, Id::new("divider"), Sense::click_and_drag());
                let hot = dr.hovered() || dr.dragged();
                let a_hot = ctx.animate_bool_with_time(Id::new("divider-hot"), hot, 0.12);
                if hot {
                    ctx.set_cursor_icon(CursorIcon::ResizeHorizontal);
                }
                if dr.dragged() {
                    self.s.panel_w = Some((open_w + dr.drag_delta().x).clamp(g.cw * 24.0, full.width() * 0.6));
                }
                if dr.double_clicked() {
                    self.s.panel_w = None;
                    self.tree_hold = 0.0;
                }
                let col = lerp_color(EDGE.gamma_multiply(0.7), RUST_HI, a_hot).gamma_multiply(open_frac);
                let p = ui.painter();
                let y0 = top + g.rh * 0.75;
                let y1 = bottom - g.rh * 0.75;
                p.line_segment([Pos2::new(line_x.round() + 0.5, y0), Pos2::new(line_x.round() + 0.5, y1)], Stroke::new(1.0 + a_hot, col));
                if a_hot > 0.01 {
                    // Grip: three dots where the pointer meets the rule.
                    let gy = dr.hover_pos().map_or(panel.center().y, |h| h.y).clamp(y0 + 12.0, y1 - 12.0);
                    for d in [-7.0, 0.0, 7.0] {
                        p.circle_filled(Pos2::new(line_x, gy + d), 2.0, RUST_HI.gamma_multiply(a_hot));
                    }
                }
            }
            self.stage(ui, stage.shrink(g.rh * 0.6), &g, now);
        }

        // Fold tab: appears as the pointer nears the tree's edge.
        if self.lib.is_some() {
            let edge_x = line_x;
            let near_edge = ptr.is_some_and(|p| (p.x - edge_x).abs() < g.cw * 6.0 && p.y > top && p.y < bottom);
            let tab_on = self.s.pin_ui || (awake && near_edge);
            let a_tab = ctx.animate_bool_with_time(Id::new("fade-tab"), tab_on, 0.16);
            if let Some(a) = self.fold_tab(&ctx, &g, edge_x, (top + bottom) * 0.5, a_tab) {
                acts.push(a);
            }
        }

        if let Some(a) = self.statusbar(&ctx, &g, full, a_status) {
            acts.push(a);
        }

        // Throws in flight: the image drops toward its slot chip.
        let fp = ctx.layer_painter(LayerId::new(Order::Foreground, Id::new("fly")));
        let mut landed = Vec::new();
        for (i, f) in self.fly.iter().enumerate() {
            let t = ((now - f.t0) / 0.26).min(1.0) as f32;
            let e = t * t * (3.0 - 2.0 * t);
            let target = self.chips.iter().find(|(c, _)| *c == f.cat).map_or(Pos2::new(full.center().x, full.bottom()), |c| c.1);
            let to = Rect::from_center_size(target, Vec2::new(g.cw * 3.0, g.rh));
            let r = Rect::from_min_max(f.from.min.lerp(to.min, e), f.from.max.lerp(to.max, e));
            let cid = self.lib.as_ref().and_then(|l| l.tree.cats.get(f.cat)).map_or(RUST_HI, |c| rgb(c.cid));
            if let Some(tex) = &f.tex {
                fp.image(tex.id(), r, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE.gamma_multiply(1.0 - 0.6 * e));
            }
            fp.rect_stroke(r, 0.0, Stroke::new(2.0, cid), StrokeKind::Inside);
            if t >= 1.0 {
                landed.push(i);
            }
        }
        for i in landed.into_iter().rev() {
            let f = self.fly.remove(i);
            self.landing = Some((f.cat, now));
        }
        if let Some((cat, t0)) = self.landing
            && now - t0 < 0.7
            && let Some((_, pos)) = self.chips.iter().find(|(c, _)| *c == cat)
            && let Some(c) = self.lib.as_ref().and_then(|l| l.tree.cats.get(cat))
        {
            let k = 1.0 - ((now - t0) / 0.7) as f32;
            let label = format!(" {} ", c.name);
            let r = Rect::from_center_size(*pos, g.size(label.chars().count(), 1));
            fp.rect_filled(r.expand(2.0), 2.0, rgb(c.cid).gamma_multiply(k));
            g.text(&fp, r.min, &label, STAGE, k);
        }

        // Toast: the outcome of anything with nothing else on screen to show for it.
        if let Some((m, c, t0)) = self.toast.clone() {
            let t0 = if t0 == 0.0 { now } else { t0 };
            self.toast = Some((m.clone(), c, t0));
            let age = now - t0;
            if age < 4.0 {
                let a = (1.0 - (age - 3.2).max(0.0) as f32 / 0.8).clamp(0.0, 1.0);
                let tp = ctx.layer_painter(LayerId::new(Order::Foreground, Id::new("toast")));
                let w = m.chars().count() + 4;
                let pos = Pos2::new(full.right() - (w as f32 + 2.0) * g.cw, top + g.rh * 2.0);
                let box_r = Rect::from_min_size(pos, g.size(w, 1)).expand2(Vec2::new(0.0, g.rh * 0.4));
                tp.rect_filled(box_r.translate(Vec2::new(3.0, 4.0)), 2.0, SHADOW.gamma_multiply(a));
                tp.rect_filled(box_r, 2.0, IRON.gamma_multiply(a));
                tp.rect_filled(Rect::from_min_size(box_r.min, Vec2::new(3.0, box_r.height())), 0.0, c.gamma_multiply(a));
                g.text(&tp, pos + Vec2::new(g.cw * 2.0, 0.0), &m, TEXT, a);
                ctx.request_repaint();
            } else {
                self.toast = None;
            }
        }

        let a_crop = ctx.animate_bool_with_time(Id::new("crop-bar"), self.crop.is_some(), 0.14);
        if let Some(a) = self.crop_bar(&ctx, &g, stage, a_crop) {
            acts.push(a);
        }
        if let Some(a) = self.menubar(&ctx, &g, full, a_bar) {
            acts.push(a);
        }
        // Each window fades and lifts in when it opens.
        let kind = match self.dialog {
            Dialog::None => 0,
            Dialog::Help => 1,
            Dialog::Settings => 2,
            Dialog::Form(_) => 3,
            Dialog::Unsaved => 4,
        };
        let mut a_dlg = 0.0;
        for k in 1..5 {
            let a = ctx.animate_bool_with_time(Id::new("dlg").with(k), kind == k, 0.14);
            if k == kind {
                a_dlg = a;
            }
        }
        let d = match self.dialog {
            Dialog::Settings => self.settings_dialog(&ctx, &g, full, a_dlg),
            Dialog::Form(_) => self.form_dialog(&ctx, &g, full, a_dlg),
            Dialog::Help => self.help_dialog(&ctx, &g, full, a_dlg),
            Dialog::Unsaved => self.unsaved_dialog(&ctx, &g, full, a_dlg),
            Dialog::None => None,
        };
        if let Some(a) = d {
            acts.push(a);
        }
        if self.cid_edit.is_some() {
            self.cid_editor(&ctx, &g, now);
        }
        // A click anywhere else closes an open menu.
        if self.menu.is_some() && ctx.input(|i| i.pointer.primary_clicked()) && !self.chrome_hover && acts.is_empty() {
            self.menu = None;
        }
        for a in acts {
            self.act(&ctx, a, now);
        }

        self.typed = ctx.memory(|m| m.focused().is_some());
        self.want();
        let anim = !self.fly.is_empty()
            || self.flash.as_ref().is_some_and(|f| now - f.t0 < 0.8)
            || self.landing.is_some_and(|(_, t0)| now - t0 < 0.7);
        if anim {
            ctx.request_repaint();
        }
    }

    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        eframe::set_value(storage, "rusted-calamari", &self.s);
    }
}
