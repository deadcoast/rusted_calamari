#![cfg_attr(all(not(debug_assertions), target_os = "windows"), windows_subsystem = "windows")]
//! Rusted Calamari. `cargo run --release` opens the window; the last
//! library reopens on its own. A folder path argument opens that instead.

mod app;
mod theme;
mod fonts;
mod glyph;
mod loader;

use eframe::egui;
use std::path::PathBuf;

fn main() -> eframe::Result {
    let arg = std::env::args().nth(1).map(PathBuf::from);
    let opts = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Rusted Calamari")
            .with_inner_size([1440.0, 900.0])
            .with_min_inner_size([720.0, 480.0])
            .with_drag_and_drop(true),
        ..Default::default()
    };
    eframe::run_native("Rusted Calamari", opts, Box::new(move |cc| Ok(Box::new(app::App::new(cc, arg)))))
}
