//! The interface kit. Retro delivery: every control is drawn in the
//! character grid with CP437 box glyphs, the way a DOS-era text UI built
//! its menu bars and double-ruled dialogs. Modern amplification: fades,
//! a short slide on open, soft shadows, hover inversion.
//!
//! Palette: iron and rust. The image stage stays neutral grey so the
//! interface never tints the photographs it frames.

use crate::glyph::Grid;
use eframe::egui::{self, Area, Color32, Id, Order, Pos2, Rect, Sense, Ui, Vec2};

/// Stage behind the image: neutral, so colour judgement isn't skewed.
pub const STAGE: Color32 = Color32::from_rgb(0x17, 0x18, 0x1a);
/// Tree panel, a half-step off the stage.
pub const PANEL: Color32 = Color32::from_rgb(0x1c, 0x1d, 0x20);
/// Bars and dialog bodies.
pub const IRON: Color32 = Color32::from_rgb(0x25, 0x27, 0x2b);
/// Row hover inside dialogs.
pub const IRON_HI: Color32 = Color32::from_rgb(0x31, 0x34, 0x39);
/// Rules and borders.
pub const EDGE: Color32 = Color32::from_rgb(0x62, 0x65, 0x6b);
pub const TEXT: Color32 = Color32::from_rgb(0xdd, 0xd8, 0xcc);
pub const MUTED: Color32 = Color32::from_rgb(0x8e, 0x8b, 0x84);
pub const DIM: Color32 = Color32::from_rgb(0x5a, 0x5c, 0x60);
/// Oxidised iron: the one accent.
pub const RUST: Color32 = Color32::from_rgb(0xb2, 0x52, 0x2a);
pub const RUST_HI: Color32 = Color32::from_rgb(0xe3, 0x88, 0x4a);
pub const WARN: Color32 = Color32::from_rgb(0xe0, 0x5a, 0x5a);
pub const SHADOW: Color32 = Color32::from_rgba_premultiplied(0, 0, 0, 120);

/// A run of text, optionally carrying an action.
#[derive(Clone)]
pub struct R<A> {
    pub t: String,
    pub c: Color32,
    pub a: Option<A>,
}

pub fn r<A>(t: impl Into<String>, c: Color32) -> R<A> {
    R { t: t.into(), c, a: None }
}

pub fn ra<A>(t: impl Into<String>, c: Color32, a: A) -> R<A> {
    R { t: t.into(), c, a: Some(a) }
}

#[derive(Clone)]
pub struct Row<A> {
    pub runs: Vec<R<A>>,
    /// Clicking anywhere on the row does this (unless a run says otherwise).
    pub act: Option<A>,
}

impl<A> Row<A> {
    pub fn new(runs: Vec<R<A>>) -> Self {
        Row { runs, act: None }
    }
    pub fn act(runs: Vec<R<A>>, a: A) -> Self {
        Row { runs, act: Some(a) }
    }
    pub fn blank() -> Self {
        Row { runs: Vec::new(), act: None }
    }
    pub fn cols(&self) -> usize {
        self.runs.iter().map(|x| x.t.chars().count()).sum()
    }
}

pub struct Out<A> {
    pub click: Option<A>,
    pub hovered: bool,
    pub rect: Rect,
}

fn paint_runs<A>(g: &Grid, p: &egui::Painter, pos: Pos2, runs: &[R<A>], alpha: f32, hot: Option<usize>) {
    let mut x = pos.x;
    let mut out: Vec<(String, Color32)> = Vec::with_capacity(runs.len());
    for (i, run) in runs.iter().enumerate() {
        let w = run.t.chars().count() as f32 * g.cw;
        if hot == Some(i) {
            p.rect_filled(Rect::from_min_size(Pos2::new(x, pos.y), Vec2::new(w, g.rh)), 0.0, RUST.gamma_multiply(alpha));
            out.push((run.t.clone(), STAGE));
        } else {
            out.push((run.t.clone(), run.c));
        }
        x += w;
    }
    g.line(p, pos, &out, alpha);
}

fn run_at<A>(g: &Grid, x0: f32, runs: &[R<A>], x: f32) -> Option<usize> {
    crate::glyph::run_at(runs, |r| r.t.chars().count(), g.col(x0, x))
}

/// A double-ruled window: `╔[■]═ Title ═╗`, body rows, `╚═╝`, and a shadow
/// one cell down and right. Rows with actions highlight on hover; runs with
/// actions invert on hover (buttons).
#[allow(clippy::too_many_arguments)]
pub fn dialog<A: Clone>(
    ctx: &egui::Context,
    g: &Grid,
    id: &str,
    pos: Pos2,
    title: &str,
    rows: &[Row<A>],
    min_cols: usize,
    alpha: f32,
    close: A,
    mut extra: impl FnMut(&mut Ui, Pos2),
) -> Out<A> {
    let mut out = Out { click: None, hovered: false, rect: Rect::NOTHING };
    let lift = (1.0 - alpha) * g.rh * 0.4;
    Area::new(Id::new(id))
        .fixed_pos(pos + Vec2::new(0.0, lift))
        .order(Order::Foreground)
        .interactable(alpha > 0.05)
        .show(ctx, |ui| {
            let inner = rows.iter().map(Row::cols).max().unwrap_or(0).max(min_cols).max(title.chars().count() + 8);
            let w = inner + 4;
            let size = g.size(w, rows.len() + 2);
            let (rect, resp) = ui.allocate_exact_size(size + Vec2::new(g.cw, g.rh * 0.5), Sense::click());
            let body = Rect::from_min_size(rect.min, size);
            let p = ui.painter();
            p.rect_filled(body.translate(Vec2::new(g.cw, g.rh * 0.5)), 0.0, SHADOW.gamma_multiply(alpha));
            p.rect_filled(body, 0.0, IRON.gamma_multiply(alpha));
            // Frame.
            let head: Vec<R<A>> = vec![
                r("╔", EDGE),
                ra("[■]", MUTED, close.clone()),
                r(format!("═ {title} "), TEXT),
                r(format!("{}╗", "═".repeat(w.saturating_sub(title.chars().count() + 8))), EDGE),
            ];
            let hover = resp.hover_pos();
            let hot_head = hover
                .filter(|h| h.y >= body.top() && h.y < body.top() + g.rh)
                .and_then(|h| run_at(g, body.left(), &head, h.x))
                .filter(|i| head[*i].a.is_some());
            paint_runs(g, p, body.min, &head, alpha, hot_head);
            for i in 0..rows.len() {
                let y = body.top() + (i + 1) as f32 * g.rh;
                g.line(p, Pos2::new(body.left(), y), &[("║".into(), EDGE)], alpha);
                g.line(p, Pos2::new(body.left() + (w - 1) as f32 * g.cw, y), &[("║".into(), EDGE)], alpha);
            }
            g.line(p, Pos2::new(body.left(), body.bottom() - g.rh), &[(format!("╚{}╝", "═".repeat(w - 2)), EDGE)], alpha);
            // Body.
            let o = body.min + Vec2::new(g.cw * 2.0, g.rh);
            let hr = hover.map(|h| ((h.y - o.y) / g.rh).floor() as isize);
            for (i, row) in rows.iter().enumerate() {
                let y = o.y + i as f32 * g.rh;
                let hot_row = hr == Some(i as isize);
                let hot_run = if hot_row { hover.and_then(|h| run_at(g, o.x, &row.runs, h.x)).filter(|j| row.runs[*j].a.is_some()) } else { None };
                if hot_row && row.act.is_some() && hot_run.is_none() {
                    p.rect_filled(
                        Rect::from_min_size(Pos2::new(body.left() + g.cw, y), Vec2::new((w - 2) as f32 * g.cw, g.rh)),
                        0.0,
                        IRON_HI.gamma_multiply(alpha),
                    );
                }
                paint_runs(g, p, Pos2::new(o.x, y), &row.runs, alpha, hot_run);
            }
            extra(ui, o);
            if resp.clicked()
                && let Some(c) = resp.interact_pointer_pos()
            {
                if c.y < body.top() + g.rh {
                    out.click = run_at(g, body.left(), &head, c.x).and_then(|i| head[i].a.clone());
                } else {
                    let i = ((c.y - o.y) / g.rh).floor();
                    if i >= 0.0
                        && let Some(row) = rows.get(i as usize)
                    {
                        out.click = run_at(g, o.x, &row.runs, c.x)
                            .and_then(|j| row.runs[j].a.clone())
                            .or_else(|| row.act.clone());
                    }
                }
            }
            out.hovered = resp.contains_pointer();
            out.rect = body;
        });
    out
}

pub enum Item<A> {
    Act { label: String, key: String, act: A, on: bool },
    Rule,
}

/// A menu dropdown: double-ruled, shortcut right-aligned, hovered row
/// inverted, disabled rows dim.
pub fn dropdown<A: Clone>(ctx: &egui::Context, g: &Grid, id: &str, pos: Pos2, items: &[Item<A>], alpha: f32) -> Out<A> {
    let mut out = Out { click: None, hovered: false, rect: Rect::NOTHING };
    let lw = items.iter().map(|i| if let Item::Act { label, .. } = i { label.chars().count() } else { 0 }).max().unwrap_or(0);
    let kw = items.iter().map(|i| if let Item::Act { key, .. } = i { key.chars().count() } else { 0 }).max().unwrap_or(0);
    let w = lw + kw + 8;
    let lift = (1.0 - alpha) * g.rh * 0.4;
    Area::new(Id::new(id))
        .fixed_pos(pos - Vec2::new(0.0, lift))
        .order(Order::Foreground)
        .interactable(alpha > 0.05)
        .show(ctx, |ui| {
            let size = g.size(w, items.len() + 2);
            let (rect, resp) = ui.allocate_exact_size(size + Vec2::new(g.cw, g.rh * 0.5), Sense::click());
            let body = Rect::from_min_size(rect.min, size);
            let p = ui.painter();
            p.rect_filled(body.translate(Vec2::new(g.cw, g.rh * 0.5)), 0.0, SHADOW.gamma_multiply(alpha));
            p.rect_filled(body, 0.0, IRON.gamma_multiply(alpha));
            g.line(p, body.min, &[(format!("╔{}╗", "═".repeat(w - 2)), EDGE)], alpha);
            let hr = resp.hover_pos().map(|h| ((h.y - body.top()) / g.rh).floor() as isize - 1);
            for (i, it) in items.iter().enumerate() {
                let y = body.top() + (i + 1) as f32 * g.rh;
                match it {
                    Item::Rule => {
                        g.line(p, Pos2::new(body.left(), y), &[(format!("╟{}╢", "─".repeat(w - 2)), EDGE)], alpha);
                    }
                    Item::Act { label, key, on, .. } => {
                        let hot = *on && hr == Some(i as isize);
                        if hot {
                            p.rect_filled(
                                Rect::from_min_size(Pos2::new(body.left() + g.cw, y), Vec2::new((w - 2) as f32 * g.cw, g.rh)),
                                0.0,
                                RUST.gamma_multiply(alpha),
                            );
                        }
                        let (tc, kc) = match (hot, on) {
                            (true, _) => (STAGE, STAGE),
                            (false, true) => (TEXT, MUTED),
                            (false, false) => (DIM, DIM),
                        };
                        g.line(
                            p,
                            Pos2::new(body.left(), y),
                            &[
                                ("║  ".into(), EDGE),
                                (format!("{label:<lw$}"), tc),
                                ("   ".into(), tc),
                                (format!("{key:>kw$}"), kc),
                                (" ".into(), tc),
                                ("║".into(), EDGE),
                            ],
                            alpha,
                        );
                    }
                }
            }
            g.line(p, Pos2::new(body.left(), body.bottom() - g.rh), &[(format!("╚{}╝", "═".repeat(w - 2)), EDGE)], alpha);
            if resp.clicked()
                && let Some(i) = hr
                && i >= 0
                && let Some(Item::Act { act, on: true, .. }) = items.get(i as usize)
            {
                out.click = Some(act.clone());
            }
            out.hovered = resp.contains_pointer();
            out.rect = body;
        });
    out
}

/// A text field cell: a recessed strip the caller puts a TextEdit on.
pub fn field_bg(p: &egui::Painter, r: Rect) {
    p.rect_filled(r.expand2(Vec2::new(3.0, 1.0)), 0.0, STAGE);
}
