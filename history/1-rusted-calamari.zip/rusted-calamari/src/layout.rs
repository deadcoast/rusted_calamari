//! Layout: tree -> tagged glyph lines.
//!
//! Every subtree renders to a `Block` (lines + the row its own label sits
//! on, the anchor). A directory has two kinds of children:
//!
//! * the **beak** — its category directories, one row per hier tier
//!   (`a.[_float_:6]`, `c.[1:9, 2:4, 3:7]`), fanned off the label row.
//!   The beak is the sorting mouth: the targets the active image can go to.
//! * **arms** — every other subdirectory, hung on a spine above (mirrored)
//!   or below the label.
//!
//! A node shows at most eight: the beak counts as one, the rest are arms;
//! overflow pages through an ink row.

use crate::tree::{Fold, Side, Tree};

pub const ARMS: usize = 8;
const SUCKER_CELLS: usize = 24;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Style {
    /// Beak fanned off the label, arms on a spine.
    Arm,
    /// Beak and arms share one fan; no spine anywhere.
    Beak,
    /// Beak enclosed in a box, arms on a spine.
    Boxed,
}

impl Style {
    pub fn parse(s: &str) -> Option<Style> {
        match s.to_ascii_lowercase().as_str() {
            "arm" => Some(Style::Arm),
            "beak" => Some(Style::Beak),
            "box" | "boxed" | "boxtobrachial" => Some(Style::Boxed),
            _ => None,
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            Style::Arm => "OCTOBRACHIAL ARM",
            Style::Beak => "OCTOBRACHIAL BEAK",
            Style::Boxed => "BOXTOBRACHIAL",
        }
    }
}

/// Token classes; the painter maps them to colours like lexer tokens.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Cls {
    /// Spine/connector glyphs; depth drives a rainbow-bracket cycle.
    Trunk(usize),
    Border(usize),
    Tier,
    Brack,
    Name,
    CatName(usize),
    Sucker(Option<usize>),
    Count,
    Fold,
    Ink,
    Mantle,
    Plain,
}

#[derive(Clone, Debug)]
pub struct Span {
    pub cls: Cls,
    pub text: String,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    Label,
    Beak,
    Border,
    Ink,
}

#[derive(Clone, Debug)]
pub struct Line {
    pub spans: Vec<Span>,
    /// Nodes with glyphs on this row (subtree extents are built from these).
    pub tags: Vec<usize>,
    /// Nodes whose label sits on this row.
    pub heads: Vec<usize>,
    pub kind: Kind,
}

impl Line {
    pub fn width(&self) -> usize {
        self.spans.iter().map(|s| s.text.chars().count()).sum()
    }
    pub fn text(&self) -> String {
        self.spans.iter().map(|s| s.text.as_str()).collect()
    }
    fn front(mut self, mut pre: Vec<Span>) -> Line {
        pre.append(&mut self.spans);
        self.spans = pre;
        self
    }
    /// Run a spine through this row's left padding at column 0.
    fn spine(&mut self, c: Cls) {
        if let Some(f) = self.spans.first_mut()
            && f.cls == Cls::Plain
            && f.text.starts_with(' ')
        {
            let rest: String = f.text.chars().skip(1).collect();
            f.text = rest;
            self.spans.insert(0, sp(c, "│"));
        }
    }
}

fn sp(cls: Cls, text: impl Into<String>) -> Span {
    Span { cls, text: text.into() }
}

#[derive(Clone, Debug)]
pub struct Block {
    pub lines: Vec<Line>,
    pub anchor: usize,
}

impl Block {
    fn one(l: Line) -> Block {
        Block { lines: vec![l], anchor: 0 }
    }
}

struct Arm {
    b: Block,
    side: Side,
}

/// Category children grouped into one beak row per tier.
fn beak_rows(t: &Tree, id: usize) -> Vec<Line> {
    let mut cats: Vec<usize> = t.nodes[id].kids.iter().copied().filter(|&k| t.nodes[k].own_cat.is_some()).collect();
    cats.sort_by_key(|&k| (t.tier(k), t.nodes[k].own_cat));
    let mut rows: Vec<Line> = Vec::new();
    let mut cur: Option<char> = None;
    for k in cats {
        let tier = t.tier(k);
        let c = t.nodes[k].own_cat.unwrap();
        let n = t.total(k);
        if tier != cur {
            if let Some(r) = rows.last_mut() {
                r.spans.push(sp(Cls::Brack, "]"));
            }
            rows.push(Line {
                spans: vec![sp(Cls::Tier, format!("{}.", tier.unwrap())), sp(Cls::Brack, "[")],
                tags: vec![],
                heads: vec![],
                kind: Kind::Beak,
            });
            cur = tier;
        } else {
            rows.last_mut().unwrap().spans.push(sp(Cls::Brack, ", "));
        }
        let r = rows.last_mut().unwrap();
        r.spans.push(sp(Cls::CatName(c), t.nodes[k].name.clone()));
        r.spans.push(sp(if n == 0 { Cls::Sucker(None) } else { Cls::Count }, format!(":{n}")));
        r.tags.push(k);
    }
    if let Some(r) = rows.last_mut() {
        r.spans.push(sp(Cls::Brack, "]"));
    }
    rows
}

/// Visible arms (non-category subdirs) and ink paging.
/// Returns (visible, hidden, page, pages).
pub fn arms(t: &Tree, id: usize) -> (Vec<usize>, usize, usize, usize) {
    let plain: Vec<usize> = t.nodes[id].kids.iter().copied().filter(|&k| t.nodes[k].own_cat.is_none()).collect();
    let has_beak = plain.len() < t.nodes[id].kids.len();
    let cap = ARMS - usize::from(has_beak);
    if plain.len() <= cap {
        return (plain, 0, 0, 1);
    }
    let per = cap - 1;
    let pages = plain.len().div_ceil(per);
    let p = t.nodes[id].page % pages;
    let s = p * per;
    let v: Vec<usize> = plain[s..(s + per).min(plain.len())].to_vec();
    let hidden = plain.len() - v.len();
    (v, hidden, p, pages)
}

fn suckers(files: &[Option<usize>]) -> Vec<Span> {
    let key = |c: &Option<usize>| c.map_or(usize::MAX, |x| x);
    let cells: Vec<Option<usize>> = if files.len() <= SUCKER_CELLS {
        let mut f = files.to_vec();
        f.sort_by_key(key);
        f
    } else {
        // Proportional cells by largest remainder; sorted first, loose last.
        let mut counts: Vec<(Option<usize>, usize)> = Vec::new();
        for &f in files {
            match counts.iter_mut().find(|(c, _)| *c == f) {
                Some((_, n)) => *n += 1,
                None => counts.push((f, 1)),
            }
        }
        counts.sort_by_key(|(c, _)| key(c));
        let total = files.len();
        let mut alloc: Vec<(Option<usize>, usize, usize)> = counts
            .iter()
            .map(|&(c, n)| (c, n * SUCKER_CELLS / total, n * SUCKER_CELLS % total))
            .collect();
        let mut left = SUCKER_CELLS - alloc.iter().map(|a| a.1).sum::<usize>();
        let mut order: Vec<usize> = (0..alloc.len()).collect();
        order.sort_by(|&a, &b| alloc[b].2.cmp(&alloc[a].2));
        for i in order {
            if left == 0 {
                break;
            }
            alloc[i].1 += 1;
            left -= 1;
        }
        alloc.iter().flat_map(|&(c, n, _)| std::iter::repeat_n(c, n)).collect()
    };
    let mut out: Vec<Span> = Vec::new();
    for c in cells {
        let g = if c.is_some() { '■' } else { '·' };
        match out.last_mut() {
            Some(s) if s.cls == Cls::Sucker(c) => s.text.push(g),
            _ => out.push(sp(Cls::Sucker(c), g.to_string())),
        }
    }
    out
}

fn label(t: &Tree, id: usize) -> Line {
    let n = &t.nodes[id];
    let mut s = Vec::new();
    if n.parent.is_none() {
        s.push(sp(Cls::Mantle, "◙ "));
    }
    s.push(sp(Cls::Brack, "["));
    s.push(sp(Cls::Name, n.name.clone()));
    s.push(sp(Cls::Brack, "]"));
    if !n.files.is_empty() {
        s.push(sp(Cls::Plain, " "));
        s.extend(suckers(&n.files));
        s.push(sp(Cls::Count, format!(" {}", n.files.len())));
    }
    if n.parent.is_none() {
        s.push(sp(Cls::Mantle, format!(" Σ{}", t.total(id))));
    }
    if !n.open && !n.kids.is_empty() {
        s.push(sp(Cls::Fold, format!(" ►{}", n.kids.len())));
    }
    Line { spans: s, tags: vec![id], heads: vec![id], kind: Kind::Label }
}

fn ink(id: usize, hidden: usize, p: usize, pages: usize) -> Line {
    Line {
        spans: vec![sp(Cls::Ink, format!("~[ink +{hidden}] {}/{pages} ►", p + 1))],
        tags: vec![id],
        heads: vec![],
        kind: Kind::Ink,
    }
}

fn block(t: &Tree, id: usize, depth: usize, style: Style) -> Block {
    let lab = label(t, id);
    let n = &t.nodes[id];
    if !n.open || n.kids.is_empty() {
        return Block::one(lab);
    }
    let rows = beak_rows(t, id);
    let (vis, hidden, p, pages) = arms(t, id);
    let mut kids: Vec<Arm> = vis
        .iter()
        .map(|&k| Arm { b: block(t, k, depth + 1, style), side: t.nodes[k].side })
        .collect();
    if hidden > 0 {
        let side = kids.last().map_or(Side::Down, |k| k.side);
        kids.push(Arm { b: Block::one(ink(id, hidden, p, pages)), side });
    }
    let fold = n.beak;
    let beak: Vec<Block> = rows.into_iter().map(Block::one).collect();
    match style {
        Style::Beak => {
            let mut all = beak;
            all.extend(kids.into_iter().map(|k| k.b));
            fan(lab, all, depth, fold)
        }
        Style::Arm => {
            let head = if beak.is_empty() { Block::one(lab) } else { fan(lab, beak, depth, fold) };
            trunk(head, kids, depth)
        }
        Style::Boxed => {
            let head = if beak.is_empty() { Block::one(lab) } else { boxed(lab, beak, depth, fold) };
            trunk(head, kids, depth)
        }
    }
}

/// Spine composition. Up arms are mirrored: first arm nearest the label,
/// farthest on top, corner glyphs flipped.
fn trunk(head: Block, kids: Vec<Arm>, depth: usize) -> Block {
    let c = Cls::Trunk(depth);
    let (ups, downs): (Vec<Arm>, Vec<Arm>) = kids.into_iter().partition(|k| k.side == Side::Up);
    let mut out = Vec::new();
    let nu = ups.len();
    for (i, k) in ups.into_iter().enumerate().rev() {
        let far = i == nu - 1;
        let a = k.b.anchor;
        for (r, l) in k.b.lines.into_iter().enumerate() {
            let pre = if r == a {
                if far { "┌─ " } else { "├─ " }
            } else if r < a && far {
                "   "
            } else {
                "│  "
            };
            out.push(l.front(vec![sp(c, pre)]));
        }
    }
    let (has_up, has_down) = (nu > 0, !downs.is_empty());
    let anchor = out.len() + head.anchor;
    for (r, mut l) in head.lines.into_iter().enumerate() {
        if (r < head.anchor && has_up) || (r > head.anchor && has_down) {
            l.spine(c);
        }
        out.push(l);
    }
    let nd = downs.len();
    for (i, k) in downs.into_iter().enumerate() {
        let last = i == nd - 1;
        let a = k.b.anchor;
        for (r, l) in k.b.lines.into_iter().enumerate() {
            let pre = if r == a {
                if last { "└─ " } else { "├─ " }
            } else if r > a && last {
                "   "
            } else {
                "│  "
            };
            out.push(l.front(vec![sp(c, pre)]));
        }
    }
    Block { lines: out, anchor }
}

/// The beak: children stacked to the right, the label pinned to one of
/// them by `fold`, so the fan spends no row of its own.
fn fan(lab: Line, kids: Vec<Block>, depth: usize, fold: Fold) -> Block {
    let c = Cls::Trunk(depth);
    let mut rows: Vec<Line> = Vec::new();
    let mut anchors = Vec::new();
    for k in kids {
        anchors.push(rows.len() + k.anchor);
        rows.extend(k.lines);
    }
    let (a0, al) = (anchors[0], *anchors.last().unwrap());
    let last = anchors.len() - 1;
    let p = match fold {
        Fold::Mid => anchors[last / 2],
        Fold::Up => al,
        Fold::Down => a0,
    };
    let lw = lab.width() + 2;
    let mut lab = Some(lab);
    let mut out = Vec::with_capacity(rows.len());
    for (r, mut l) in rows.into_iter().enumerate() {
        let ai = anchors.iter().position(|&a| a == r);
        let g = if last == 0 {
            if r == p { '─' } else { ' ' }
        } else {
            match (ai, r == p) {
                (Some(0), true) => '┬',
                (Some(i), true) if i == last => '┴',
                (Some(_), true) => '┼',
                (None, true) => '┤',
                (Some(0), false) => '┌',
                (Some(i), false) if i == last => '└',
                (Some(_), false) => '├',
                (None, false) => if r > a0 && r < al { '│' } else { ' ' },
            }
        };
        let tail = if ai.is_some() { "─ " } else { "  " };
        let mut pre = Vec::new();
        if r == p {
            let pl = lab.take().unwrap();
            l.tags.extend(pl.tags.iter().copied());
            l.heads.extend(pl.heads.iter().copied());
            pre.extend(pl.spans);
            pre.push(sp(c, " ─"));
        } else {
            pre.push(sp(Cls::Plain, " ".repeat(lw)));
        }
        pre.push(sp(c, format!("{g}{tail}")));
        out.push(l.front(pre));
    }
    Block { lines: out, anchor: p }
}

/// Boxtobrachial beak: tier rows in a box hooked to the label with ─┤.
fn boxed(lab: Line, rows: Vec<Block>, depth: usize, fold: Fold) -> Block {
    let c = Cls::Border(depth);
    let rows: Vec<Line> = rows.into_iter().flat_map(|b| b.lines).collect();
    let n = rows.len();
    let at = match fold {
        Fold::Mid => (n - 1) / 2,
        Fold::Up => n - 1,
        Fold::Down => 0,
    };
    let w = rows.iter().map(Line::width).max().unwrap_or(0);
    let lw = lab.width() + 3;
    let tags: Vec<usize> = rows.iter().flat_map(|l| l.tags.clone()).collect();
    let edge = |l: &str, r: &str| Line {
        spans: vec![sp(Cls::Plain, " ".repeat(lw)), sp(c, format!("{l}{}{r}", "─".repeat(w + 2)))],
        tags: tags.clone(),
        heads: vec![],
        kind: Kind::Border,
    };
    let mut out = vec![edge("┌", "┐")];
    let mut lab = Some(lab);
    for (i, mut l) in rows.into_iter().enumerate() {
        let pad = w - l.width();
        l.spans.push(sp(c, format!("{} │", " ".repeat(pad))));
        let pre = if i == at {
            let pl = lab.take().unwrap();
            l.tags.extend(pl.tags.iter().copied());
            l.heads.extend(pl.heads.iter().copied());
            let mut v = pl.spans;
            v.push(sp(c, " ──┤ "));
            v
        } else {
            vec![sp(Cls::Plain, " ".repeat(lw)), sp(c, "│ ")]
        };
        out.push(l.front(pre));
    }
    out.push(edge("└", "┘"));
    Block { lines: out, anchor: at + 1 }
}

/// Rendered tree plus row lookups for the tide engine.
pub struct Frame {
    pub lines: Vec<Line>,
}

impl Frame {
    pub fn row(&self, id: usize) -> Option<usize> {
        self.lines.iter().position(|l| l.heads.contains(&id))
    }
    pub fn ink_row(&self, id: usize) -> Option<usize> {
        self.lines.iter().position(|l| l.kind == Kind::Ink && l.tags[0] == id)
    }
    /// First and last rows a subtree occupies.
    pub fn span(&self, t: &Tree, id: usize) -> (usize, usize) {
        let mut lo = usize::MAX;
        let mut hi = 0;
        for (r, l) in self.lines.iter().enumerate() {
            if l.tags.iter().any(|&x| t.is_under(x, id)) {
                lo = lo.min(r);
                hi = hi.max(r);
            }
        }
        (lo, hi)
    }
}

pub fn render(t: &Tree, style: Style) -> Frame {
    Frame { lines: block(t, 0, 0, style).lines }
}

pub fn height(t: &Tree, id: usize, style: Style) -> usize {
    block(t, id, 1, style).lines.len()
}
