//! Directory arena. Directories are nodes; media files are not nodes, they
//! are suckers on their directory, each carrying the category it was sorted
//! into (the in-app cid, never written to the filesystem).

use crate::config::Cat;
use std::fs;
use std::io;
use std::path::Path;

const MEDIA: &[&str] = &[
    "jpg", "jpeg", "png", "gif", "webp", "bmp", "tif", "tiff", "heic", "avif", "jxl",
    "mp4", "mov", "mkv", "webm", "avi", "m4v",
];

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Side {
    Up,
    Down,
}

/// Where a node's label pins onto its beak fan. `Up` folds the tiers
/// upward (label on the last tier row), `Down` hangs them below.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Fold {
    Mid,
    Up,
    Down,
}

impl Side {
    pub fn flip(self) -> Side {
        match self {
            Side::Up => Side::Down,
            Side::Down => Side::Up,
        }
    }
}

#[derive(Clone, Debug)]
pub struct Node {
    pub name: String,
    pub parent: Option<usize>,
    pub kids: Vec<usize>,
    /// Category this directory *is* (its name matches a category).
    pub own_cat: Option<usize>,
    /// One entry per media file: the category it is sorted into.
    pub files: Vec<Option<usize>>,
    pub open: bool,
    /// Which side of its parent this arm hangs on.
    pub side: Side,
    /// Ink page when the node has more than eight arms.
    pub page: usize,
    pub beak: Fold,
}

pub struct Tree {
    pub nodes: Vec<Node>,
    pub cats: Vec<Cat>,
}

fn is_media(name: &str) -> bool {
    name.rsplit_once('.')
        .is_some_and(|(_, e)| MEDIA.contains(&e.to_ascii_lowercase().as_str()))
}

impl Tree {
    pub fn scan(root: &Path, cats: Vec<Cat>) -> io::Result<Tree> {
        let mut t = Tree { nodes: Vec::new(), cats };
        t.add(root, None, None)?;
        t.nodes[0].open = true;
        Ok(t)
    }

    fn add(&mut self, p: &Path, parent: Option<usize>, inherited: Option<usize>) -> io::Result<usize> {
        let name = p
            .file_name()
            .map(|s| s.to_string_lossy().into_owned())
            .unwrap_or_else(|| p.display().to_string());
        let own_cat = self.cats.iter().position(|c| c.name == name);
        let eff = own_cat.or(inherited);
        let id = self.nodes.len();
        self.nodes.push(Node {
            name,
            parent,
            kids: Vec::new(),
            own_cat,
            files: Vec::new(),
            open: false,
            side: Side::Down,
            page: 0,
            beak: Fold::Mid,
        });
        let mut entries: Vec<_> = fs::read_dir(p)?.filter_map(Result::ok).collect();
        entries.sort_by_key(|e| e.file_name());
        let mut dirs = Vec::new();
        for e in entries {
            let n = e.file_name().to_string_lossy().into_owned();
            if n.starts_with('.') {
                continue;
            }
            let ft = e.file_type()?;
            if ft.is_dir() {
                dirs.push(e.path());
            } else if ft.is_file() && is_media(&n) {
                self.nodes[id].files.push(eff);
            }
        }
        let mut kids = Vec::with_capacity(dirs.len());
        for d in dirs {
            kids.push(self.add(&d, Some(id), eff)?);
        }
        kids.sort_by_key(|&k| self.rank(k));
        self.nodes[id].kids = kids;
        Ok(id)
    }

    /// Categories first, by tier then name; plain directories after.
    fn rank(&self, id: usize) -> (u8, char, String) {
        let n = &self.nodes[id];
        match n.own_cat {
            Some(c) => (0, self.cats[c].tier, n.name.clone()),
            None => (1, '~', n.name.clone()),
        }
    }

    pub fn tier(&self, id: usize) -> Option<char> {
        self.nodes[id].own_cat.map(|c| self.cats[c].tier)
    }

    pub fn total(&self, id: usize) -> usize {
        let n = &self.nodes[id];
        n.files.len() + n.kids.iter().map(|&k| self.total(k)).sum::<usize>()
    }

    pub fn is_under(&self, mut x: usize, id: usize) -> bool {
        loop {
            if x == id {
                return true;
            }
            match self.nodes[x].parent {
                Some(p) => x = p,
                None => return false,
            }
        }
    }

    pub fn path(&self, id: usize) -> String {
        let mut parts = Vec::new();
        let mut x = Some(id);
        while let Some(i) = x {
            if self.nodes[i].parent.is_some() {
                parts.push(self.nodes[i].name.as_str());
            }
            x = self.nodes[i].parent;
        }
        parts.reverse();
        if parts.is_empty() { ".".into() } else { parts.join("/") }
    }

    /// Resolve `a/b/c` relative to the root. A trailing `~` targets the ink.
    pub fn find(&self, path: &str) -> Option<(usize, bool)> {
        let mut id = 0;
        let mut ink = false;
        for seg in path.split('/').filter(|s| !s.is_empty() && *s != ".") {
            if seg == "~" {
                ink = true;
                continue;
            }
            id = *self.nodes[id].kids.iter().find(|&&k| self.nodes[k].name == seg)?;
        }
        Some((id, ink))
    }
}
