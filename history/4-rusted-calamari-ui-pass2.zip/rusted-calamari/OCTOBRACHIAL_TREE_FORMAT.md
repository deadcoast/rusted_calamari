# Octobrachial Tree Format (OTF)

The directory display format of Rusted Calamari. Graph View draws Obsidian's
links; OTF draws Rusted Calamari's sort. The tree and the sorter share one
state: a keystroke that files the active image into `1` changes a glyph
in the tree, and clicking a node in the tree changes which directory the
sorter is feeding from. Neither renders the other.

Everything in this document beyond the request's own terms (`hier`, `cid`,
`_float_`, `_fav_`, the three style names, mirrored output, hotkeys) is a
design addition and is marked **[new]** where it first appears.

---

## 1. Anatomy

```
                                    ┌─ a.[_float_:6]                  ← beak, tier a
◙ [photos] ·············· 14 Σ259 ─┼─ b.[_fav_:3]                     ← beak, tier b
│                                  └─ c.[1:9, 2:4, 3:7, 4:2]          ← beak, tier c
├─ [scans] ►12                                                        ← folded arm
├─ [screens] ························ 31                              ← arm + suckers
└─ [trips]
   ├─ [2024]
   │  │  ┌─ [tokyo] ········ 8                                        ← mirrored arms
   │  │  ├─ [osaka] ························ 40
   │  │  ├─ [kyoto] ····· 5
   │  └─ [japan] ··········· 11 ─┬─ a.[_float_:2]                     ← beak hangs down
   │                             └─ c.[1:5, 2:3, 3:1]
   └─ [2025] ►1
```

| Part | What it is |
|---|---|
| **Mantle** `◙` **[new]** | The root of the open library. Carries its loose files and `Σ` total. Its arms split above and below it so the body sits mid-screen. |
| **Arm** | A plain subdirectory, hung on a spine. |
| **Beak** | The category directories of a node (`_float_`, `_fav_`, `1`..`8`), collapsed into **one row per hier tier**: `c.[1:9, 2:4, 3:7]`. This is the request's `[img]->[cata]->[hier]` fan made literal: the beak is the set of slots the active image can be thrown into. Categories never appear as arms. |
| **Suckers** **[new]** | One cell per media file on the arm's own row. `·` = loose (unsorted), `■` in the category's cid = sorted. Over 24 files the row becomes a proportional 24-cell bar. A directory's sucker row is its remaining work. |
| **Ink** **[new]** | `~[ink +5] 1/2 ►`. A node shows at most eight things: the beak counts as one, arms fill the rest, overflow pages through the ink row. Clicking ink turns the page. |
| **Fold mark** | `►12` on a closed node: how many children it holds. |

Hier tiers are adjacent, never nested: `a`, `b`, `c` are rows of the same
beak, ordered top to bottom.

## 2. Tokens and colour

OTF is coloured like source code. Each glyph run is a typed token:

| Token | Colour rule |
|---|---|
| `Trunk(depth)` | Spine and connector glyphs cycle a 6-colour ramp by depth, the way rainbow-bracket highlighting colours nesting. The octopus's arms read by colour before you read a name. |
| `CatName(cat)` | The category's cid, bold. |
| `Sucker(cat)` | The category's cid; loose files dim. |
| `Tier`, `Brack`, `Count` | Muted, like punctuation. |
| `Name` | Primary text. |
| `Mantle`, `Ink`, `Fold` | Fixed accents. |

The renderer emits `Line { spans: [Span { cls, text, node }], tags, heads }`.
The window paints spans on a monospace glyph grid in whichever of the
twelve int10h faces is selected, and a click resolves to (row, column) →
span → node, which is how a slot token knows it was hit.

## 3. Mirroring

A spine can hang its arms below the label (`├─ … └─`) or above it,
mirrored: the first arm stays nearest the label, the farthest arm goes on
top and takes the `┌─` corner.

```
├─ [2024]                    │  ┌─ [tokyo]
│  ├─ [kyoto]                │  ├─ [osaka]
│  ├─ [osaka]       ⇄        │  ├─ [kyoto]
│  └─ [tokyo]                └─ [japan]
```

The beak flexes separately. Its label pins to the middle tier (`Mid`), to
the last tier with the tiers folded above it (`Up`), or to the first tier
with the tiers hanging below (`Down`). `a` is always the top row of a
beak, so folding `Up` is the request's "hier(a) folds upward" rule.

## 4. The tide (on-click fit) **[new name]**

A click never moves the row under the cursor unless nothing else works.
Opening a node runs this ladder; each step is one render of the visible
tree, so a click costs a handful of linear passes over on-screen rows.

1. **FIT** — preferred arm side, beak `Mid`. The preferred side is down,
   unless the node itself hangs above its parent, in which case it keeps
   growing up.
2. **MIRROR** — the subtree overran the viewport (a snag). Try beak `Up`,
   beak `Down`, then flip the arms to the other side and try the three
   beak folds again. First shape that fits at the pinned row wins.
3. **SLIDE** — no shape fits at the pinned row but the subtree is shorter
   than the viewport: take the shape needing the smallest shift and move
   the row that many lines.
4. **RETRACT** — the subtree is taller than the viewport. Close the
   node's own open descendants, deepest first, re-running steps 1–3 after
   each. (A node remembers its open arms when folded; reopening it is
   where this fires.)
5. **CLIPPED** — a single level is taller than the viewport. Open toward
   the larger room and push the farthest arms off-screen.

Folding a node or paging ink pulls hidden rows back into any blank space
left at the bottom.

## 5. Styles

| Setting | Beak | Arms |
|---|---|---|
| `Octobrachial Arm` | fanned off the label row | spine |
| `Octobrachial Beak` | fanned, and arms join the same fan | no spine anywhere; the tree reads left to right like the request's `->` chains |
| `Boxtobrachial` | tier rows in a box hooked by `──┤` | spine |

```
◙ [photos] ·· 14 Σ259 ──┤ b.[_fav_:3]            │
```

## 6. Inside Rusted Calamari

The window is the image viewer. The image takes every pixel the layout can
give it; everything else is chrome that arrives on hover and leaves on the
next keystroke.

```
 hover top     ┌───────────────────────────────────────────────────────┐
 menu bar   →  │ ◙ Rusted Calamari  File Edit View Settings Help   path │
               ├─────────────┬──┬──────────────────────────────────────┤
               │ OTF tree    │ ││                                      │
               │ beside the  │ <│ ← divider + fold tab (hover)         │
               │ image       │ ││             image                    │
               │             │ ││                                      │
               ├─────────────┴──┴──────────────────────────────────────┤
 hover bottom  │ folder │ n of m │ name │ WxH │ MB │ zoom   z 1  x 2 .. │
 status line → └───────────────────────────────────────────────────────┘
```

- **Fold.** The tree sits beside the image. Its edge carries a tab that
  appears when the pointer nears it: `<` folds the tree away, `>` brings it
  back (`Tab` does both). The tree's width animates and the image stage
  takes whatever is left, so folding grows the image in the same motion.
- **Divider.** A two-cell margin separates the tree from the image, with a
  1px rule down its centre. The margin opens and closes with the fold. On
  hover the rule turns rust, thickens and shows a grip; drag it to set the
  tree's width, double-click it to go back to hugging the tree. The fold
  tab sits on it.
- **Pinned.** `PIN_UI` keeps the menu bar and status line up, and the stage
  shrinks to sit between them instead of under them.
- **Chrome.** Menus and dialogs share one frame: a single 1px rule with
  rounded corners (the `╭─╮ ╰─╯` shape, drawn as vector because no CP437
  face carries those glyphs), inset half a cell inside the body so nothing
  spills past it, over a soft two-layer shadow. Menu dividers stop one cell
  short of the frame on each side. Dialogs carry ` ■ Title ` set into the
  top rule; the square closes them. Menus and dialogs fade and lift in as
  they open. Shortcuts sit right-aligned; the hovered row inverts in rust.
- **Title.** Off by default. Settings > `Title over the image` (or View >
  Show the title) writes the folder and the image's number, `japan 003`,
  large on the image's lower left.
- **Status line.** Left: folder, position, file name, pixel size, file
  size, zoom, and `edited, not saved` when there are pending edits. Right:
  one keycap chip per bound category in its cid. Clicking a chip throws
  the image there; a keyboard throw drops the image toward its chip, which
  flashes even while the line is hidden.

| You do | The window does |
|---|---|
| `z x c v` / `SPACE` (any key bound to a category) | The image is moved on disk into `<active>/<category>/` and drops toward its chip; the slot token in the tree flashes and its count ticks up; the next image is already up. A name clash gets ` (2)`; nothing is overwritten. Pending edits are saved first so they travel with the file. |
| tree: click a slot token | Same throw, by mouse. |
| tree: right-click a slot token | Browse that category folder; the token shows `◄n/m`. |
| tree: click a folder | Sort from it; it opens through the tide; click again to fold it. |
| tree: click ink | Next page of arms. |
| `← → ↑ ↓ [ ] ; '` | ±1, ±5, ±25, ±50 through the active folder. |
| `Ctrl+K` | Crop tool: drag a frame, drag its edges or corners, drag inside to move it. `A` or the `◄ ►` in the crop bar cycles free, original, 1:1, 4:3, 3:2, 16:9, 3:4, 2:3, 9:16. `Enter` applies, `Esc` cancels. |
| `Ctrl+R` / `Ctrl+Shift+R`, `Ctrl+F` / `Ctrl+Shift+F` | Rotate right / left, flip horizontal / vertical. |
| `Ctrl+S` | Save the pending edits into the file (JPEG at quality 95, EXIF orientation baked in). Undo restores the old bytes. |
| `Ctrl+Shift+S` | Export as: a new file with the edits applied; PNG, JPEG, WebP, BMP or TIFF, picked by extension. The original is untouched. |
| File > Revert edits | Drop the pending edits on this image. |
| `Ctrl+Z` / `Backspace` | Undo the last edit, save, throw or trash. |
| `Delete` | Move to `<library>/.calamari_trash/`. |
| wheel / drag / `0` / `Ctrl+1` / double-click | Zoom / pan / fit / actual size / fit. |
| `Tab` · `H` · `.` · `Esc` · `Alt+F/E/V` | Fold tree · keys · settings · close · open a menu. |
| `Ctrl+O` · `Ctrl+I` · drop a folder or files | Open a folder · import images into the active folder · either. |
| close the window with pending edits | A dialog offers save all and quit, quit without saving, or cancel. |

Edits are pending until saved: crop, rotate and flip apply to a
screen-resolution preview at once and to the full-resolution file only on
Save or Export as, so a crop can be undone step by step before anything
touches the disk.

The active folder always shows every category as a slot, including ones
not yet created on disk (`4:0` dimmed); the folder is created on the first
throw. Other folders show only the categories they actually contain.

Menus: File (open folder, import images, save, save all, export as, revert
edits, import/export categories, export manifest `.csv`, export sorted set,
quit), Edit (undo, crop, rotate, flip, move to trash), View (fold the tree,
fit, actual size, tree style, pin the interface), Settings, Help.
Settings holds PIN_UI, the tree toggle, the twelve int10h faces, size,
style, and `[create]` > `[classification_category]` listing every
category: click one to edit or delete it, `+ category` to add one (name,
key captured by pressing it, colour with swatch cycling, tier).

The window reopens the last library and settings on launch.

Category table file, `<library>/.calamari` **[new]**:

```
# key  name     cid      tier
spc    _float_  #E6D463  a
-      _fav_    #F0A35E  b
z      1        #e56399  c
x      2        #92CC7C  c
c      3        #7f96ff  c
v      4        #a6cfd5  c
```

`_fav_` has no key or cid in the request; `#F0A35E` is a placeholder.

## 7. Open edges

- Category directories that themselves contain subdirectories are counted
  into their beak total; right-click browses only the category folder's
  own files.
- Video, HEIC, AVIF and JXL files are sortable but shown as a card; there
  is no decoder for them yet.
