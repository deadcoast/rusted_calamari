//! Octobrachial Tree Format (OTF) for Rusted Calamari.
//!
//! The tree is the sorter. `tree` holds the directory arena and the
//! category table, `layout` turns it into tagged glyph lines, `tide` is the
//! on-click fit/mirror/retract engine, `paint` colours lines like a syntax
//! highlighter.

pub mod config;
pub mod layout;
pub mod ops;
pub mod paint;
pub mod tide;
pub mod tree;

pub use layout::{render, Frame, Style};
pub use tide::{click, Trip, View};
pub use tree::{Side, Tree};
