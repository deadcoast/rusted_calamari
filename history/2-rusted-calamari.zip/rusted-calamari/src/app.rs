//! Rusted Calamari: the viewer, the sorter, and the Octobrachial Tree view
//! drawn on one surface. The image is the letter in the alien's hand; the
//! tree is the wall of slots; a keystroke throws one into the other and both
//! views change because they read the same state.

use crate::fonts::{self, FACES, SIZES};
use crate::glyph::{run_at, Grid, Run};
use crate::loader::{Loader, Slot};
use octo::ops::{self, Edit};
use eframe::egui::{
    self, Area, Color32, Event, Id, Key, LayerId, Order, Pos2, Rect, Sense, Stroke, StrokeKind, TextEdit, Vec2,
};
use octo::config::{self, Cat, Rgb};
use octo::layout::{render, Cls, Ctx, Kind, Style};
use octo::paint::colour;
use octo::tide::{self, balance, View};
use octo::tree::{is_decodable, Tree, IMAGES, OTHER_MEDIA};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

const BG: Color32 = Color32::from_rgb(0x0d, 0x0f, 0x12);
const VEIL: Color32 = Color32::from_rgba_premultiplied(9, 10, 13, 252);
const FIELD: Color32 = Color32::from_rgb(0x1a, 0x1d, 0x24);
const TEXT: Color32 = Color32::from_rgb(0xd7, 0xda, 0xe0);
const MUTED: Color32 = Color32::from_rgb(0x7a, 0x82, 0x90);
const DIM: Color32 = Color32::from_rgb(0x4b, 0x51, 0x60);
const GOLD: Color32 = Color32::from_rgb(0xe6, 0xd4, 0x63);
const RED: Color32 = Color32::from_rgb(0xe5, 0x63, 0x99);

const STYLES: [Style; 3] = [Style::Arm, Style::Beak, Style::Boxed];
const STYLE_NAMES: [&str; 3] = ["Octobrachial Arm", "Octobrachial Beak", "Boxtobrachial"];
const SWATCHES: [&str; 12] = [
    "#e56399", "#92CC7C", "#7f96ff", "#a6cfd5", "#E6D463", "#F0A35E", "#c792ea", "#ff8a65", "#4dd0e1", "#aed581",
    "#f06292", "#9fa8da",
];
/// Keys that belong to the app and cannot be given to a category.
const RESERVED: [&str; 2] = ["h", "0"];

fn rgb(c: Rgb) -> Color32 {
    Color32::from_rgb(c.0, c.1, c.2)
}

fn hexs(c: Rgb) -> String {
    format!("#{:02X}{:02X}{:02X}", c.0, c.1, c.2)
}

fn run(s: impl Into<String>, c: Color32) -> Run {
    (s.into(), c)
}

#[derive(Serialize, Deserialize, Clone)]
#[serde(default)]
pub struct Settings {
    pub font: usize,
    pub size: usize,
    pub style: usize,
    pub pin_ui: bool,
    pub tree: bool,
    pub library: Option<PathBuf>,
}

impl Default for Settings {
    fn default() -> Self {
        Settings { font: 0, size: 2, style: 0, pin_ui: false, tree: false, library: None }
    }
}

struct Lib {
    tree: Tree,
    active: usize,
    cursor: usize,
}

enum Undo {
    Move { from: usize, to: usize, from_name: String, to_name: String },
    Trash { node: usize, name: String, trashed: PathBuf },
    Edit { node: usize, name: String, bytes: Vec<u8> },
}

struct Fly {
    tex: Option<egui::TextureHandle>,
    from: Rect,
    cat: usize,
    t0: f64,
}

struct Strip {
    left: Vec<Run>,
    right: Vec<Run>,
    y: f32,
    ky: f32,
    right_at: Pos2,
    slots: Vec<(usize, Pos2)>,
}

struct Flash {
    node: usize,
    cat: usize,
    t0: f64,
}

#[derive(Clone, Copy, PartialEq)]
enum Menu {
    File,
    Edit,
    View,
}

struct Form {
    edit: Option<usize>,
    name: String,
    key: Option<String>,
    cid: String,
    tier: char,
    capturing: bool,
    err: Option<String>,
}

enum Overlay {
    None,
    Help,
    Settings,
    Form(Form),
}

enum TreeAct {
    Arm(usize),
    Ink(usize),
    Throw(usize),
    Browse(usize),
}

pub struct App {
    s: Settings,
    font_on: Option<usize>,
    lib: Option<Lib>,
    loader: Loader,
    view: View,
    overlay: Overlay,
    menu: Option<Menu>,
    menu_hover: bool,
    quiet: bool,
    zoom: f32,
    pan: Vec2,
    undo: Vec<Undo>,
    fly: Vec<Fly>,
    flash: Option<Flash>,
    note: Option<(String, Color32, f64)>,
    img_rect: Option<Rect>,
    slots: HashMap<usize, Pos2>,
    tree_acc: f32,
    /// Category chip that just received a throw.
    landing: Option<(usize, f64)>,
    /// Horizontal pan of the tree window when a row is wider than it.
    tree_dx: f32,
    /// A text field held focus last frame (egui drops focus on Escape
    /// before we see the key, so that Escape belongs to the field).
    typed: bool,
}

impl App {
    pub fn new(cc: &eframe::CreationContext<'_>, arg: Option<PathBuf>) -> App {
        let s: Settings = cc.storage.and_then(|st| eframe::get_value(st, "rusted-calamari")).unwrap_or_default();
        let mut v = egui::Visuals::dark();
        v.text_cursor.stroke = Stroke::new(2.0, GOLD);
        v.selection.bg_fill = Color32::from_rgb(0x3a, 0x34, 0x10);
        v.panel_fill = BG;
        cc.egui_ctx.set_visuals(v);
        let mut app = App {
            s,
            font_on: None,
            lib: None,
            loader: Loader::new(cc.egui_ctx.clone()),
            view: View { rows: 40, scroll: 0 },
            overlay: Overlay::None,
            menu: None,
            menu_hover: false,
            quiet: false,
            zoom: 1.0,
            pan: Vec2::ZERO,
            undo: Vec::new(),
            fly: Vec::new(),
            flash: None,
            note: None,
            img_rect: None,
            slots: HashMap::new(),
            tree_acc: 0.0,
            landing: None,
            tree_dx: 0.0,
            typed: false,
        };
        let start = arg.or_else(|| app.s.library.clone()).filter(|p| p.is_dir());
        if let Some(p) = start {
            app.open_library(&p);
        }
        app
    }

    fn style(&self) -> Style {
        STYLES[self.s.style % 3]
    }

    fn say(&mut self, s: impl Into<String>, c: Color32, now: f64) {
        self.note = Some((s.into(), c, now));
    }

    // ── library ────────────────────────────────────────────────────────

    fn open_library(&mut self, p: &Path) {
        let p = p.canonicalize().unwrap_or_else(|_| p.to_path_buf());
        match Tree::scan(&p, config::load(&p)) {
            Ok(mut tree) => {
                let style = self.style();
                balance(&mut tree, style, &Ctx { active: Some(0), cursor: 0 });
                self.lib = Some(Lib { tree, active: 0, cursor: 0 });
                self.s.library = Some(p);
                self.view.scroll = 0;
                self.undo.clear();
                self.fly.clear();
                self.flash = None;
                self.reset_view();
            }
            Err(e) => self.note = Some((format!("cannot open {}: {e}", p.display()), RED, 0.0)),
        }
    }

    fn reset_view(&mut self) {
        self.zoom = 1.0;
        self.pan = Vec2::ZERO;
    }

    fn current(&self) -> Option<PathBuf> {
        let lib = self.lib.as_ref()?;
        let f = lib.tree.nodes[lib.active].files.get(lib.cursor)?;
        Some(lib.tree.dir(lib.active).join(&f.name))
    }

    fn step(&mut self, d: isize) {
        let Some(lib) = self.lib.as_mut() else { return };
        let n = lib.tree.nodes[lib.active].files.len();
        if n == 0 {
            return;
        }
        let c = (lib.cursor as isize + d).clamp(0, n as isize - 1) as usize;
        if c != lib.cursor {
            lib.cursor = c;
            self.zoom = 1.0;
            self.pan = Vec2::ZERO;
        }
    }

    /// Throw the active image into category `cat` of the active folder.
    fn classify(&mut self, cat: usize, now: f64) {
        let from = self.img_rect;
        let Some(lib) = self.lib.as_mut() else { return };
        let a = lib.active;
        let Some(f) = lib.tree.nodes[a].files.get(lib.cursor).cloned() else { return };
        let dir = lib.tree.dir(a);
        let src = dir.join(&f.name);
        let cname = lib.tree.cats[cat].name.clone();
        match ops::move_into(&src, &dir.join(&cname), &f.name) {
            Ok(n) => {
                let tex = self.loader.texture(&src);
                self.loader.forget(&src);
                lib.tree.take_file(a, &f.name);
                let d = lib.tree.ensure_child(a, &cname);
                lib.tree.put_file(d, &n);
                let len = lib.tree.nodes[a].files.len();
                lib.cursor = lib.cursor.min(len.saturating_sub(1));
                self.undo.push(Undo::Move { from: a, to: d, from_name: f.name, to_name: n });
                if let Some(r) = from {
                    self.fly.push(Fly { tex, from: r, cat, t0: now });
                } else {
                    self.landing = Some((cat, now));
                }
                self.flash = Some(Flash { node: d, cat, t0: now });
                self.reset_view();
            }
            Err(e) => self.say(format!("move failed: {e}"), RED, now),
        }
    }

    fn trash(&mut self, now: f64) {
        let Some(lib) = self.lib.as_mut() else { return };
        let a = lib.active;
        let Some(f) = lib.tree.nodes[a].files.get(lib.cursor).cloned() else { return };
        let src = lib.tree.dir(a).join(&f.name);
        let td = ops::trash_dir(&lib.tree);
        match ops::move_into(&src, &td, &f.name) {
            Ok(n) => {
                self.loader.forget(&src);
                lib.tree.take_file(a, &f.name);
                let len = lib.tree.nodes[a].files.len();
                lib.cursor = lib.cursor.min(len.saturating_sub(1));
                self.undo.push(Undo::Trash { node: a, name: f.name, trashed: td.join(n) });
            }
            Err(e) => self.say(format!("trash failed: {e}"), RED, now),
        }
    }

    fn edit(&mut self, e: Edit, now: f64) {
        let Some(path) = self.current() else { return };
        let lib = self.lib.as_ref().unwrap();
        let (node, name) = (lib.active, lib.tree.nodes[lib.active].files[lib.cursor].name.clone());
        match ops::edit(&path, e) {
            Ok(bytes) => {
                self.loader.forget(&path);
                self.undo.push(Undo::Edit { node, name, bytes });
            }
            Err(err) => self.say(format!("{}: {err}", e.label()), RED, now),
        }
    }

    fn undo(&mut self, now: f64) {
        let Some(u) = self.undo.pop() else { return };
        let Some(lib) = self.lib.as_mut() else { return };
        let r = match u {
            Undo::Move { from, to, from_name, to_name } => {
                let src = lib.tree.dir(to).join(&to_name);
                ops::move_into(&src, &lib.tree.dir(from), &from_name).map(|n| {
                    lib.tree.take_file(to, &to_name);
                    let i = lib.tree.put_file(from, &n);
                    (from, i)
                })
            }
            Undo::Trash { node, name, trashed } => ops::move_into(&trashed, &lib.tree.dir(node), &name).map(|n| {
                let i = lib.tree.put_file(node, &n);
                (node, i)
            }),
            Undo::Edit { node, name, bytes } => {
                let p = lib.tree.dir(node).join(&name);
                std::fs::write(&p, bytes).map(|_| {
                    self.loader.forget(&p);
                    let i = lib.tree.nodes[node].files.iter().position(|f| f.name == name).unwrap_or(0);
                    (node, i)
                })
            }
        };
        match r {
            Ok((node, i)) => {
                lib.active = node;
                lib.cursor = i;
                self.reset_view();
            }
            Err(e) => self.say(format!("undo failed: {e}"), RED, now),
        }
    }

    // ── tree interaction ──────────────────────────────────────────────

    fn ctx_of(lib: &Lib) -> Ctx {
        Ctx { active: Some(lib.active), cursor: lib.cursor }
    }

    fn tree_act(&mut self, act: TreeAct, now: f64) {
        let style = self.style();
        match act {
            TreeAct::Throw(c) => self.classify(c, now),
            TreeAct::Ink(id) => {
                let lib = self.lib.as_mut().unwrap();
                let cx = Self::ctx_of(lib);
                tide::click(&mut lib.tree, &mut self.view, style, &cx, id, true);
            }
            TreeAct::Arm(id) | TreeAct::Browse(id) => {
                let lib = self.lib.as_mut().unwrap();
                if id == lib.active {
                    let cx = Self::ctx_of(lib);
                    tide::click(&mut lib.tree, &mut self.view, style, &cx, id, false);
                    return;
                }
                // Keep the clicked row under the pointer while the active
                // folder (and with it the slot rows) changes.
                let old = Self::ctx_of(lib);
                let r = render(&lib.tree, style, &old).row(id).map(|x| x as isize - self.view.scroll as isize);
                lib.active = id;
                lib.cursor = 0;
                let cx = Self::ctx_of(lib);
                let nr = render(&lib.tree, style, &cx).row(id);
                if let (Some(r), Some(nr)) = (r, nr) {
                    self.view.scroll = (nr as isize - r).max(0) as usize;
                }
                let n = &lib.tree.nodes[id];
                let has_arms = n.kids.iter().any(|&k| lib.tree.nodes[k].own_cat.is_none());
                if !n.open && has_arms {
                    tide::click(&mut lib.tree, &mut self.view, style, &cx, id, false);
                }
                self.reset_view();
            }
        }
    }

    /// The Octobrachial Tree view. Returns where the active folder's arm
    /// leaves its row, for the reach to the image.
    fn tree_pane(&mut self, ui: &mut egui::Ui, rect: Rect, g: &Grid, now: f64) -> Option<Pos2> {
        let style = self.style();
        let lib = self.lib.as_ref()?;
        let cx = Self::ctx_of(lib);
        let frame = render(&lib.tree, style, &cx);
        let inner = rect.shrink2(Vec2::new(g.cw * 1.5, g.rh));
        let rows = ((inner.height() / g.rh).floor() as usize).max(1);
        self.view.rows = rows;
        self.view.scroll = self.view.scroll.min(frame.lines.len().saturating_sub(1));

        let resp = ui.interact(rect, Id::new("otf-pane"), Sense::click_and_drag());
        let widest = frame.lines.iter().map(|l| l.width()).max().unwrap_or(0) as f32 * g.cw;
        let slack = (widest - inner.width()).max(0.0);
        if resp.hovered() {
            self.tree_dx += ui.input(|i| i.smooth_scroll_delta.x);
        }
        self.tree_dx = (self.tree_dx + resp.drag_delta().x).clamp(-slack, 0.0);
        let inner = inner.translate(Vec2::new(self.tree_dx, 0.0));
        if resp.hovered() {
            self.tree_acc += ui.input(|i| i.smooth_scroll_delta.y);
            while self.tree_acc >= g.rh {
                self.tree_acc -= g.rh;
                self.view.scroll = self.view.scroll.saturating_sub(1);
            }
            while self.tree_acc <= -g.rh {
                self.tree_acc += g.rh;
                if self.view.scroll + rows < frame.lines.len() {
                    self.view.scroll += 1;
                }
            }
        }
        let p = ui.painter().with_clip_rect(rect);
        let hover_row = resp
            .hover_pos()
            .map(|h| ((h.y - inner.top()) / g.rh).floor())
            .filter(|r| *r >= 0.0)
            .map(|r| r as usize);
        self.slots.clear();
        let mut arm = None;
        let end = (self.view.scroll + rows).min(frame.lines.len());
        for (i, li) in (self.view.scroll..end).enumerate() {
            let line = &frame.lines[li];
            let y = inner.top() + i as f32 * g.rh;
            if hover_row == Some(i) {
                p.rect_filled(
                    Rect::from_min_size(Pos2::new(rect.left(), y), Vec2::new(rect.width(), g.rh)),
                    0.0,
                    Color32::from_white_alpha(7),
                );
            }
            let mut x = inner.left();
            let mut runs: Vec<Run> = Vec::with_capacity(line.spans.len());
            for s in &line.spans {
                let w = s.text.chars().count() as f32 * g.cw;
                let (c, _) = colour(&lib.tree, s.cls);
                let mut col = rgb(c);
                if let Cls::CatName(cat) = s.cls {
                    if let Some(n) = s.node {
                        self.slots.insert(n, Pos2::new(x + w * 0.5, y + g.rh * 0.5));
                    }
                    if let Some(f) = &self.flash
                        && s.node == Some(f.node)
                        && cat == f.cat
                        && now - f.t0 < 0.8
                    {
                        let k = 1.0 - ((now - f.t0) / 0.8) as f32;
                        let r = Rect::from_min_size(Pos2::new(x - 1.0, y), Vec2::new(w + 2.0, g.rh));
                        p.rect_filled(r, 0.0, col.gamma_multiply(k));
                        if k > 0.45 {
                            col = BG;
                        }
                    }
                }
                runs.push((s.text.clone(), col));
                x += w;
            }
            g.line(&p, Pos2::new(inner.left(), y), &runs, 1.0);
            if line.heads.contains(&lib.active)
                || line.spans.iter().any(|s| s.node == Some(lib.active) && s.cls == Cls::Cursor)
            {
                arm = Some(Pos2::new(inner.left() + line.width() as f32 * g.cw + g.cw * 0.5, y + g.rh * 0.5));
            }
        }
        let above = self.view.scroll;
        let below = frame.lines.len().saturating_sub(end);
        if above > 0 {
            let t = format!("▲ {above}");
            g.text(&p, Pos2::new(rect.right() - (t.chars().count() as f32 + 2.0) * g.cw, rect.top() + 2.0), &t, DIM, 1.0);
        }
        if below > 0 {
            let t = format!("▼ {below}");
            g.text(&p, Pos2::new(rect.right() - (t.chars().count() as f32 + 2.0) * g.cw, rect.bottom() - g.rh - 2.0), &t, DIM, 1.0);
        }

        let mut act = None;
        if (resp.clicked() || resp.secondary_clicked())
            && let Some(pos) = resp.interact_pointer_pos()
        {
            let r = ((pos.y - inner.top()) / g.rh).floor();
            if r >= 0.0
                && let Some(line) = frame.lines.get(self.view.scroll + r as usize)
                && let Some(si) = run_at(&line.spans, |s| s.text.chars().count(), g.col(inner.left(), pos.x))
            {
                let s = &line.spans[si];
                let slot = line.spans[..=si].iter().rev().find_map(|x| match x.cls {
                    Cls::CatName(c) => Some((c, x.node)),
                    _ => None,
                });
                act = match s.cls {
                    Cls::Ink => s.node.map(TreeAct::Ink),
                    Cls::CatName(_) | Cls::Count | Cls::Sucker(None) if line.kind == Kind::Beak && slot.is_some() => {
                        let (c, node) = slot.unwrap();
                        if resp.secondary_clicked() { node.map(TreeAct::Browse) } else { Some(TreeAct::Throw(c)) }
                    }
                    _ => s.node.map(TreeAct::Arm),
                };
            }
        }
        if let Some(a) = act {
            self.tree_act(a, now);
        }
        arm
    }

    // ── image ────────────────────────────────────────────────────────

    fn card(&self, p: &egui::Painter, g: &Grid, center: Pos2, lines: &[(&str, Color32)]) {
        let w = lines.iter().map(|(s, _)| s.chars().count()).max().unwrap_or(0) + 2;
        let top = center - g.size(w + 2, lines.len() + 2) * 0.5;
        g.text(p, top, &format!("┌{}┐", "─".repeat(w)), DIM, 1.0);
        for (i, (s, c)) in lines.iter().enumerate() {
            let pad = w - 1 - s.chars().count();
            let pos = top + Vec2::new(0.0, (i + 1) as f32 * g.rh);
            g.line(p, pos, &[run("│ ", DIM), run(*s, *c), run(format!("{}│", " ".repeat(pad)), DIM)], 1.0);
        }
        g.text(p, top + Vec2::new(0.0, (lines.len() + 1) as f32 * g.rh), &format!("└{}┘", "─".repeat(w)), DIM, 1.0);
    }

    fn image_pane(&mut self, ui: &mut egui::Ui, rect: Rect, g: &Grid, now: f64) {
        self.img_rect = None;
        let Some(lib) = self.lib.as_ref() else { return };
        let node = &lib.tree.nodes[lib.active];
        let p = ui.painter().with_clip_rect(rect);
        let Some(f) = node.files.get(lib.cursor) else {
            let name = format!("[{}] holds no loose media", node.name);
            self.card(
                &p,
                g,
                rect.center(),
                &[(name.as_str(), TEXT), ("[file] open library, or drop a folder", MUTED), ("tab: pick a folder in the tree", MUTED)],
            );
            return;
        };
        let path = lib.tree.dir(lib.active).join(&f.name);
        let name = f.name.clone();
        let resp = ui.interact(rect, Id::new("img-pane"), Sense::click_and_drag());
        if resp.double_clicked() {
            self.reset_view();
        }
        self.pan += resp.drag_delta();
        if resp.hovered() {
            let dy = ui.input(|i| i.smooth_scroll_delta.y);
            if dy != 0.0
                && let Some(ptr) = resp.hover_pos()
            {
                let old = self.zoom;
                self.zoom = (self.zoom * (1.0 + dy * 0.0025)).clamp(0.1, 24.0);
                let c = rect.center() + self.pan;
                self.pan += (ptr - c) * (1.0 - self.zoom / old);
            }
        }
        match self.loader.get(&path) {
            Some(Slot::Ready { tex, .. }) => {
                let ts = tex.size_vec2();
                let fit = (rect.width() * 0.96 / ts.x).min(rect.height() * 0.94 / ts.y);
                let r = Rect::from_center_size(rect.center() + self.pan, ts * fit * self.zoom);
                p.image(tex.id(), r, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
                self.img_rect = Some(r);
            }
            Some(Slot::Failed(e)) => {
                let e = e.clone();
                self.card(&p, g, rect.center(), &[(name.as_str(), TEXT), ("cannot decode", RED), (e.as_str(), MUTED)]);
                self.img_rect = Some(Rect::from_center_size(rect.center(), g.size(20, 4)));
            }
            None if is_decodable(&name) => {
                let spin = ["|", "/", "-", "\\"][((now * 10.0) as usize) % 4];
                g.text(&p, rect.center() - Vec2::new(g.cw * 0.5, g.rh * 0.5), spin, DIM, 1.0);
                ui.ctx().request_repaint();
            }
            None => {
                self.card(&p, g, rect.center(), &[(name.as_str(), TEXT), ("no decoder for this format", MUTED), ("still sortable", MUTED)]);
                self.img_rect = Some(Rect::from_center_size(rect.center(), g.size(28, 5)));
            }
        }
    }

    fn want(&mut self) {
        let Some(lib) = self.lib.as_ref() else { return };
        let files = &lib.tree.nodes[lib.active].files;
        if files.is_empty() {
            self.loader.want(&[]);
            return;
        }
        let dir = lib.tree.dir(lib.active);
        let c = lib.cursor as isize;
        let mut v = Vec::new();
        for d in [0isize, 1, -1, 2, 3, -2, 5, -5, 25, 50] {
            let i = c + d;
            if i >= 0 && (i as usize) < files.len() {
                v.push(dir.join(&files[i as usize].name));
            }
        }
        self.loader.want(&v);
    }

    // ── input ────────────────────────────────────────────────────────

    fn key_name(k: Key) -> Option<String> {
        if k == Key::Space {
            return Some("spc".into());
        }
        let n = k.name();
        let mut ch = n.chars();
        match (ch.next(), ch.next()) {
            (Some(c), None) if c.is_ascii_alphanumeric() => Some(c.to_ascii_lowercase().to_string()),
            _ => None,
        }
    }

    fn keys(&mut self, ctx: &egui::Context, now: f64) {
        let typing = self.typed || ctx.memory(|m| m.focused().is_some());
        let events = ctx.input(|i| i.events.clone());
        for ev in events {
            let Event::Key { key, pressed: true, repeat, modifiers, .. } = ev else { continue };
            if let Overlay::Form(f) = &mut self.overlay
                && f.capturing
            {
                f.capturing = false;
                if key == Key::Escape {
                    continue;
                }
                let Some(n) = Self::key_name(key) else {
                    f.err = Some("letters, digits or space only".into());
                    continue;
                };
                let taken = self.lib.as_ref().and_then(|l| {
                    l.tree.cats.iter().enumerate().find(|(i, c)| Some(*i) != f.edit && c.key.as_deref() == Some(n.as_str()))
                });
                if RESERVED.contains(&n.as_str()) {
                    f.err = Some(format!("«{n}» belongs to the app"));
                } else if let Some((_, c)) = taken {
                    f.err = Some(format!("«{n}» already throws to [{}]", c.name));
                } else {
                    f.key = Some(n);
                    f.err = None;
                }
                continue;
            }
            if typing {
                if key == Key::Escape {
                    ctx.memory_mut(|m| {
                        if let Some(id) = m.focused() {
                            m.surrender_focus(id);
                        }
                    });
                }
                continue;
            }
            if !self.s.pin_ui {
                self.quiet = true;
            }
            let cmd = modifiers.command;
            match key {
                Key::Escape => {
                    self.overlay = Overlay::None;
                    self.menu = None;
                }
                Key::H if !cmd => {
                    self.overlay = if matches!(self.overlay, Overlay::Help) { Overlay::None } else { Overlay::Help };
                }
                Key::Period => {
                    self.overlay = if matches!(self.overlay, Overlay::Settings) { Overlay::None } else { Overlay::Settings };
                }
                Key::Tab => self.s.tree = !self.s.tree,
                Key::Num0 if !cmd => self.reset_view(),
                Key::Z if cmd => self.undo(now),
                Key::Backspace => self.undo(now),
                Key::Delete => self.trash(now),
                Key::R if cmd => self.edit(if modifiers.shift { Edit::RotCcw } else { Edit::RotCw }, now),
                Key::F if cmd => self.edit(if modifiers.shift { Edit::FlipV } else { Edit::FlipH }, now),
                Key::ArrowLeft => self.step(-1),
                Key::ArrowRight => self.step(1),
                Key::ArrowUp => self.step(-5),
                Key::ArrowDown => self.step(5),
                Key::OpenBracket => self.step(25),
                Key::CloseBracket => self.step(-25),
                Key::Semicolon => self.step(50),
                Key::Quote => self.step(-50),
                _ if !repeat && !cmd && !modifiers.alt => {
                    if let Some(n) = Self::key_name(key)
                        && let Some(c) = self
                            .lib
                            .as_ref()
                            .and_then(|l| l.tree.cats.iter().position(|c| c.key.as_deref() == Some(n.as_str())))
                    {
                        self.classify(c, now);
                    }
                }
                _ => {}
            }
        }
    }

    fn drops(&mut self, ctx: &egui::Context, now: f64) {
        let dropped: Vec<PathBuf> = ctx.input(|i| i.raw.dropped_files.iter().map(|f| f.path().to_path_buf()).filter(|p| !p.as_os_str().is_empty()).collect());
        if dropped.is_empty() {
            return;
        }
        if let Some(d) = dropped.iter().find(|p| p.is_dir()) {
            let d = d.clone();
            self.open_library(&d);
            return;
        }
        self.import_files(&dropped, now);
    }

    fn import_files(&mut self, files: &[PathBuf], now: f64) {
        let Some(lib) = self.lib.as_mut() else {
            self.say("open a library first", RED, now);
            return;
        };
        let dir = lib.tree.dir(lib.active);
        let mut n = 0;
        for f in files {
            let name = f.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
            if !octo::tree::is_media(&name) {
                continue;
            }
            if let Ok(nm) = ops::copy_into(f, &dir) {
                lib.tree.put_file(lib.active, &nm);
                n += 1;
            }
        }
        let into = lib.tree.nodes[lib.active].name.clone();
        self.say(format!("imported {n} into [{into}]"), MUTED, now);
    }

    // ── menus ───────────────────────────────────────────────────────

    /// A floating glyph block. Returns (row, column, secondary) of a click,
    /// and whether the pointer is over it.
    fn block(
        ctx: &egui::Context,
        g: &Grid,
        id: &str,
        pos: Pos2,
        rows: &[Vec<Run>],
        alpha: f32,
        bg: bool,
        mut extra: impl FnMut(&mut egui::Ui, Pos2),
    ) -> (Option<(usize, usize)>, bool) {
        let mut out = (None, false);
        Area::new(Id::new(id))
            .fixed_pos(pos)
            .order(Order::Foreground)
            .interactable(alpha > 0.05)
            .show(ctx, |ui| {
                let cols = rows.iter().map(|r| Grid::cols(r)).max().unwrap_or(0) + 2;
                let pad = Vec2::new(g.cw, g.rh * 0.5);
                let size = g.size(cols, rows.len()) + pad * 2.0;
                let (rect, resp) = ui.allocate_exact_size(size, Sense::click());
                let p = ui.painter();
                if bg {
                    p.rect_filled(rect, 0.0, VEIL.gamma_multiply(alpha));
                    p.rect_stroke(rect, 0.0, Stroke::new(1.0, DIM.gamma_multiply(alpha)), StrokeKind::Inside);
                }
                let o = rect.min + pad;
                let hr = resp.hover_pos().map(|h| ((h.y - o.y) / g.rh).floor() as isize);
                for (i, r) in rows.iter().enumerate() {
                    let y = o.y + i as f32 * g.rh;
                    if hr == Some(i as isize) && !r.is_empty() {
                        p.rect_filled(
                            Rect::from_min_size(Pos2::new(rect.left() + 1.0, y), Vec2::new(rect.width() - 2.0, g.rh)),
                            0.0,
                            Color32::from_white_alpha((10.0 * alpha) as u8),
                        );
                    }
                    g.line(p, Pos2::new(o.x, y), r, alpha);
                }
                extra(ui, o);
                if resp.clicked()
                    && let Some(c) = resp.interact_pointer_pos()
                {
                    let r = ((c.y - o.y) / g.rh).floor();
                    if r >= 0.0 && (r as usize) < rows.len() {
                        out.0 = Some((r as usize, g.col(o.x, c.x)));
                    }
                }
                out.1 = resp.hovered() || resp.contains_pointer();
            });
        out
    }

    fn top_bar(&mut self, ctx: &egui::Context, g: &Grid, full: Rect, alpha: f32, now: f64) {
        if alpha < 0.01 {
            self.menu_hover = false;
            return;
        }
        let items = ["file", "edit", "view", "settings", "help"];
        let mut runs = vec![run(" ≡ ", GOLD), run("RUSTED CALAMARI", GOLD), run("   ", DIM)];
        let mut cols = Vec::new();
        let mut c = Grid::cols(&runs);
        for it in items {
            let open = match it {
                "file" => self.menu == Some(Menu::File),
                "edit" => self.menu == Some(Menu::Edit),
                "view" => self.menu == Some(Menu::View),
                "settings" => matches!(self.overlay, Overlay::Settings | Overlay::Form(_)),
                _ => matches!(self.overlay, Overlay::Help),
            };
            let t = format!("[{it}]");
            cols.push((c, c + t.chars().count(), it));
            c += t.chars().count() + 2;
            runs.push(run(t, if open { GOLD } else { TEXT }));
            runs.push(run("  ", DIM));
        }
        if let Some(l) = &self.lib {
            runs.push(run(format!("  {}", l.tree.root.display()), DIM));
        }
        let strip = Rect::from_min_size(full.min, Vec2::new(full.width(), g.rh * 2.0));
        ctx.layer_painter(LayerId::new(Order::Middle, Id::new("bar"))).rect_filled(strip, 0.0, VEIL.gamma_multiply(alpha));
        let (hit, hov) = Self::block(ctx, g, "bar", full.min, &[runs], alpha, false, |_, _| {});
        self.menu_hover = hov;
        if let Some((_, col)) = hit
            && let Some((_, _, it)) = cols.iter().find(|(a, b, _)| col >= *a && col < *b)
        {
            match *it {
                "file" => self.menu = if self.menu == Some(Menu::File) { None } else { Some(Menu::File) },
                "edit" => self.menu = if self.menu == Some(Menu::Edit) { None } else { Some(Menu::Edit) },
                "view" => self.menu = if self.menu == Some(Menu::View) { None } else { Some(Menu::View) },
                "settings" => {
                    self.menu = None;
                    self.overlay = if matches!(self.overlay, Overlay::Settings) { Overlay::None } else { Overlay::Settings };
                }
                _ => {
                    self.menu = None;
                    self.overlay = if matches!(self.overlay, Overlay::Help) { Overlay::None } else { Overlay::Help };
                }
            }
        }
        let Some(m) = self.menu else { return };
        let x = cols
            .iter()
            .find(|(_, _, it)| match m {
                Menu::File => *it == "file",
                Menu::Edit => *it == "edit",
                Menu::View => *it == "view",
            })
            .map_or(0, |c| c.0);
        let pos = full.min + Vec2::new((x as f32 + 1.0) * g.cw, g.rh * 2.0);
        let entries: Vec<(&str, &str)> = match m {
            Menu::File => vec![
                ("open library", ""),
                ("import images", ""),
                ("import categories", ""),
                ("export manifest .csv", ""),
                ("export categories", ""),
                ("export sorted set", ""),
            ],
            Menu::Edit => vec![
                ("undo", "^Z"),
                ("rotate cw", "^R"),
                ("rotate ccw", "^S-R"),
                ("flip horizontal", "^F"),
                ("flip vertical", "^S-F"),
                ("trash", "del"),
            ],
            Menu::View => vec![
                (if self.s.tree { "[x] octobrachial tree" } else { "[ ] octobrachial tree" }, "tab"),
                ("fit image", "0"),
                (STYLE_NAMES[self.s.style % 3], "◄►"),
            ],
        };
        let n = entries.len();
        let rows: Vec<Vec<Run>> = entries
            .iter()
            .enumerate()
            .map(|(i, (a, k))| {
                vec![
                    run(if i + 1 == n { "└─ " } else { "├─ " }, DIM),
                    run(format!("{a:<22}"), TEXT),
                    run(*k, MUTED),
                ]
            })
            .collect();
        let (hit, hov) = Self::block(ctx, g, "menu", pos, &rows, alpha, true, |_, _| {});
        self.menu_hover |= hov;
        if let Some((r, _)) = hit {
            self.menu = None;
            match (m, r) {
                (Menu::File, 0) => {
                    if let Some(d) = rfd::FileDialog::new().set_title("Open library").pick_folder() {
                        self.open_library(&d);
                    }
                }
                (Menu::File, 1) => {
                    let ex: Vec<&str> = IMAGES.iter().chain(OTHER_MEDIA).copied().collect();
                    if let Some(fs) = rfd::FileDialog::new().add_filter("media", &ex).pick_files() {
                        self.import_files(&fs, now);
                    }
                }
                (Menu::File, 2) => self.import_categories(now),
                (Menu::File, 3) => self.export(0, now),
                (Menu::File, 4) => self.export(1, now),
                (Menu::File, 5) => self.export(2, now),
                (Menu::Edit, 0) => self.undo(now),
                (Menu::Edit, 1) => self.edit(Edit::RotCw, now),
                (Menu::Edit, 2) => self.edit(Edit::RotCcw, now),
                (Menu::Edit, 3) => self.edit(Edit::FlipH, now),
                (Menu::Edit, 4) => self.edit(Edit::FlipV, now),
                (Menu::Edit, 5) => self.trash(now),
                (Menu::View, 0) => self.s.tree = !self.s.tree,
                (Menu::View, 1) => self.reset_view(),
                (Menu::View, 2) => self.s.style = (self.s.style + 1) % 3,
                _ => {}
            }
        }
    }

    fn import_categories(&mut self, now: f64) {
        let Some(lib) = self.lib.as_mut() else { return };
        let Some(f) = rfd::FileDialog::new().set_title("Import categories").pick_file() else { return };
        let cats = std::fs::read_to_string(&f).map(|t| config::parse(&t)).unwrap_or_default();
        if cats.is_empty() {
            self.say("no categories in that file", RED, now);
            return;
        }
        lib.tree.cats = cats;
        lib.tree.recat();
        let _ = config::save(&lib.tree.root, &lib.tree.cats);
        self.flash = None;
        self.fly.clear();
    }

    fn export(&mut self, what: u8, now: f64) {
        let Some(lib) = self.lib.as_ref() else { return };
        let r = match what {
            0 => rfd::FileDialog::new()
                .set_file_name("calamari_manifest.csv")
                .save_file()
                .map(|p| std::fs::write(&p, ops::manifest(&lib.tree)).map(|_| format!("manifest -> {}", p.display()))),
            1 => rfd::FileDialog::new()
                .set_file_name("categories.calamari")
                .save_file()
                .map(|p| std::fs::write(&p, config::to_text(&lib.tree.cats)).map(|_| format!("categories -> {}", p.display()))),
            _ => rfd::FileDialog::new()
                .set_title("Export sorted set")
                .pick_folder()
                .map(|d| ops::export_set(&lib.tree, &d).map(|n| format!("{n} files -> {}", d.display()))),
        };
        match r {
            Some(Ok(m)) => self.say(m, MUTED, now),
            Some(Err(e)) => self.say(format!("export failed: {e}"), RED, now),
            None => {}
        }
    }

    // ── settings / create / help ─────────────────────────────────────

    fn settings(&mut self, ctx: &egui::Context, g: &Grid, pos: Pos2) {
        let cats: Vec<Cat> = self.lib.as_ref().map(|l| l.tree.cats.clone()).unwrap_or_else(config::defaults);
        let active = self.lib.as_ref().map(|l| l.tree.path(l.active)).unwrap_or_else(|| "-".into());
        let tick = |b: bool| if b { "[x]" } else { "[ ]" };
        let mut rows: Vec<Vec<Run>> = vec![
            vec![run("[settings]", GOLD), run(":style: ", DIM), run(format!("\"{}\"", STYLE_NAMES[self.s.style % 3]), TEXT)],
            vec![run("├─ ", DIM), run(tick(self.s.pin_ui), GOLD), run(" PIN_UI: Turn Active UI Fade OFF", TEXT)],
            vec![run("├─ ", DIM), run(tick(self.s.tree), GOLD), run(" TREE: Octobrachial Tree window", TEXT), run("  tab", DIM)],
            vec![run("├─ font  ", DIM), run("◄ ", GOLD), run(FACES[self.s.font % 12].name, TEXT), run(" ►", GOLD)],
            vec![run("├─ size  ", DIM), run("◄ ", GOLD), run(format!("{}", SIZES[self.s.size % SIZES.len()]), TEXT), run(" ►", GOLD)],
            vec![run("├─ style ", DIM), run("◄ ", GOLD), run(STYLE_NAMES[self.s.style % 3], TEXT), run(" ►", GOLD)],
            vec![run("└─ ", DIM), run("[create]", GOLD)],
            vec![run("   └─ ", DIM), run("[classification_category] ", TEXT), run(active, MUTED)],
        ];
        let first_cat = rows.len();
        for c in &cats {
            rows.push(vec![
                run("      ├─ ", DIM),
                run(format!("{}.", c.tier), MUTED),
                run("[", DIM),
                run(format!("{:<10}", format!("{}]", c.name)), rgb(c.cid)),
                run(format!(" {:<6}", format!("«{}»", c.key.as_deref().unwrap_or("-"))), MUTED),
                run(hexs(c.cid), DIM),
                run(" ██", rgb(c.cid)),
            ]);
        }
        rows.push(vec![run("      └─ ", DIM), run("+ category", GOLD)]);
        let (hit, _) = Self::block(ctx, g, "settings", pos, &rows, 1.0, true, |_, _| {});
        let Some((r, col)) = hit else { return };
        let back = col < 11;
        let cyc = |v: usize, n: usize| if back { (v + n - 1) % n } else { (v + 1) % n };
        match r {
            1 => self.s.pin_ui = !self.s.pin_ui,
            2 => self.s.tree = !self.s.tree,
            3 => self.s.font = cyc(self.s.font % 12, 12),
            4 => self.s.size = cyc(self.s.size % SIZES.len(), SIZES.len()),
            5 => self.s.style = cyc(self.s.style % 3, 3),
            r if r >= first_cat && r < first_cat + cats.len() => {
                let c = &cats[r - first_cat];
                self.overlay = Overlay::Form(Form {
                    edit: Some(r - first_cat),
                    name: c.name.clone(),
                    key: c.key.clone(),
                    cid: hexs(c.cid),
                    tier: c.tier,
                    capturing: false,
                    err: None,
                });
            }
            r if r == first_cat + cats.len() => {
                let used: Vec<String> = cats.iter().map(|c| hexs(c.cid).to_lowercase()).collect();
                let cid = SWATCHES.iter().find(|s| !used.contains(&s.to_lowercase())).unwrap_or(&SWATCHES[0]);
                self.overlay = Overlay::Form(Form {
                    edit: None,
                    name: String::new(),
                    key: None,
                    cid: cid.to_string(),
                    tier: 'c',
                    capturing: false,
                    err: None,
                });
            }
            _ => {}
        }
    }

    fn form(&mut self, ctx: &egui::Context, g: &Grid, pos: Pos2) {
        let Overlay::Form(f) = &mut self.overlay else { return };
        let cid = config::hex(&f.cid);
        let title = if f.edit.is_some() { "[edit]" } else { "[create]" };
        let rows: Vec<Vec<Run>> = vec![
            vec![run(title, GOLD), run(" > ", DIM), run("[category]", TEXT)],
            vec![run("├─ name ", DIM), run("┤ ", DIM), run(" ".repeat(18), TEXT), run(" │", DIM)],
            vec![
                run("├─ key  ", DIM),
                run("┤ ", DIM),
                run(
                    if f.capturing { "press a key..".to_string() } else { format!("«{}»", f.key.as_deref().unwrap_or("-")) },
                    if f.capturing { GOLD } else { TEXT },
                ),
                run(if f.capturing { "" } else { "  click to bind" }, DIM),
            ],
            vec![
                run("├─ cid  ", DIM),
                run("┤ ", DIM),
                run(" ".repeat(9), TEXT),
                run(" ████ ", cid.map_or(RED, rgb)),
                run("◄ swatch ►", GOLD),
            ],
            vec![run("├─ tier ", DIM), run("◄ ", GOLD), run(f.tier.to_string(), TEXT), run(" ►", GOLD), run("  a is highest", DIM)],
            vec![
                run("└─ ", DIM),
                run("[save]", GOLD),
                run("  ", DIM),
                run(if f.edit.is_some() { "[delete]" } else { "        " }, RED),
                run("  ", DIM),
                run("[cancel]", MUTED),
            ],
            vec![run(format!("   {}", f.err.clone().unwrap_or_default()), RED)],
        ];
        let font = g.font.clone();
        let (name_ref, cid_ref) = (&mut f.name, &mut f.cid);
        let (hit, _) = Self::block(ctx, g, "form", pos, &rows, 1.0, true, |ui, o| {
            let field = |row: usize, col: usize, w: usize| {
                Rect::from_min_size(o + Vec2::new(col as f32 * g.cw, row as f32 * g.rh), g.size(w, 1))
            };
            ui.painter().rect_filled(field(1, 10, 18).expand2(Vec2::new(3.0, 1.0)), 0.0, FIELD);
            ui.painter().rect_filled(field(3, 10, 9).expand2(Vec2::new(3.0, 1.0)), 0.0, FIELD);
            ui.put(
                field(1, 10, 18),
                TextEdit::singleline(name_ref).font(font.clone()).text_color(TEXT).frame(egui::Frame::NONE).margin(Vec2::ZERO),
            );
            ui.put(
                field(3, 10, 9),
                TextEdit::singleline(cid_ref).font(font.clone()).text_color(TEXT).frame(egui::Frame::NONE).margin(Vec2::ZERO),
            );
        });
        let Some((r, col)) = hit else { return };
        let Overlay::Form(f) = &mut self.overlay else { return };
        match r {
            2 => {
                f.capturing = true;
                f.err = None;
                ctx.memory_mut(|m| {
                    if let Some(id) = m.focused() {
                        m.surrender_focus(id);
                    }
                });
            }
            3 if col >= 25 => {
                let i = SWATCHES.iter().position(|s| s.eq_ignore_ascii_case(&f.cid)).unwrap_or(0);
                let n = SWATCHES.len();
                f.cid = SWATCHES[if col < 31 { (i + n - 1) % n } else { (i + 1) % n }].to_string();
            }
            4 => {
                let t = f.tier as u8;
                f.tier = if col < 10 { if t > b'a' { (t - 1) as char } else { 'a' } } else if t < b'z' { (t + 1) as char } else { 'z' };
            }
            5 if (3..9).contains(&col) => self.save_form(),
            5 if (11..19).contains(&col) => {
                if let Some(i) = f.edit
                    && let Some(lib) = self.lib.as_mut()
                {
                    lib.tree.cats.remove(i);
                    lib.tree.recat();
                    let _ = config::save(&lib.tree.root, &lib.tree.cats);
                    self.flash = None;
                    self.fly.clear();
                }
                self.overlay = Overlay::Settings;
            }
            5 if (21..29).contains(&col) => self.overlay = Overlay::Settings,
            _ => {}
        }
    }

    fn save_form(&mut self) {
        let Overlay::Form(f) = &mut self.overlay else { return };
        let name = f.name.trim().to_string();
        if name.is_empty() || name.contains(|c: char| c.is_whitespace() || "/\\:*?\"<>|".contains(c)) {
            f.err = Some("name must be a plain folder name, no spaces".into());
            return;
        }
        let Some(cid) = config::hex(&f.cid) else {
            f.err = Some("cid must be #RRGGBB".into());
            return;
        };
        let Some(lib) = self.lib.as_mut() else {
            f.err = Some("open a library first".into());
            return;
        };
        if lib.tree.cats.iter().enumerate().any(|(i, c)| Some(i) != f.edit && c.name == name) {
            f.err = Some(format!("[{name}] already exists"));
            return;
        }
        let cat = Cat { key: f.key.clone(), name, cid, tier: f.tier };
        match f.edit {
            Some(i) => lib.tree.cats[i] = cat,
            None => lib.tree.cats.push(cat),
        }
        lib.tree.recat();
        if let Err(e) = config::save(&lib.tree.root, &lib.tree.cats) {
            f.err = Some(format!("saved in app, not on disk: {e}"));
            return;
        }
        self.overlay = Overlay::Settings;
    }

    fn help(&mut self, ctx: &egui::Context, g: &Grid, pos: Pos2) {
        let cats: Vec<Cat> = self.lib.as_ref().map(|l| l.tree.cats.clone()).unwrap_or_else(config::defaults);
        let mut rows: Vec<Vec<Run>> = vec![vec![run("[help]", GOLD)], vec![run("├─ ", DIM), run("[classify]", GOLD), run("  active image ► slot", DIM)]];
        for (i, c) in cats.iter().enumerate() {
            let last = i + 1 == cats.len();
            rows.push(vec![
                run(if last { "│  └─ " } else { "│  ├─ " }, DIM),
                run(format!("{:<5}", c.key.as_deref().unwrap_or("-")), TEXT),
                run(format!("{}.[{}]", c.tier, c.name), rgb(c.cid)),
            ]);
        }
        let sec = |rows: &mut Vec<Vec<Run>>, head: &str, last: bool, items: &[(&str, &str)]| {
            rows.push(vec![run(if last { "└─ " } else { "├─ " }, DIM), run(head.to_string(), GOLD)]);
            for (i, (k, d)) in items.iter().enumerate() {
                let stem = if last { "   " } else { "│  " };
                let br = if i + 1 == items.len() { "└─ " } else { "├─ " };
                rows.push(vec![run(format!("{stem}{br}"), DIM), run(format!("{k:<14}"), TEXT), run(d.to_string(), MUTED)]);
            }
        };
        sec(&mut rows, "[browse]", false, &[
            ("← →", "1 back · 1 next"),
            ("↑ ↓", "5 back · 5 next"),
            ("[ ]", "25 next · 25 back"),
            ("; '", "50 next · 50 back"),
        ]);
        sec(&mut rows, "[edit]", false, &[
            ("^Z  bksp", "undo"),
            ("^R  ^S-R", "rotate cw · ccw"),
            ("^F  ^S-F", "flip horizontal · vertical"),
            ("del", "trash to .calamari_trash"),
        ]);
        sec(&mut rows, "[tree window]", false, &[
            ("click arm", "sort from it · again to fold"),
            ("click slot", "throw the image into it"),
            ("right-click", "browse that slot"),
            ("click ink", "next page of arms"),
            ("wheel", "scroll the tree"),
        ]);
        sec(&mut rows, "[view]", true, &[
            ("tab", "open / close tree window"),
            ("wheel · drag", "zoom · pan image"),
            ("0  dbl-click", "fit image"),
            (".", "settings"),
            ("h  esc", "close"),
        ]);
        let (hit, _) = Self::block(ctx, g, "help", pos, &rows, 1.0, true, |_, _| {});
        if hit.is_some() {
            self.overlay = Overlay::None;
        }
    }

    fn current_cat(&self) -> Option<Color32> {
        let lib = self.lib.as_ref()?;
        let c = lib.tree.nodes[lib.active].files.get(lib.cursor)?.cat?;
        Some(rgb(lib.tree.cats[c].cid))
    }

    /// Bottom strip layout: the letter's label on the left, the slot keys
    /// on the right. Computed every frame (throws aim at it) and painted
    /// only while hovered.
    fn strip(&self, g: &Grid, full: Rect) -> Option<Strip> {
        let lib = self.lib.as_ref()?;
        let n = &lib.tree.nodes[lib.active];
        let mut left = vec![run(format!("[{}] ", n.name), GOLD)];
        if let Some(f) = n.files.get(lib.cursor) {
            left.push(run(format!("{}/{}  ", lib.cursor + 1, n.files.len()), MUTED));
            left.push(run(f.name.clone(), TEXT));
            if let Some(c) = f.cat {
                let c = &lib.tree.cats[c];
                left.push(run(format!("  ■ {}", c.name), rgb(c.cid)));
            }
            let path = lib.tree.dir(lib.active).join(&f.name);
            if let Some(Slot::Ready { size, bytes, .. }) = self.loader.get(&path) {
                left.push(run(format!("  {}x{}  {:.1}MB", size[0], size[1], *bytes as f64 / 1_048_576.0), MUTED));
            }
        }
        let mut right: Vec<Run> = Vec::new();
        let mut marks: Vec<(usize, usize, usize)> = Vec::new();
        let mut col = 0;
        for (i, c) in lib.tree.cats.iter().enumerate() {
            if let Some(k) = &c.key {
                let kt = format!("{k} ");
                let nt = format!("{}", c.name);
                marks.push((i, col + kt.chars().count(), nt.chars().count()));
                col += kt.chars().count() + nt.chars().count() + 2;
                right.push(run(kt, MUTED));
                right.push(run(nt, rgb(c.cid)));
                right.push(run("  ", DIM));
            }
        }
        let y = full.bottom() - g.rh * 1.6;
        let lw = Grid::cols(&left) as f32 * g.cw;
        let rw = Grid::cols(&right) as f32 * g.cw;
        let fits = full.left() + g.cw * 2.0 + lw + g.cw * 3.0 + rw < full.right() - g.cw;
        let ky = if fits { y } else { y - g.rh };
        let right_at = Pos2::new(full.right() - rw - g.cw, ky);
        let slots = marks
            .into_iter()
            .map(|(i, c, w)| (i, Pos2::new(right_at.x + (c as f32 + w as f32 * 0.5) * g.cw, ky + g.rh * 0.5)))
            .collect();
        Some(Strip { left, right, y, ky, right_at, slots })
    }

    /// The Octobrachial Tree window. Like Graph View beside the editor: a
    /// second window over the same library, opened and closed with Tab.
    fn tree_window(&mut self, ctx: &egui::Context, g: &Grid, now: f64) {
        let id = egui::ViewportId::from_hash_of("octobrachial-tree");
        // Opens as wide as the tree is (applied only when the window is created).
        let w = self.lib.as_ref().map_or(620.0, |l| {
            let f = render(&l.tree, self.style(), &Self::ctx_of(l));
            f.lines.iter().map(|x| x.width()).max().unwrap_or(0) as f32 * g.cw + g.cw * 6.0
        });
        let builder = egui::ViewportBuilder::default()
            .with_title("Octobrachial Tree")
            .with_inner_size([w.clamp(420.0, 1100.0), 820.0])
            .with_min_inner_size([320.0, 240.0]);
        ctx.show_viewport_immediate(id, builder, |ui, _class| {
            let vctx = ui.ctx().clone();
            if vctx.input(|i| i.viewport().close_requested()) {
                self.s.tree = false;
                return;
            }
            self.keys(&vctx, now);
            let full = ui.max_rect();
            ui.painter().rect_filled(full, 0.0, BG);
            self.tree_pane(ui, full, g, now);
            if self.flash.as_ref().is_some_and(|f| now - f.t0 < 0.8) {
                vctx.request_repaint();
            }
        });
    }

    fn splash(&self, p: &egui::Painter, g: &Grid, rect: Rect) {
        let rows: Vec<Vec<Run>> = vec![
            vec![run("◙ ", GOLD), run("[RUSTED CALAMARI]", GOLD)],
            vec![run("├─ ", DIM), run("drop a folder on this window", TEXT)],
            vec![run("├─ ", DIM), run("or hover the top edge ", MUTED), run("► [file] ► open library", TEXT)],
            vec![run("├─ ", DIM), run("tab ", TEXT), run("octobrachial tree window", MUTED)],
            vec![run("└─ ", DIM), run("h ", TEXT), run("help", MUTED)],
        ];
        let w = rows.iter().map(|r| Grid::cols(r)).max().unwrap_or(0);
        let o = rect.center() - g.size(w, rows.len()) * 0.5;
        for (i, r) in rows.iter().enumerate() {
            g.line(p, o + Vec2::new(0.0, i as f32 * g.rh), r, 1.0);
        }
    }
}

impl eframe::App for App {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        if self.font_on != Some(self.s.font) {
            fonts::install(&ctx, self.s.font);
            self.font_on = Some(self.s.font);
        }
        let now = ctx.input(|i| i.time);
        self.drops(&ctx, now);
        self.loader.poll(&ctx);
        self.keys(&ctx, now);
        if ctx.input(|i| i.pointer.delta() != Vec2::ZERO) {
            self.quiet = false;
        }
        let g = Grid::new(&ctx, SIZES[self.s.size % SIZES.len()]);
        let full = ui.max_rect();
        ui.painter().rect_filled(full, 0.0, BG);

        // Fade: chrome shows while hovered, hides on use unless pinned.
        let ptr = ctx.input(|i| i.pointer.hover_pos());
        let overlay_open = !matches!(self.overlay, Overlay::None);
        let top = ptr.is_some_and(|p| p.y < full.top() + g.rh * 2.5);
        let bottom = ptr.is_some_and(|p| p.y > full.bottom() - g.rh * 3.0);
        let menu_on = self.s.pin_ui || overlay_open || self.menu.is_some() || ((top || self.menu_hover) && !self.quiet);
        let hud_on = self.s.pin_ui || (bottom && !self.quiet);
        let a_menu = ctx.animate_bool_with_time(Id::new("fade-menu"), menu_on, 0.18);
        let a_hud = ctx.animate_bool_with_time(Id::new("fade-hud"), hud_on, 0.18);

        // The window is the image.
        if self.lib.is_none() {
            self.splash(ui.painter(), &g, full);
        } else {
            self.image_pane(ui, full.shrink(g.rh * 0.75), &g, now);
            // The image's cid, held in the app: a bar under the picture.
            if let (Some(r), Some(c)) = (self.img_rect, self.current_cat()) {
                let bar = Rect::from_min_size(Pos2::new(r.left(), r.bottom() + 4.0), Vec2::new(r.width(), 3.0));
                ui.painter().rect_filled(bar, 0.0, c);
            }
        }

        let strip = self.strip(&g, full);

        // Throws in flight: the image drops toward its key in the strip.
        let fp = ctx.layer_painter(LayerId::new(Order::Foreground, Id::new("fly")));
        let mut landed = Vec::new();
        for (i, f) in self.fly.iter().enumerate() {
            let t = ((now - f.t0) / 0.26).min(1.0) as f32;
            let e = t * t * (3.0 - 2.0 * t);
            let target = strip
                .as_ref()
                .and_then(|s| s.slots.iter().find(|(c, _)| *c == f.cat).map(|(_, p)| *p))
                .unwrap_or(Pos2::new(full.center().x, full.bottom() - g.rh));
            let to = Rect::from_center_size(target, Vec2::new(g.cw * 2.0, g.rh));
            let r = Rect::from_min_max(f.from.min.lerp(to.min, e), f.from.max.lerp(to.max, e));
            let cid = self.lib.as_ref().and_then(|l| l.tree.cats.get(f.cat)).map_or(GOLD, |c| rgb(c.cid));
            if let Some(tex) = &f.tex {
                fp.image(tex.id(), r, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE.gamma_multiply(1.0 - 0.6 * e));
            }
            fp.rect_stroke(r, 0.0, Stroke::new(2.0, cid), StrokeKind::Inside);
            if t >= 1.0 {
                landed.push(i);
            }
        }
        for i in landed.into_iter().rev() {
            let f = self.fly.remove(i);
            self.landing = Some((f.cat, now));
        }
        // Where it landed: the category chip, in its cid, gone in a moment.
        if let Some((cat, t0)) = self.landing
            && now - t0 < 0.7
            && let Some(s) = &strip
            && let Some((_, p)) = s.slots.iter().find(|(c, _)| *c == cat)
            && let Some(c) = self.lib.as_ref().and_then(|l| l.tree.cats.get(cat))
        {
            let k = 1.0 - ((now - t0) / 0.7) as f32;
            let label = format!(" {} ", c.name);
            let r = Rect::from_center_size(*p, g.size(label.chars().count(), 1));
            fp.rect_filled(r, 0.0, rgb(c.cid).gamma_multiply(k));
            g.text(&fp, r.min, &label, BG, k);
        }

        // HUD: the letter's label and the slot keys.
        if a_hud > 0.01
            && let Some(s) = &strip
        {
            let band = Rect::from_min_max(Pos2::new(full.left(), s.ky - g.rh * 0.3), full.max);
            let hp = ctx.layer_painter(LayerId::new(Order::Middle, Id::new("hud")));
            hp.rect_filled(band, 0.0, VEIL.gamma_multiply(a_hud));
            g.line(&hp, Pos2::new(full.left() + g.cw * 2.0, s.y), &s.left, a_hud);
            g.line(&hp, s.right_at, &s.right, a_hud);
        }

        // Notes: errors and results with nothing on screen to show for them.
        if let Some((m, c, t0)) = self.note.clone() {
            let age = now - t0;
            if age < 4.0 || t0 == 0.0 {
                if t0 == 0.0 {
                    self.note = Some((m.clone(), c, now));
                }
                let a = (1.0 - ((age - 3.0).max(0.0)) as f32).clamp(0.0, 1.0);
                let np = ctx.layer_painter(LayerId::new(Order::Foreground, Id::new("note")));
                g.text(&np, Pos2::new(full.left() + g.cw * 2.0, full.top() + g.rh * 2.6), &format!("» {m}"), c, a);
                ctx.request_repaint();
            } else {
                self.note = None;
            }
        }

        self.top_bar(&ctx, &g, full, a_menu, now);
        let opos = full.min + Vec2::new(g.cw * 2.0, g.rh * 2.6);
        match self.overlay {
            Overlay::Settings => self.settings(&ctx, &g, opos),
            Overlay::Form(_) => self.form(&ctx, &g, opos),
            Overlay::Help => self.help(&ctx, &g, opos),
            Overlay::None => {}
        }
        self.typed = ctx.memory(|m| m.focused().is_some());

        // The Octobrachial Tree: its own window, opened on demand.
        if self.s.tree && self.lib.is_some() {
            self.tree_window(&ctx, &g, now);
        }

        self.want();
        let anim = !self.fly.is_empty()
            || self.flash.as_ref().is_some_and(|f| now - f.t0 < 0.8)
            || self.landing.is_some_and(|(_, t0)| now - t0 < 0.7);
        if anim {
            ctx.request_repaint();
        }
    }

    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        eframe::set_value(storage, "rusted-calamari", &self.s);
    }
}
