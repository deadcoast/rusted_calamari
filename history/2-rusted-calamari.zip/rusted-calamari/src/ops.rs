//! Disk operations. Every one returns what undo needs.

use image::codecs::jpeg::JpegEncoder;
use image::{DynamicImage, ImageDecoder, ImageFormat, ImageReader};
use crate::tree::Tree;
use std::fs;
use std::io::{self, Cursor};
use std::path::{Path, PathBuf};

/// Decode with EXIF orientation applied.
pub fn decode(p: &Path) -> Result<DynamicImage, String> {
    let mut dec = ImageReader::open(p)
        .map_err(|e| e.to_string())?
        .with_guessed_format()
        .map_err(|e| e.to_string())?
        .into_decoder()
        .map_err(|e| e.to_string())?;
    let orient = dec.orientation().ok();
    let mut img = DynamicImage::from_decoder(dec).map_err(|e| e.to_string())?;
    if let Some(o) = orient {
        img.apply_orientation(o);
    }
    Ok(img)
}

/// `name` if free in `dir`, else `stem (2).ext`, `stem (3).ext`, ...
pub fn unique(dir: &Path, name: &str) -> String {
    if !dir.join(name).exists() {
        return name.to_string();
    }
    let (stem, ext) = match name.rsplit_once('.') {
        Some((s, e)) => (s.to_string(), format!(".{e}")),
        None => (name.to_string(), String::new()),
    };
    (2..)
        .map(|i| format!("{stem} ({i}){ext}"))
        .find(|n| !dir.join(n).exists())
        .unwrap()
}

/// Move `src` into `dst_dir`, creating it. Returns the name it landed as.
pub fn move_into(src: &Path, dst_dir: &Path, name: &str) -> io::Result<String> {
    fs::create_dir_all(dst_dir)?;
    let n = unique(dst_dir, name);
    let dst = dst_dir.join(&n);
    if fs::rename(src, &dst).is_err() {
        // Different volume: copy, then remove.
        fs::copy(src, &dst)?;
        fs::remove_file(src)?;
    }
    Ok(n)
}

pub fn copy_into(src: &Path, dst_dir: &Path) -> io::Result<String> {
    fs::create_dir_all(dst_dir)?;
    let name = src.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
    let n = unique(dst_dir, &name);
    fs::copy(src, dst_dir.join(&n))?;
    Ok(n)
}

#[derive(Clone, Copy, Debug)]
pub enum Edit {
    RotCw,
    RotCcw,
    FlipH,
    FlipV,
}

impl Edit {
    pub fn label(self) -> &'static str {
        match self {
            Edit::RotCw => "rotate cw",
            Edit::RotCcw => "rotate ccw",
            Edit::FlipH => "flip horizontal",
            Edit::FlipV => "flip vertical",
        }
    }
}

/// Apply an edit in place. Returns the original bytes for undo.
/// JPEGs are re-encoded at quality 95 with EXIF orientation baked in.
pub fn edit(path: &Path, e: Edit) -> Result<Vec<u8>, String> {
    let ext = path.extension().map(|e| e.to_string_lossy().to_ascii_lowercase()).unwrap_or_default();
    if ext == "gif" {
        return Err("gif frames are not edited".into());
    }
    let orig = fs::read(path).map_err(|e| e.to_string())?;
    let img = decode(path)?;
    let img: DynamicImage = match e {
        Edit::RotCw => img.rotate90(),
        Edit::RotCcw => img.rotate270(),
        Edit::FlipH => img.fliph(),
        Edit::FlipV => img.flipv(),
    };
    let mut buf = Vec::new();
    if ext == "jpg" || ext == "jpeg" {
        JpegEncoder::new_with_quality(&mut buf, 95)
            .encode_image(&img.to_rgb8())
            .map_err(|e| e.to_string())?;
    } else {
        let fmt = ImageFormat::from_path(path).map_err(|e| e.to_string())?;
        img.write_to(&mut Cursor::new(&mut buf), fmt).map_err(|e| e.to_string())?;
    }
    let tmp = path.with_extension(format!("{ext}.calamari-tmp"));
    fs::write(&tmp, &buf).map_err(|e| e.to_string())?;
    fs::rename(&tmp, path).map_err(|e| e.to_string())?;
    Ok(orig)
}

pub fn trash_dir(t: &Tree) -> PathBuf {
    t.root.join(".calamari_trash")
}

fn csv(s: &str) -> String {
    if s.contains([',', '"', '\n']) { format!("\"{}\"", s.replace('"', "\"\"")) } else { s.to_string() }
}

/// Every media file with its category, tier and cid.
pub fn manifest(t: &Tree) -> String {
    let mut out = String::from("path,category,tier,cid\n");
    for (i, n) in t.nodes.iter().enumerate() {
        let dir = t.path(i);
        for f in &n.files {
            let rel = if dir == "." { f.name.clone() } else { format!("{dir}/{}", f.name) };
            let (cat, tier, cid) = match f.cat {
                Some(c) => {
                    let c = &t.cats[c];
                    (c.name.clone(), c.tier.to_string(), format!("#{:02X}{:02X}{:02X}", c.cid.0, c.cid.1, c.cid.2))
                }
                None => (String::new(), String::new(), String::new()),
            };
            out.push_str(&format!("{},{},{},{}\n", csv(&rel), csv(&cat), tier, cid));
        }
    }
    out
}

/// Copy every sorted file into `dest/<category>/`. Returns files copied.
pub fn export_set(t: &Tree, dest: &Path) -> io::Result<usize> {
    let mut n = 0;
    for (i, node) in t.nodes.iter().enumerate() {
        for f in &node.files {
            if let Some(c) = f.cat {
                copy_into(&t.dir(i).join(&f.name), &dest.join(&t.cats[c].name))?;
                n += 1;
            }
        }
    }
    Ok(n)
}
